import { tryRecover } from "./recover";
import DeliveryApp from "./DeliveryApp";

/* eslint-disable react-hooks/exhaustive-deps, no-unused-vars */

import React, { useState, useEffect, useRef, useCallback, useMemo, memo } from "react";
import { db, auth, authReady } from "./firebase";
import { signInWithEmailAndPassword, signOut, onAuthStateChanged, signInAnonymously, RecaptchaVerifier, linkWithPhoneNumber, PhoneAuthProvider, signInWithCredential, setPersistence, browserLocalPersistence } from "firebase/auth";
import {
  collection, doc, setDoc, onSnapshot, updateDoc, deleteDoc,
  getDocs, getDoc, addDoc, query, orderBy, serverTimestamp, where, limit, arrayUnion, arrayRemove,
  runTransaction  //  ADD THIS
} from "firebase/firestore";
import { QRCodeSVG } from 'qrcode.react';
import * as HX from "./hardening";
function ImageUploadButton({ currentImage, onUploaded, label }) {
  const widgetRef = useRef(null);
  const onUploadedRef = useRef(onUploaded);
  onUploadedRef.current = onUploaded;
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;
    let tries = 0;
    const tryInit = () => {
      if (cancelled) return;
      if (window.cloudinary) {
        widgetRef.current = window.cloudinary.createUploadWidget(
          {
            cloudName: "nnddxvcn",
            uploadPreset: "eatpark_uploads",
            sources: ["local", "camera", "url"],
            multiple: false,
            maxFileSize: 5000000,
            clientAllowedFormats: ["jpg", "jpeg", "png", "webp"],
          },
          (error, result) => {
            if (error) {
              console.error("Cloudinary error:", error);
              alert("Upload fail: " + (error.statusText || error.message || JSON.stringify(error)));
              return;
            }
            if (result && result.event === "success") {
              onUploadedRef.current(result.info.secure_url);
            }
          }
        );
        setReady(true);
      } else if (++tries < 20) {
        setTimeout(tryInit, 300);
      } else {
        alert("Cloudinary script load nahi hui. public/index.html check karo.");
      }
    };
    tryInit();
    return () => { cancelled = true; };
  }, []);

  const openWidget = () => {
    if (widgetRef.current) widgetRef.current.open();
  };

  return (
    <button
      onClick={openWidget}
      disabled={!ready}
      style={{
        width: "100%",
        padding: 14,
        border: "none",
        borderRadius: 12,
        background: ready ? "#D97706" : "#999",
        color: "#fff",
        fontWeight: 800,
        fontSize: 14,
        cursor: ready ? "pointer" : "wait",
      }}
    >
      {ready ? (label || "📸 Upload Image") : "⏳ Loading..."}
    </button>
  );
}
/* ═══════════════════════════════════════════════════════════════════════
   🍽️ EAT & PARK RESTAURANT — V15 FINAL
   Waiter Mode · Running Items · KOT · Touch Kitchen · Live Notifications
   ═══════════════════════════════════════════════════════════════════════ */

// ==
// 1. CONSTANTS
// ==

const FONTS = `
@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap');
@keyframes flash { 0% { background-color: #E25938; } 50% { background-color: #C1442D; } 100% { background-color: #E25938; } }
@keyframes slideUp { from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
@keyframes slideRight { from { transform: translateX(-100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
@keyframes toastSlide { 0% { transform: translate(-50%, 100px); opacity: 0; } 10% { transform: translate(-50%, 0); opacity: 1; } 90% { transform: translate(-50%, 0); opacity: 1; } 100% { transform: translate(-50%, 100px); opacity: 0; } }
@keyframes scaleInBounce { 0% { transform: scale(0.3); opacity: 0; } 50% { opacity: 1; } 100% { transform: scale(1); opacity: 1; } }
@keyframes smoothSlideUp { from { transform: translateY(12px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
@keyframes fadeInScale { from { transform: scale(0.95); opacity: 0; } to { transform: scale(1); opacity: 1; } }
@keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.05); } }
@keyframes notificationPulse { 0% { transform: scale(1); box-shadow: 0 0 0 0 rgba(226,89,56,0.7); } 70% { transform: scale(1.05); box-shadow: 0 0 0 20px rgba(226,89,56,0); } 100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(226,89,56,0); } }
.flash-banner { animation: flash 2s infinite; }
.slide-up { animation: slideUp 0.4s ease-out; }
.slide-right { animation: slideRight 0.3s cubic-bezier(0.16, 1, 0.3, 1); }
.toast-anim { animation: toastSlide 3s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
.smooth-transition { transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); }
.hover-lift:hover { transform: translateY(-3px); box-shadow: 0 12px 24px rgba(0, 0, 0, 0.12) !important; }
.scale-bounce { animation: scaleInBounce 0.5s cubic-bezier(0.34, 1.56, 0.64, 1); }
.smooth-slide-up { animation: smoothSlideUp 0.4s cubic-bezier(0.34, 1.56, 0.64, 1); }
.fade-scale { animation: fadeInScale 0.3s ease-out; }
.pulse { animation: pulse 2s ease-in-out infinite; }
.notification-pulse { animation: notificationPulse 2s ease-in-out infinite; }
.dark-theme { filter: invert(0.92) hue-rotate(180deg); background: #111; min-height: 100vh; }
.desktop-menu { display: grid; grid-template-columns: repeat(auto-fill, minmax(340px, 1fr)); column-gap: 24px; }
.desktop-menu > * { grid-column: 1 / -1; }
.desktop-menu > .smooth-slide-up { grid-column: auto; }
.dark-theme img, .dark-theme .keep-color { filter: invert(1) hue-rotate(180deg); }
@media print {
  .app-content { display: none !important; }
  .print-area { display: block !important; color: #000; font-family: 'JetBrains Mono', monospace; filter: none !important; }
  @page { margin: 0; }
  body { background: #fff; margin: 0; padding: 0; }
}
`;

const COLORS = {
  ink: "#1A1A1A", paper: "#FAFAF8", paper2: "#F0EFEB",
  copper: "#E25938", copperDark: "#C1442D", copperLight: "#F5E8E3",
  rust: "#C0392B", sage: "#4A7C59", sageDark: "#2F5C3F", sageLight: "#E8F0EB",
  gold: "#D4A574", line: "#E8E6DC", text: "#3C3C3C", textLight: "#8A8375",
  success: "#10B981", error: "#EF4444", warning: "#FF9800", info: "#3B82F6",
  google: "#4285F4", razorpay: "#0B4F6C", phonepe: "#5F259F"
};

const RESTAURANT = {
  name: "Eat & Park Restaurant", full: "Eat & Park Restaurant", tagline: "A Premium Family Restaurant",
  address: "Girja More, Ara – Buxar Main Road, Pakri, Ara",
  phones: ["7303267750", "8271918062"], whatsapp: "917303267750", upiId: "7303267750-5@ybl", gstin: import.meta.env.VITE_GSTIN || ""
};

const GOOGLE_PLACE_ID = "ChIJc8jv-j9fjTkRYFQLM7KK1aA";
const GOOGLE_REVIEW_URL = `https://search.google.com/local/writereview?placeid=${GOOGLE_PLACE_ID}`;

const RAZORPAY_KEY = import.meta.env.VITE_RAZORPAY_KEY || "YOUR_RAZORPAY_KEY_ID";
const PHONEPE_MERCHANT_ID = import.meta.env.VITE_PHONEPE_MERCHANT_ID || "YOUR_MERCHANT_ID";

const CATEGORIES = [
  "Thali",
  "Mutton, Fish & Egg",
  "Chicken Curries",
  "Tandoor",
  "Biryani & Rice",
  "Paneer & Mushroom",
  "Dal, Roti & Chole",
  "Soya Chaap",
  "Chinese",
  "Momos & Rolls",
  "Pizza, Burgers & More",
  "Maggi, Corn & Fries",
  "Soups",
  "Shakes & Drinks",
  "Desserts",
  "Combos"
];

const VEG = COLORS.sage; const NONVEG = COLORS.rust;

// ==
// 2. LOYALTY SYSTEM
// ==

const LOYALTY_TIERS = [
  { name: 'Bronze', points: 0, discount: 0.05, emoji: '🥉', color: '#CD7F32' },
  { name: 'Silver', points: 500, discount: 0.10, emoji: '🥈', color: '#C0C0C0' },
  { name: 'Gold', points: 1000, discount: 0.15, emoji: '🥇', color: '#FFD700' },
  { name: 'Platinum', points: 2000, discount: 0.25, emoji: '💎', color: '#E5E4E2' }
];

function getLoyaltyTier(points) {
  let tier = LOYALTY_TIERS[0];
  for (const t of LOYALTY_TIERS) if (points >= t.points) tier = t;
  return tier;
}

// ==
// 3. UTILITY FUNCTIONS
// ==

function uid(prefix) { return prefix + Date.now().toString(36).slice(-5) + Math.random().toString(36).slice(2, 8) + Math.random().toString(36).slice(2, 6); }
function escapeHtml(s) {
  return String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function inr(n) {
  const num = Number(n);
  if (!Number.isFinite(num)) return "₹0";
  return "₹" + num.toLocaleString("en-IN");
}
const isWalkIn = (s) => /^walk-?in$/i.test(String(s || "").trim());
const getBaseKots = (o) => (o.kots?.length ? o.kots : [{ id: uid("kot"), kotNumber: 1, items: o.items || [], createdAt: o.createdAt, status: o.status }])
  .map(k => (k.status === "new" && o.status !== "new" ? { ...k, status: o.status } : k));
const getNextKotNo = (o) => Math.max(...getBaseKots(o).map(k => k.kotNumber || 1)) + 1;

// Ek hi jagah se order total (coupon + loyalty + delivery sab included)
function getOrderTotal(o) {
  const hasRunning = (o?.kots || []).some(k => k.isRunning);
  // If finalTotal is trusted (no running KOT or bill was manually edited), use it.
  if (Number.isFinite(o?.finalTotal) && (!hasRunning || o?.billEditedAt)) return o.finalTotal;
  // Otherwise compute from items. NOTE: items array already includes running KOT items,
  // and runningPatch() updates finalTotal only when billEditedAt is set — so no double count.
  const sub = (o?.items || []).reduce((s, it) => s + it.price * it.qty, 0);
  const coupon = Math.round((sub * (o?.discount || 0)) / 100);
  return Math.max(0, sub - coupon - (o?.loyaltyDiscount || 0)) + (o?.deliveryFee || 0);
}

// Firestore doc ko safe shape deta hai (purane/adhure docs se crash nahi hoga)
const normOrder = HX.normOrder;
const normOrderLegacy = (d) => {
  const o = { id: d.id, ...d.data() };
  if (!Array.isArray(o.items)) o.items = [];
  if (!o.customer) o.customer = { name: "", phone: "" };
  return o;
};

// Running KOT aane par total / paid status theek karta hai
const runningPatch = (o, added) => {
  const addT = added.reduce((s, it) => s + it.price * it.qty, 0);
  const p = {};
  if (o.billEditedAt) {
    const g = Number(o.gstRate) || 0;
    p.finalTotal = Math.round((Number(o.finalTotal) || 0) + addT * (1 - (Number(o.billDiscountPct) || 0) / 100) * (1 + g / 100));
    p.subtotal = (Number(o.subtotal) || 0) + addT;
  }
  if (o.paid) { p.paid = false; p.paymentStatus = "pending"; }
  return p;
};

const patchAt = (list, idx, patch) => list.map((x, i) => (i === idx ? { ...x, ...patch } : x));

// Agar bill khulne ke baad order me naya KOT/item aa gaya to save rok do
async function guardedOrderUpdate(base, patch) {
  const ref = doc(db, "orders", base.id);
  await runTransaction(db, async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists()) throw new Error("Order nahi mila");
    const cur = snap.data();
    if ((cur.items || []).length !== (base.items || []).length || (cur.kots || []).length !== (base.kots || []).length) {
      throw new Error("Ye order kisi aur ne abhi badla hai (naya KOT/item). Bill band karke dobara kholo.");
    }
    tx.update(ref, patch);
  });
}


const DEMO_OTP = import.meta.env.VITE_DEMO_OTP === "true";
function timeAgo(ts) { const s = Math.floor((Date.now() - ts) / 1000); if (s < 60) return s + "s ago"; const m = Math.floor(s / 60); if (m < 60) return m + "m ago"; return Math.floor(m / 60) + "h ago"; }
const toLocalISODate = HX.toLocalISODate;
function toLocalISODateLegacy(timestamp) { const d = new Date(timestamp); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().split('T')[0]; }

function getEstimatedTime(items, menu = []) {
  if (!items || items.length === 0) return 5;
  const maxTime = Math.max(...items.map(it => { 
    const item = menu.find(m => m.id === it.itemId); 
    return PREP_TIME_ESTIMATES[item?.category || "Fun Food"] || 15; 
  }));
  return (Number.isFinite(maxTime) ? maxTime : 15) + 2;
}

function getOrderProgress(status) {
  if (status === 'served' || status === 'delivered' || status === 'completed') return 100;
  if (status === 'out_for_delivery') return 90;
  if (status === 'ready') return 70;
  if (status === 'preparing') return 40;
  if (status === 'new') return 15;
  return 0;
}

// Cart helpers — Flash sale / Combo price override handle karte hain
function getCartQty(cartEntry) {
  if (!cartEntry) return 0;
  if (typeof cartEntry === 'number') return cartEntry;
  return cartEntry.qty || 0;
}

function getCartLineTotal(cartEntry, menuItem) {
  if (!cartEntry || !menuItem) return 0;
  const price = cartEntry.priceOverride ?? menuItem.price ?? 0;
  const _q = getCartQty(cartEntry);
  if (cartEntry.priceOverride == null) return price * _q;
  const _cap = Math.min(_q, cartEntry.ovQty ?? _q);
  return price * _cap + (menuItem.price ?? 0) * (_q - _cap);
}

function getSmartSuggestionPool(menu, cart) {
  const hour = new Date().getHours();
  let cats;
  if (hour < 11) cats = ["Shakes & Drinks", "Momos & Rolls"];
  else if (hour < 15) cats = ["Biryani & Rice", "Thali", "Dal, Roti & Chole"];
  else if (hour < 18) cats = ["Maggi, Corn & Fries", "Shakes & Drinks", "Momos & Rolls"];
  else cats = ["Tandoor", "Chinese", "Paneer & Mushroom"];
  return menu.filter(m => cats.includes(m.category) && m.available && !cart[m.id]);
}
function getSmartSuggestionPoolOld(menu, cart) {
  const hour = new Date().getHours();
  let pool = [];
  if (hour < 11) pool = menu.filter(m => m.category.includes("Tea") || m.category.includes("Bread"));
  else if (hour < 13) pool = menu.filter(m => m.category.includes("Biryani") || m.category.includes("Pulao"));
  else if (hour < 17) pool = menu.filter(m => m.category.includes("Snacks") || m.category.includes("Drinks"));
  else pool = menu.filter(m => m.category.includes("Tandoori") || m.category.includes("Mains"));
  return pool.filter(m => m.available && !cart[m.id]);
}

const PREP_TIME_ESTIMATES = {
  "Thali": 20,
  "Mutton, Fish & Egg": 30,
  "Chicken Curries": 25,
  "Tandoor": 20,
  "Biryani & Rice": 25,
  "Paneer & Mushroom": 20,
  "Dal, Roti & Chole": 12,
  "Soya Chaap": 18,
  "Chinese": 15,
  "Momos & Rolls": 12,
  "Pizza, Burgers & More": 15,
  "Maggi, Corn & Fries": 8,
  "Soups": 8,
  "Shakes & Drinks": 5,
  "Desserts": 5,
  "Combos": 15,
  // Fallback for old categories
  "Drinks": 3,
  "Fun Food": 10,
  "Chinese Starter": 12,
  "Tandoori": 20,
  "Biryani & Thali": 25
};const STATUS_FLOW = ["new", "preparing", "ready", "out_for_delivery", "served"];
const STATUS_LABEL = { new: "New", preparing: "Preparing", ready: "Ready", served: "Served" };
const STATUS_COLOR = { new: COLORS.rust, preparing: COLORS.copper, ready: COLORS.sage, served: "#8A8375" };

const TOAST_CONFIG = {
  success: { duration: 2200, bg: COLORS.success, icon: "✅" },
  error: { duration: 4500, bg: COLORS.error, icon: "❌" },
  info: { duration: 3000, bg: COLORS.ink, icon: "ℹ️" },
  reward: { duration: 5000, bg: COLORS.gold, icon: "🎁" },
  warning: { duration: 4000, bg: COLORS.warning, icon: "⚠️" },
  order: { duration: 6000, bg: COLORS.copper, icon: "🛎️" }
};

const EMPTY_STATES = {
  veg_filtered: { icon: "🥬", title: "No vegetarian options here", subtitle: "Try 'All Items' or check our Paneer & Mushroom section!" },
  search_no_results: { icon: "🔍", title: "Dish not found", subtitle: "Try searching 'paneer', 'chicken', 'biryani', or 'tandoori'" },
  category_empty: { icon: "📂", title: "This category is empty", subtitle: "Check out our bestsellers in Fun Food or Tandoori!" }
};

// ==
// 4. REUSABLE COMPONENTS
// ==

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  componentDidCatch(error, info) {
    tryRecover(arguments[0]);
    console.error('🔴 ErrorBoundary caught:', error);
    console.error('🔴 Component Stack:', info.componentStack);
    this.setState({ error, errorInfo: info });
  }
  render() {
    if (this.state.hasError && this.props.compact) {
      return (
        <div style={{ position: "fixed", inset: 0, zIndex: 400, background: "rgba(0,0,0,0.7)", display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
          <div style={{ background: "#fff", borderRadius: 16, padding: 20, maxWidth: 320, textAlign: "center" }}>
            <div style={{ fontSize: 40 }}>⚠️</div>
            <div style={{ fontWeight: 800, margin: "8px 0 14px" }}>Ye screen me dikkat aayi. Band karke dobara kholo.</div>
            <button onClick={() => { this.setState({ hasError: false, error: null, errorInfo: null }); if (this.props.onReset) this.props.onReset(); }} style={{ background: COLORS.ink, color: "#fff", border: "none", padding: "10px 24px", borderRadius: 10, fontWeight: 800, cursor: "pointer" }}>Theek hai</button>
          </div>
        </div>
      );
    }
    if (this.state.hasError) {
      return (
        <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', padding: 20 }}>
          <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>😅</div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 'bold', color: COLORS.ink, marginBottom: '0.5rem' }}>Something went wrong</h2>
          <pre style={{ background: '#f5f5f5', padding: 16, borderRadius: 8, maxWidth: 600, overflow: 'auto', fontSize: 12, color: '#c00', marginBottom: 16, whiteSpace: 'pre-wrap' }}>
            {this.state.error?.toString()}
            {'\n\n'}
            {this.state.errorInfo?.componentStack}
          </pre>
          <button onClick={() => { try { localStorage.removeItem('eatpark_cart'); } catch (e) {} window.location.reload(); }} style={{ background: COLORS.copper, color: '#fff', border: 'none', padding: '10px 20px', borderRadius: 8, fontWeight: 'bold', cursor: 'pointer' }}>Clear Cache & Refresh</button>
          <button onClick={() => this.setState({ hasError: false, error: null, errorInfo: null })} style={{ background: COLORS.ink, color: '#fff', border: 'none', padding: '10px 20px', borderRadius: 8, fontWeight: 'bold', cursor: 'pointer', marginTop: 10 }}>🔄 Try Again</button>
          <button onClick={() => this.setState({ hasError: false, error: null, errorInfo: null })} style={{ background: COLORS.ink, color: '#fff', border: 'none', padding: '10px 20px', borderRadius: 8, fontWeight: 'bold', cursor: 'pointer', marginTop: 10 }}>🔄 Try Again</button>
        </div>
      );
    }
    return this.props.children;
  }
}

const VegDot = memo(({ veg }) => {
  const c = veg ? VEG : NONVEG;
  return <span role="img" aria-label={veg ? "Vegetarian" : "Non-vegetarian"} style={{ width: 14, height: 14, border: `1.5px solid ${c}`, display: "inline-flex", alignItems: "center", justifyContent: "center", flexShrink: 0, borderRadius: 4 }}><span style={{ width: 6, height: 6, borderRadius: "50%", background: c }} /></span>;
});

const Badge = memo(({ children, color }) => (
  <span style={{ background: color, color: "#fff", fontFamily: "'JetBrains Mono', monospace", fontSize: 11, letterSpacing: "0.06em", textTransform: "uppercase", padding: "5px 10px", borderRadius: 999, fontWeight: 700, display: "inline-block" }}>{children}</span>
));

const Stepper = memo(({ qty, onChange }) => {
  const btnStyle = { width: 28, height: 28, borderRadius: "50%", border: `1.5px solid ${COLORS.copper}`, background: "transparent", color: COLORS.copper, fontSize: 18, lineHeight: 1, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", transition: "all 0.2s ease" };
  return <div style={{ display: "flex", alignItems: "center", gap: 10 }}><button onClick={() => onChange(Math.max(0, qty - 1))} style={btnStyle}>−</button><span style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, minWidth: 16, textAlign: "center", fontSize: 15 }}>{qty}</span><button onClick={() => onChange(qty + 1)} style={btnStyle}>+</button></div>;
});

const AddBtnStepper = memo(({ qty, onChange, available }) => {
  if (!available) return <div style={{ color: COLORS.rust, background: COLORS.paper2, borderRadius: 8, fontWeight: 700, fontSize: 11, padding: "6px 10px", textAlign: "center", width: 80, boxSizing: "border-box" }}>Out of stock</div>;
  if (!qty) return <button onClick={() => onChange(1)} style={{ color: COLORS.sage, background: "#fff", border: `2px solid ${COLORS.sage}`, borderRadius: 8, fontWeight: 800, fontSize: 12, padding: "6px 16px", cursor: "pointer", width: 80, boxShadow: "0 4px 12px rgba(74,124,89,0.15)" }} className="smooth-transition hover-lift">ADD</button>;
  return <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", width: 80, padding: "4px", background: "#fff", border: `2px solid ${COLORS.sage}`, borderRadius: 8 }}><button onClick={() => onChange(Math.max(0, qty - 1))} style={{ width: 22, height: 22, border: "none", color: COLORS.sage, background: "transparent", fontSize: 18, cursor: "pointer" }}>−</button><span style={{ fontWeight: 800, fontSize: 14, color: COLORS.sage }}>{qty}</span><button onClick={() => onChange(qty + 1)} style={{ width: 22, height: 22, border: "none", color: COLORS.sage, background: "transparent", fontSize: 18, cursor: "pointer" }}>+</button></div>;
});

const SearchBar = memo(({ value, onChange, placeholder = "Search menu..." }) => {
  const timeoutRef = useRef(null);
  const [localValue, setLocalValue] = useState(value);
  useEffect(() => { setLocalValue(value); }, [value]);
  const handleChange = (e) => {
    const q = e.target.value;
    setLocalValue(q);
    clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => onChange(q), 250);
  };
  return (
    <div style={{ position: "relative", flex: 1 }}>
      <input type="text" value={localValue} onChange={handleChange} placeholder={placeholder} className="keep-color"
        style={{ padding: "12px 16px 12px 42px", border: `1.5px solid ${COLORS.line}`, borderRadius: 12, fontSize: 16, width: "100%", boxSizing: "border-box", background: "#fff", color: COLORS.ink }} />
      <span style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", fontSize: 18, color: COLORS.textLight }}>🔍</span>
      {localValue && (<button onClick={() => { setLocalValue(""); onChange(""); }} style={{ position: "absolute", right: 12, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", fontSize: 18, color: COLORS.textLight, padding: "4px 8px" }}>✕</button>)}
    </div>
  );
});

const Toast = memo(({ message, type = 'info' }) => {
  const config = TOAST_CONFIG[type] || TOAST_CONFIG.info;
  return (
    <div className="toast-anim" role="status" style={{ position: 'fixed', bottom: 40, left: '50%', transform: 'translateX(-50%)', background: config.bg, color: '#fff', padding: '16px 28px', borderRadius: 30, boxShadow: `0 12px 28px ${config.bg}66`, zIndex: 100, fontWeight: 700, fontSize: 15, display: 'flex', alignItems: 'center', gap: 12 }}>
      <span style={{ fontSize: 18 }}>{config.icon}</span><span>{message}</span>
    </div>
  );
});

const ModalHeader = memo(({ title, onClose }) => (
  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 24, borderBottom: `1px solid ${COLORS.line}`, paddingBottom: 16 }}>
    <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 24, fontWeight: 700 }}>{title}</div>
    <button onClick={onClose} style={{ background: "rgba(0,0,0,0.05)", border: "none", borderRadius: "50%", width: 36, height: 36, cursor: "pointer", fontSize: 18 }}>✕</button>
  </div>
));

const StatCard = memo(({ label, value, icon, color }) => (
  <div style={{ background: "#fff", border: `1.5px solid ${COLORS.line}`, borderRadius: 18, padding: "24px 20px", boxShadow: "0 8px 24px rgba(0,0,0,0.04)" }} className="smooth-transition hover-lift">
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}><div style={{ fontSize: 13, color: COLORS.textLight, textTransform: "uppercase", fontWeight: 800, letterSpacing: "0.05em" }}>{label}</div><span style={{ fontSize: 28 }}>{icon}</span></div>
    <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 32, fontWeight: 800, color: color }}>{value}</div>
  </div>
));

const SidebarBtn = memo(({ icon, text, onClick, highlight }) => (
  <button onClick={onClick} style={{ display: "flex", alignItems: "center", gap: 16, padding: "14px 20px", borderRadius: 14, background: highlight ? COLORS.copperLight : COLORS.paper, border: highlight ? `1.5px solid ${COLORS.copper}` : `1px solid ${COLORS.line}`, color: highlight ? COLORS.copperDark : COLORS.ink, fontSize: 15, fontWeight: 700, cursor: "pointer", textAlign: "left", width: '100%' }}>
    <span style={{ fontSize: 20 }}>{icon}</span><span>{text}</span>
  </button>
));

const ComboCard = memo(({ combo, onAdd }) => {
  if (!combo.active) return null;
  return (
    <div style={{ background: '#fff', borderRadius: 12, border: `2px solid ${COLORS.gold}`, padding: 16 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <span style={{ fontSize: 32 }}>{combo.image}</span>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 800, fontSize: 16, color: COLORS.ink }}>{combo.name}</div>
          <ul style={{ fontSize: 12, color: COLORS.textLight, margin: '4px 0', paddingLeft: 16 }}>
            {combo.items.map(item => <li key={item.id}>{item.name} × {item.quantity}</li>)}
          </ul>
          <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginTop: 4 }}>
            <span style={{ fontWeight: 700, color: COLORS.copper }}>₹{combo.finalPrice}</span>
            <span style={{ textDecoration: 'line-through', fontSize: 12, color: COLORS.textLight }}>₹{combo.totalPrice}</span>
            <span style={{ background: COLORS.copper, color: '#fff', padding: '2px 8px', borderRadius: 20, fontSize: 11, fontWeight: 700 }}>{combo.discount}% OFF</span>
          </div>
        </div>
        <button onClick={onAdd} style={{ background: COLORS.sage, color: '#fff', border: 'none', padding: '8px 16px', borderRadius: 8, fontWeight: 700, cursor: 'pointer' }}>Add Combo</button>
      </div>
    </div>
  );
});

const FlashSaleItem = memo(({ item, onAdd }) => {
  if (!item.active || (item.stock != null && item.stock <= 0)) return null;
  return (
    <div style={{ background: '#fff', borderRadius: 12, border: `2px solid ${COLORS.error}`, padding: 12, minWidth: 150, flexShrink: 0 }}>
      <div style={{ fontSize: 20 }}>🔥</div>
      <div style={{ fontWeight: 700, fontSize: 14, color: COLORS.ink }}>{item.name}</div>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center', margin: '4px 0' }}>
        <span style={{ fontWeight: 800, color: COLORS.error }}>₹{item.discountPrice}</span>
        <span style={{ textDecoration: 'line-through', fontSize: 12, color: COLORS.textLight }}>₹{item.price}</span>
      </div>
      {item.stock != null && item.stock <= 5 && (<div style={{ fontSize: 11, color: COLORS.error, fontWeight: 700, marginBottom: 4 }}>Only {item.stock} left!</div>)}
      <button onClick={onAdd} style={{ background: COLORS.error, color: '#fff', border: 'none', padding: '4px 12px', borderRadius: 6, fontWeight: 700, width: '100%', cursor: 'pointer' }}>Add</button>
    </div>
  );
});

// ==
// 5. CUSTOM HOOKS
// ==
function useLiveNow(intervalMs = 30000) {
  const [, forceTick] = useState(0);
  useEffect(() => {
    const t = setInterval(() => forceTick(x => x + 1), intervalMs);
    return () => clearInterval(t);
  }, [intervalMs]);
  // Returns nothing on purpose — just forces a re-render every intervalMs.
  // Callers use this to refresh relative timestamps like timeAgo().
}
const useLocalStorage = (key, initialValue) => {
  const [storedValue, setStoredValue] = useState(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) { return initialValue; }
  });
  useEffect(() => {
    try { window.localStorage.setItem(key, JSON.stringify(storedValue)); }
    catch (error) { console.error('useLocalStorage error:', error); }
  }, [key, storedValue]);
  return [storedValue, setStoredValue];
};

// 🖥️📱 APP / DESKTOP MODE
const VIEW_KEY = "eatpark_viewmode";
function useViewMode() {
  const read = () => {
    try {
      const saved = localStorage.getItem(VIEW_KEY);
      if (saved === "desktop" || saved === "app") return saved;
    } catch (e) {}
    return typeof window !== "undefined" && window.innerWidth >= 1024 ? "desktop" : "app";
  };
  const [mode, setModeState] = useState(read);
  useEffect(() => {
    const sync = () => setModeState(read());
    window.addEventListener("eatpark_viewmode_change", sync);
    return () => window.removeEventListener("eatpark_viewmode_change", sync);
  }, []);
  const setMode = useCallback((m) => {
    try { localStorage.setItem(VIEW_KEY, m); } catch (e) {}
    window.dispatchEvent(new Event("eatpark_viewmode_change"));
  }, []);
  return [mode, setMode];
}

// 📌 ADMIN PRESETS (Firebase: settings/presets) — waiters, customers, notes, discount, GST
const DEFAULT_PRESETS = { waiters: [], notes: [], discounts: [], gstRates: [], customers: [] };
function usePresets() {
  const [presets, setPresetsState] = useState(() => {
    try { return { ...DEFAULT_PRESETS, ...JSON.parse(localStorage.getItem("eatpark_presets") || "{}") }; }
    catch (e) { return DEFAULT_PRESETS; }
  });
  useEffect(() => {
    const unsub = onSnapshot(doc(db, "settings", "presets"), (snap) => {
      if (snap.exists()) {
        const d = { ...DEFAULT_PRESETS, ...snap.data() };
        setPresetsState(d);
        try { localStorage.setItem("eatpark_presets", JSON.stringify(d)); } catch (e) {}
      }
    }, (err) => console.error("presets listener:", err));
    return () => unsub();
  }, []);
  const savePresets = async (next) => {
    setPresetsState(next);
    try { localStorage.setItem("eatpark_presets", JSON.stringify(next)); } catch (e) {}
    try { await setDoc(doc(db, "settings", "presets"), next); }
    catch (e) { console.error(e); alert("⚠️ Presets save nahi hue. Internet / Firebase rules check karo."); }
  };
  return [presets, savePresets];
}

const ViewModeToggle = memo(() => {
  const [mode, setMode] = useViewMode();
  const isDesktop = mode === "desktop";
  return (
    <button onClick={() => setMode(isDesktop ? "app" : "desktop")} title="App / Desktop mode badlo"
      style={{ background: COLORS.paper2, border: `1.5px solid ${COLORS.line}`, borderRadius: 12, padding: "8px 12px", cursor: "pointer", fontWeight: 700, fontSize: 13, marginLeft: 8, color: COLORS.ink }}>
      {isDesktop ? "📱 App Mode" : "🖥️ Desktop Mode"}
    </button>
  );
});

// 5 galat PIN ke baad 30 second lock
function usePinLockout(max = 5, lockMs = 30000) {
  const [fails, setFails] = useState(0);
  const [lockedUntil, setLockedUntil] = useState(0);
  return {
    isLocked: () => Date.now() < lockedUntil,
    secondsLeft: () => Math.max(0, Math.ceil((lockedUntil - Date.now()) / 1000)),
    registerFail: () => {
      const n = fails + 1;
      if (n >= max) { setLockedUntil(Date.now() + lockMs); setFails(0); } else setFails(n);
    },
    reset: () => setFails(0)
  };
}

const useLocalStorageOld = (key, initialValue) => {
  const [storedValue, setStoredValue] = useState(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      return initialValue;
    }
  });

  const setValue = useCallback((value) => {
    setStoredValue(prev => {
      try {
        const v = value instanceof Function ? value(prev) : value;
        window.localStorage.setItem(key, JSON.stringify(v));
        return v;
      } catch (error) {
        console.error('useLocalStorage error:', error);
        return prev;
      }
    });
  }, [key]);

  return [storedValue, setValue];
};

// ==
// 6. NOTIFICATION SOUND
// ==

const notificationAudio = new Audio("https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3");
notificationAudio.volume = 0.5;
// Notification Android pe crash na kare
const safeNotify = (title, opts) => { try { return new Notification(title, opts); } catch (e) { console.warn("Notification:", e); } };
// localStorage corrupt ho to bhi crash na ho
const safeJSON = (key, fallback) => { try { const v = JSON.parse(localStorage.getItem(key) || "null"); return v ?? fallback; } catch (e) { return fallback; } };
const safeSet = (key, val) => { try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) { console.error("localStorage:", e); } };
const playNotificationSound = () => {
  try { notificationAudio.currentTime = 0; notificationAudio.play().catch(e => console.log("Sound play error:", e)); } catch (e) { console.log("Sound error:", e); }
};
// 🔓 Audio unlock on first user interaction (browser autoplay fix)
if (typeof window !== 'undefined') {
  const unlockAudio = () => {
    notificationAudio.play().then(() => {
      notificationAudio.pause();
      notificationAudio.currentTime = 0;
    }).catch(() => {});
    document.removeEventListener('click', unlockAudio);
    document.removeEventListener('touchstart', unlockAudio);
  };
  document.addEventListener('click', unlockAudio);
  document.addEventListener('touchstart', unlockAudio);
}

// ==
// 7. MENU ITEM HELPER
// ==

const IMG = (id) => `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=400&q=80`;
const DEFAULT_IMG_ID = "1546069901-ba9599a7e63c";

const CATEGORY_IMG = [
  ["Thali", "1585937421612-70a008356fbe"], ["Mutton", "1604908176997-125f25cc6f3d"],
  ["Fish", "1604908176997-125f25cc6f3d"], ["Egg", "1604908176997-125f25cc6f3d"],
  ["Chicken", "1604908176997-125f25cc6f3d"], ["Tandoor", "1599487405702-3e28c42b9370"],
  ["Biryani", "1589302168068-964664d93cb0"], ["Rice", "1589302168068-964664d93cb0"],
  ["Paneer", "1631452180519-c014fe946bc0"], ["Mushroom", "1631452180519-c014fe946bc0"],
  ["Dal", "1626082927389-6cd097cdc6ec"], ["Roti", "1626082927389-6cd097cdc6ec"],
  ["Soya", "1626082895617-2c6ad36f568a"], ["Chinese", "1585032226651-759b368d7246"],
  ["Momos", "1534422298391-e4f8c172dddb"], ["Pizza", "1513104890138-7c749659a591"],
  ["Maggi", "1573080496219-bb080dd4f877"], ["Soups", "1547592180-85f173990554"],
  ["Shakes", "1513558161293-cdaf765ed2fd"], ["Desserts", "1551024506-0bccd828d307"],
  ["Combos", "1600891964092-4316c288032e"]
];

const DISH_IMG_RULES = [
  [/momo/i, "1563245372-f21724e3856d"],
  [/burger/i, "1568901346375-23c9450c58cd"],
  [/sandwich/i, "1528735602780-2552fd46c7af"],
  [/pizza/i, "1574071318508-1cdbab80d002"],
  [/pasta/i, "1621996346565-e3dbc646d9a9"],
  [/fries|potato/i, "1573080496219-bb080dd4f877"],
  [/maggi|noodles/i, "1612929633738-8fe44f7ec841"],
  [/mojito|nimbu|lime/i, "1551024709-8f23befc6f87"],
  [/coffee/i, "1461023058943-07fcbe16d735"],
  [/\btea\b/i, "1564890369478-c89ca6d9cde9"],
  [/shake/i, "1572490122747-3968b75cc699"],
  [/ice cream/i, "1563805042-7684c019e1cb"],
  [/biryani/i, "1589302168068-964664d93cb0"],
  [/fried rice|pulao/i, "1603133872878-684f208fb84b"],
  [/chicken.*butter|butter chicken/i, "1603894584373-5ac82b2ae398"],
  [/tikka|kabab|seekh|tangdi|murgh/i, "1567188040759-fb8a883dc6d8"],
  [/naan|roti|bhature/i, "1601050690597-df0568f70950"],
  [/^dal /i, "1546833999-b9f581a1996d"],
  [/fish/i, "1519708227418-c8fd9a32b7a2"],
  [/egg|omelette|bhurji/i, "1525351484163-7529414344d8"],
  [/salad/i, "1512621776951-a57141f2eefd"]
];

function categoryImage(category) {
  const c = String(category || "");
  const hit = CATEGORY_IMG.find(([k]) => c.includes(k));
  return IMG(hit ? hit[1] : DEFAULT_IMG_ID);
}
function dishImage(name, category) {
  const n = String(name || "");
  const hit = DISH_IMG_RULES.find(([re]) => re.test(n));
  return hit ? IMG(hit[1]) : "";
}
const GENERIC_IMAGES = new Set([IMG(DEFAULT_IMG_ID), ...CATEGORY_IMG.map(([, id]) => IMG(id))]);
const withDishImage = (m) => (!m.image || GENERIC_IMAGES.has(m.image) ? { ...m, image: dishImage(m.name, m.category) } : m);

function mi(id, name, price, category, veg, desc, portion, isBestseller = false, available = true, customImg = "") {
  return { id, name, desc: desc || "Freshly prepared with premium ingredients.", price, category, veg, available, image: customImg || dishImage(name, category), portion: portion || "", isBestseller };
}

// ==
// 8. LOYALTY PROGRESS
// ==

const LoyaltyProgress = memo(({ currentPoints, nextTier, loyaltyRules }) => {
  if (!nextTier) return null;
  const currentTierIndex = LOYALTY_TIERS.indexOf(nextTier) - 1;
  const previousTierPoints = currentTierIndex >= 0 ? LOYALTY_TIERS[currentTierIndex].points : 0;
  const pointsNeeded = nextTier.points - currentPoints;
  const progress = Math.min(((currentPoints - previousTierPoints) / (nextTier.points - previousTierPoints)) * 100, 100);
  return (
    <div style={{ marginTop: 8, padding: '10px 12px', background: '#fff', borderRadius: 10, border: `1px solid ${COLORS.line}` }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 4 }}>
        <span style={{ fontWeight: 600, color: COLORS.textLight }}>{nextTier.emoji} Next: {nextTier.name}</span>
        <span style={{ fontWeight: 700, color: pointsNeeded > 0 ? COLORS.copper : COLORS.success }}>{pointsNeeded > 0 ? `${pointsNeeded} away` : '🎉 Unlocked!'}</span>
      </div>
      <div style={{ width: '100%', height: 6, background: COLORS.paper2, borderRadius: 999, overflow: 'hidden' }}>
        <div style={{ width: `${Math.min(progress, 100)}%`, height: '100%', background: `linear-gradient(90deg, ${COLORS.gold}, ${nextTier.color || COLORS.sage})`, borderRadius: 999, transition: 'width 0.8s ease' }} />
      </div>
      {pointsNeeded > 0 && (<div style={{ fontSize: 11, color: COLORS.textLight, marginTop: 4 }}>💰 Spend ₹{Math.ceil(pointsNeeded * loyaltyRules.rate)} more</div>)}
    </div>
  );
});

// ==
// 9. CHAT BOX
// ==

const ChatBox = memo(({ orderId, customerId }) => {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const messagesRef = useMemo(() => collection(db, 'chats', orderId, 'messages'), [orderId]);
  useEffect(() => {
    try {
      const q = query(messagesRef, orderBy('timestamp', 'asc'));
      const unsub = onSnapshot(q, (snap) => {
        setMessages(snap.docs.map(doc => { const data = doc.data(); if (!data.timestamp) data.timestamp = Date.now(); return { id: doc.id, ...data }; }));
      });
      return unsub;
    } catch (e) { console.error('Chat error:', e); }
  }, [orderId, messagesRef]);
  const sendMessage = async () => {
    if (!newMessage.trim()) return;
    try {
      await addDoc(messagesRef, { text: newMessage, senderId: customerId, senderName: customerId === 'customer' ? 'Customer' : 'Restaurant', timestamp: serverTimestamp() });
      setNewMessage('');
    } catch (e) { console.error('Chat send error:', e); }
  };
  return (
    <div style={{ border: '1px solid #ddd', borderRadius: 8, padding: 12, background: '#fff' }}>
      <div style={{ maxHeight: 250, overflowY: 'auto', marginBottom: 8 }}>
        {messages.map((msg) => (
          <div key={msg.id} style={{ textAlign: msg.senderId === customerId ? 'right' : 'left', margin: '4px 0' }}>
            <span style={{ background: msg.senderId === customerId ? COLORS.copper : '#e9ecef', color: msg.senderId === customerId ? '#fff' : '#000', padding: '6px 12px', borderRadius: 12, display: 'inline-block', maxWidth: '80%' }}>{msg.text}</span>
          </div>
        ))}
      </div>
      <div style={{ display: 'flex', gap: 8 }}>
        <input value={newMessage} onChange={(e) => setNewMessage(e.target.value)} placeholder="Type a message..." style={{ flex: 1, padding: 8, border: '1px solid #ccc', borderRadius: 4 }} onKeyDown={(e) => e.key === 'Enter' && sendMessage()} />
        <button onClick={sendMessage} style={{ background: COLORS.copper, color: '#fff', border: 'none', padding: '8px 16px', borderRadius: 4, cursor: 'pointer' }}>Send</button>
      </div>
    </div>
  );
});

// ==
// 10. GOOGLE REVIEW BUTTON
// ==

const GoogleReviewButton = memo(({ variant = 'primary', size = 'md', showText = true }) => {
  const variants = {
    primary: { background: '#4285F4', color: '#fff', border: 'none' },
    sm: { background: '#4285F4', color: '#fff', border: 'none' }
  };
  const sizes = {
    sm: { padding: '4px 12px', fontSize: 11, borderRadius: 16 },
    md: { padding: '8px 18px', fontSize: 13, borderRadius: 20 },
    lg: { padding: '12px 24px', fontSize: 16, borderRadius: 24 }
  };
  return (
    <a href={GOOGLE_REVIEW_URL} target="_blank" rel="noopener noreferrer" style={{ display: 'inline-flex', alignItems: 'center', gap: 6, textDecoration: 'none', fontWeight: 700, cursor: 'pointer', ...variants[variant], ...sizes[size] }} className="smooth-transition hover-lift">
      <span style={{ fontSize: size === 'lg' ? 24 : size === 'sm' ? 14 : 18 }}>⭐</span>
      {showText && <span>Rate on Google</span>}
    </a>
  );
});

// ==
// 11. PAYMENT PROCESSING
// ==

const loadRazorpayScript = () => new Promise((resolve) => {
  if (window.Razorpay) { resolve(true); return; }
  const script = document.createElement('script');
  script.src = 'https://checkout.razorpay.com/v1/checkout.js';
  script.onload = () => resolve(true);
  script.onerror = () => resolve(false);
  document.body.appendChild(script);
});

// Success pe Razorpay response, cancel/fail pe null return karta hai
const processRazorpayPaymentLegacy = (amount, orderId, customerName, customerPhone) =>
  new Promise(async (resolve) => {
    if (!RAZORPAY_KEY || RAZORPAY_KEY.startsWith("YOUR_")) {
      alert("⚠️ Razorpay key configure nahi hai.");
      return resolve(null);
    }
    const loaded = await loadRazorpayScript();
    if (!loaded || !window.Razorpay) { alert("⚠️ Payment gateway load nahi hua."); return resolve(null); }
    const rzp = new window.Razorpay({
      key: RAZORPAY_KEY, amount: Math.round(amount * 100), currency: "INR",
      name: RESTAURANT.name, description: `Order #${orderId.slice(1, 5).toUpperCase()}`,
      prefill: { name: customerName, contact: customerPhone },
      theme: { color: COLORS.copper },
      handler: (response) => resolve(response),
      modal: { ondismiss: () => resolve(null) }
    });
    rzp.on('payment.failed', () => resolve(null));
    rzp.open();
  });

const processRazorpayPayment = async (amount, orderId, customerName, customerPhone) => {
  try {
    return await HX.payWithRazorpay({
      key: RAZORPAY_KEY, amount, orderId, name: RESTAURANT.name,
      desc: `Order #${orderId.slice(1, 5).toUpperCase()}`,
      prefill: { name: customerName, contact: customerPhone }, color: COLORS.copper
    });
  } catch (e) { alert("⚠️ " + (e.message || e)); return null; }
};
const loadRazorpayScriptOld = () => new Promise((resolve) => {
  const script = document.createElement('script');
  script.src = 'https://checkout.razorpay.com/v1/checkout.js';
  script.onload = () => resolve(true);
  script.onerror = () => resolve(false);
  document.body.appendChild(script);
});

const processRazorpayPaymentOld = async (amount, orderId, customerName, customerPhone) => {
  const loaded = await loadRazorpayScript();
  if (!loaded) { alert("⚠️ Payment gateway could not load."); return false; }
  const options = {
    key: RAZORPAY_KEY, amount: Math.round(amount * 100), currency: "INR",
    name: RESTAURANT.name, description: `Order #${orderId}`,
    prefill: { name: customerName, contact: customerPhone },
    theme: { color: COLORS.copper },
    handler: function (response) { console.log("Payment successful:", response); return true; }
  };
  const razorpay = new window.Razorpay(options);
  razorpay.open();
  return true;
};

// ==
// 12. KOT BADGE (V15 NEW)
// ==

const KotBadge = memo(({ kots }) => {
  const count = kots?.length || 1;
  if (count <= 1) return null;
  return (
    <span style={{ background: COLORS.info, color: "#fff", fontSize: 11, padding: "2px 8px", borderRadius: 10, fontWeight: 800, marginLeft: 6 }}>
      {count} KOTs
    </span>
  );
});

// ==
// 13. KITCHEN NOTIFICATION COLUMN (V15 NEW)
// ==

const KitchenNotificationColumn = memo(({ orders, selectedOrderId, onSelect }) => { useLiveNow(30000);
  const [open, setOpen] = useState(false);
  const newOrders = orders.filter(o => o.status === "new");
  const preparingOrders = orders.filter(o => o.status === "preparing");

  if (!open) {
    return (
      <button onClick={() => setOpen(true)} aria-label="Open notifications"
        style={{ position: "fixed", top: 90, right: 16, zIndex: 90, background: newOrders.length ? COLORS.copper : COLORS.ink, color: "#fff", border: "none", borderRadius: "50%", width: 52, height: 52, fontSize: 22, cursor: "pointer", boxShadow: "0 8px 24px rgba(0,0,0,0.25)" }}
        className={newOrders.length ? "notification-pulse" : ""}>
        🔔{newOrders.length > 0 && (
          <span style={{ position: "absolute", top: -4, right: -4, background: COLORS.error, color: "#fff", borderRadius: "50%", width: 22, height: 22, fontSize: 12, fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center" }}>{newOrders.length}</span>
        )}
      </button>
    );
  }

  return (
    <div style={{ position: "fixed", top: 90, right: 16, width: 240, maxHeight: "calc(100vh - 120px)", background: "#fff", border: `1.5px solid ${COLORS.line}`, borderRadius: 16, boxShadow: "0 12px 32px rgba(0,0,0,0.12)", zIndex: 90, display: "flex", flexDirection: "column", overflow: "hidden" }} className="slide-right">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "12px 14px", borderBottom: `1px solid ${COLORS.line}`, background: COLORS.paper }}>
        <span style={{ fontWeight: 800, fontSize: 13, textTransform: "uppercase", letterSpacing: 0.5 }}>🔔 Live Orders</span>
        <button onClick={() => setOpen(false)} style={{ background: "none", border: "none", fontSize: 18, cursor: "pointer", color: COLORS.textLight }}>✕</button>
      </div>
      <div style={{ overflowY: "auto", padding: 10, flex: 1 }}>
        {newOrders.length === 0 && preparingOrders.length === 0 && (
          <div style={{ textAlign: "center", padding: "24px 0", color: COLORS.textLight, fontSize: 12 }}>
            <div style={{ fontSize: 28, marginBottom: 6 }}>😌</div>All quiet
          </div>
        )}
        {newOrders.length > 0 && (
          <>
            <div style={{ fontSize: 10, fontWeight: 800, color: COLORS.copper, letterSpacing: 1, marginBottom: 6, textTransform: "uppercase" }}>🆕 New ({newOrders.length})</div>
            {newOrders.map(o => (
              <button key={o.id} onClick={() => onSelect(o.id)} style={{ width: "100%", textAlign: "left", background: selectedOrderId === o.id ? COLORS.copperLight : COLORS.paper, border: `1px solid ${selectedOrderId === o.id ? COLORS.copper : COLORS.line}`, borderRadius: 10, padding: "8px 10px", marginBottom: 6, cursor: "pointer", fontFamily: "inherit" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <strong style={{ fontSize: 13 }}>{o.orderType === "parcel" ? "🛍️" : `T${o.table}`}</strong>
                  <span style={{ fontSize: 10, color: COLORS.textLight }}>{timeAgo(o.createdAt)}</span>
                </div>
                <div style={{ fontSize: 11, color: COLORS.textLight, marginTop: 2 }}>
                  {o.items.length} item{o.items.length !== 1 ? "s" : ""}
                  {o.kots?.length > 1 && (<span style={{ marginLeft: 6, color: COLORS.info, fontWeight: 700 }}>+{o.kots.length - 1} KOT</span>)}
                </div>
              </button>
            ))}
          </>
        )}
        {preparingOrders.length > 0 && (
          <>
            <div style={{ fontSize: 10, fontWeight: 800, color: COLORS.sage, letterSpacing: 1, margin: "10px 0 6px", textTransform: "uppercase" }}>👨‍🍳 Cooking ({preparingOrders.length})</div>
            {preparingOrders.map(o => (
              <button key={o.id} onClick={() => onSelect(o.id)} style={{ width: "100%", textAlign: "left", background: selectedOrderId === o.id ? COLORS.sageLight : COLORS.paper, border: `1px solid ${selectedOrderId === o.id ? COLORS.sage : COLORS.line}`, borderRadius: 10, padding: "8px 10px", marginBottom: 6, cursor: "pointer", fontFamily: "inherit" }}>
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <strong style={{ fontSize: 13 }}>{o.orderType === "parcel" ? "🛍️" : `T${o.table}`}</strong>
                  <span style={{ fontSize: 10, color: COLORS.textLight }}>{timeAgo(o.createdAt)}</span>
                </div>
              </button>
            ))}
          </>
        )}
      </div>
    </div>
  );
});

// ==
// ==
// 13.5 AI ORDER MODAL (VOICE & TEXT)
// ==

function AIOrderModal({ menu, onOrderParsed, onClose }) {
  const [aiText, setAiText] = useState("");
  const [aiBusy, setAiBusy] = useState(false);
  const [aiErr, setAiErr] = useState("");
  const [listening, setListening] = useState(false);
  const recRef = useRef(null);

  const startMic = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      setAiErr("⚠️ Is browser me mic support nahi hai. Keyboard ka mic use karein.");
      return;
    }

    // Agar pehle se sun raha hai toh stop karein
    if (listening && recRef.current) {
      try {
        recRef.current.stop();
      } catch (err) {}
      setListening(false);
      return;
    }

    try {
      const r = new SR();
      r.lang = "hi-IN";
      r.interimResults = false;
      r.continuous = false;

      r.onstart = () => {
        setListening(true);
        setAiErr("");
      };

      r.onresult = (e) => {
        const transcript = Array.from(e.results)
          .map((res) => res[0].transcript)
          .join(" ");
        setAiText((prev) => (prev ? prev + " " : "") + transcript);
      };

      r.onerror = (e) => {
        setListening(false);
        if (e.error === "not-allowed") {
          setAiErr("⚠️ Mic permission blocked hai. Settings me allow karein.");
        } else if (e.error === "no-speech") {
          setAiErr("⚠️ Koi aawaz nahi suni gayi. Dobara bolein.");
        } else {
          setAiErr(`⚠️ Mic error: ${e.error || "Aawaz capture nahi hui"}`);
        }
      };

      r.onend = () => {
        setListening(false);
      };

      recRef.current = r;
      r.start();
    } catch (err) {
      setListening(false);
      setAiErr("⚠️ Mic start nahi ho paya. Dobara tap karein.");
    }
  };

  const runAi = async () => {
    const text = aiText.trim();
    if (!text || aiBusy) return;
    setAiBusy(true);
    setAiErr("");
    try {
      const r = await HX.fetchWithTimeout("/api/parse-order", {
        method: "POST",
        headers: { "Content-Type": "application/json", ...(auth.currentUser ? { Authorization: "Bearer " + (await auth.currentUser.getIdToken()) } : {}) },

        body: JSON.stringify({
          text,
          menu: (menu || [])
            .filter((m) => m.available)
            .map((m) => ({ id: m.id, name: m.name, portion: m.portion || "" })),
        }),
      });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || "AI processing fail ho gayi");
      onOrderParsed(HX.sanitizeAiLines(data, menu));
      onClose();
    } catch (e) {
      setAiErr("⚠️ " + (e.message || e));
    } finally {
      setAiBusy(false);
    }
  };


  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.65)", zIndex: 280, display: "flex", alignItems: "center", justifyContent: "center", padding: 14 }} onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} style={{ background: "#fff", borderRadius: 18, padding: 18, width: "100%", maxWidth: 390, display: "flex", flexDirection: "column", gap: 10 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ fontWeight: 800, fontSize: 18, fontFamily: "'Outfit', sans-serif" }}>🤖 AI Order</div>
          <button onClick={onClose} style={{ background: "none", border: "none", fontSize: 18, cursor: "pointer" }}>✕</button>
        </div>
        <div style={{ fontSize: 12, color: "#8A8375" }}>Bolo ya likho: "2 veg roll, 1 cold coffee"</div>
        <textarea
          rows={3}
          value={aiText}
          onChange={(e) => setAiText(e.target.value)}
          placeholder="Order yahan likhein ya mic se bolein..."
          style={{ width: "100%", padding: 10, borderRadius: 10, border: "1.5px solid #E8E6DC", boxSizing: "border-box", fontSize: 14, resize: "none" }}
        />
        <div style={{ display: "flex", gap: 8 }}>
          <button type="button" onClick={startMic} style={{ flex: 1, padding: 10, borderRadius: 10, background: listening ? "#C0392B" : "#FAFAF8", border: "1.5px solid #E8E6DC", fontWeight: 800, color: listening ? "#fff" : "#1A1A1A", cursor: "pointer" }}>
            {listening ? "⏹️ Ruko" : "🎤 Bolo"}
          </button>
          <button type="button" onClick={runAi} disabled={aiBusy || !aiText.trim()} style={{ flex: 1, padding: 10, borderRadius: 10, background: "#3B82F6", color: "#fff", border: "none", fontWeight: 800, cursor: "pointer", opacity: (aiBusy || !aiText.trim()) ? 0.6 : 1 }}>
            {aiBusy ? "⏳ Soch raha..." : "✨ Samjho"}
          </button>
        </div>
        {aiErr && <div style={{ color: "#EF4444", fontSize: 12, fontWeight: 700 }}>{aiErr}</div>}
      </div>
    </div>
  );
}

// ==
// 14. RUNNING ORDER MODAL (V15 NEW)
// ==

// ==

const RunningOrderModal = memo(({ order, menu, onConfirm, onClose }) => {
  const [additions, setAdditions] = useState({});
  const [search, setSearch] = useState("");
  const filtered = menu.filter(m => m.available && (!search.trim() || m.name.toLowerCase().includes(search.toLowerCase())));
  const itemsToAdd = Object.entries(additions).filter(([, q]) => q > 0);
  const addTotal = itemsToAdd.reduce((s, [id, q]) => { const m = menu.find(x => x.id === id); return s + (m ? m.price * q : 0); }, 0);

  const handleSetQty = (id, q) => { setAdditions(prev => { const next = { ...prev, [id]: q }; if (q <= 0) delete next[id]; return next; }); };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)", zIndex: 85, display: "flex", alignItems: "flex-end" }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} className="slide-up" style={{ background: "#fff", width: "100%", maxWidth: 480, margin: "0 auto", borderRadius: "24px 24px 0 0", padding: "20px", maxHeight: "85vh", overflowY: "auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16 }}>
          <div>
            <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 22, fontWeight: 800 }}>➕ Add Running Items</div>
            <div style={{ fontSize: 12, color: COLORS.textLight, marginTop: 2 }}>Order #{order.id.slice(1, 5).toUpperCase()} · New KOT #{Math.max(1, ...(order.kots || [{ kotNumber: 1 }]).map(k => k.kotNumber || 1)) + 1}</div>
          </div>
          <button onClick={onClose} style={{ background: "rgba(0,0,0,0.05)", border: "none", borderRadius: "50%", width: 36, height: 36, fontSize: 18, cursor: "pointer" }}>✕</button>
        </div>
        <SearchBar value={search} onChange={setSearch} placeholder="Search menu..." />
        <div style={{ marginTop: 16, maxHeight: "45vh", overflowY: "auto" }}>
          {filtered.map(item => {
            const qty = additions[item.id] || 0;
            return (
              <div key={item.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: `1px solid ${COLORS.line}` }}>
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 6 }}><VegDot veg={item.veg} /><strong style={{ fontSize: 14 }}>{item.name}</strong></div>
                  <div style={{ fontSize: 13, color: COLORS.copper, fontWeight: 700, marginTop: 2 }}>{inr(item.price)}</div>
                </div>
                <AddBtnStepper qty={qty} onChange={q => handleSetQty(item.id, q)} available={item.available} />
              </div>
            );
          })}
        </div>
        <div style={{ borderTop: `2px solid ${COLORS.line}`, paddingTop: 16, marginTop: 16 }}>
          <div style={{ display: "flex", justifyContent: "space-between", fontWeight: 800, fontSize: 17, marginBottom: 12 }}>
            <span>Additional Total</span><span style={{ color: COLORS.copper, fontFamily: "'JetBrains Mono', monospace" }}>{inr(addTotal)}</span>
          </div>
          <button disabled={itemsToAdd.length === 0}
            onClick={() => {
              if (itemsToAdd.length === 0) return;
              const newItems = itemsToAdd.map(([id, qty]) => { const m = menu.find(x => x.id === id); return { itemId: id, name: m.name, portion: m.portion || "", price: m.price, qty }; });
              onConfirm(newItems);
            }}
            style={{ width: "100%", padding: "16px", border: "none", borderRadius: 14, background: itemsToAdd.length ? COLORS.info : COLORS.paper2, color: itemsToAdd.length ? "#fff" : COLORS.textLight, fontWeight: 800, fontSize: 16, cursor: itemsToAdd.length ? "pointer" : "not-allowed" }}>
            🍳 Send KOT to Kitchen
          </button>
        </div>
      </div>
    </div>
  );
});
// ==
// 14.5 TABLE STATUS BOARD
// ==

const TableStatusBoard = memo(({ orders, tables = 12, onTableClick, onEmptyTableClick, showStats = true, compact = false, isDark = false }) => { useLiveNow(30000);
  const tableData = useMemo(() => {
    const activeOrders = (orders || []).filter(o =>
      o.orderType === "dine_in" &&
      o.status !== "cancelled" &&
      o.status !== "served" &&
      !o.paid
    );

    const map = {};
    for (let i = 1; i <= tables; i++) {
      map[i] = { table: i, order: null, status: "empty" };
    }

    [...activeOrders].sort((a, b) => a.createdAt - b.createdAt).forEach(o => {
      const t = Number(o.table);
      if (map[t]) {
        map[t].all = [...(map[t].all || []), o]; map[t].order = o;
        if (!map[t].all.some(x => x.status === "new" || x.status === "preparing")) map[t].status = "billing";
        else map[t].status = "occupied";
      }
    });

    return Object.values(map);
  }, [orders, tables]);

  const stats = useMemo(() => {
    const active = tableData.filter(t => t.order);
    const totalAmount = active.reduce((sum, t) => sum + (t.all || [t.order]).reduce((s, x) => s + getOrderTotal(x), 0), 0);
    return {
      occupied: active.length,
      empty: tables - active.length,
      running: totalAmount,
    };
  }, [tableData, tables]);
   
  const statusColors = {
    empty:    { bg: "#E8F5E9", border: "#4A7C59", label: "Empty",    emoji: "🟢" },
    occupied: { bg: "#FFEBEE", border: "#EF4444", label: "Occupied", emoji: "🔴" },
    billing:  { bg: "#FFF8E1", border: "#FF9800", label: "Billing",  emoji: "🟡" },
  };

  const formatTime = (ts) => {
    const s = Math.floor((Date.now() - ts) / 1000);
    const m = Math.floor(s / 60);
    if (m < 60) return `${m}m`;
    const h = Math.floor(m / 60);
    return `${h}h ${m % 60}m`;
  };

  if (compact) {
    return (
      <div style={{ background: '#fff', borderRadius: 12, border: `1px solid ${COLORS.line}`, padding: 12 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
          <div style={{ fontWeight: 800, fontSize: 13 }}>🍽️ Table Status</div>
          <div style={{ fontSize: 11, color: COLORS.textLight }}>
            <span style={{ color: COLORS.error, fontWeight: 700 }}>{stats.occupied}</span> occupied ·{' '}
            <span style={{ color: COLORS.sage, fontWeight: 700 }}>{stats.empty}</span> free
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10 }}>
          {tableData.map(t => {
            const c = statusColors[t.status];
            return (
              <button
                key={t.table}
                onClick={() => (t.order ? (onTableClick && onTableClick(t.order)) : (onEmptyTableClick && onEmptyTableClick(t.table)))}
                disabled={!t.order && !onEmptyTableClick}
                style={{
                  aspectRatio: '1', borderRadius: 14,
                  background: c.bg, border: `2.5px solid ${c.border}`,
                  fontWeight: 900, fontSize: 20, color: COLORS.ink,
                  cursor: (t.order || onEmptyTableClick) ? 'pointer' : 'default',
                  fontFamily: "'Outfit', sans-serif",
                  padding: 0,
                  display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 2,
                  boxShadow: '0 4px 10px rgba(0,0,0,0.08)'
                }}>
                <span style={{ fontSize: 11, opacity: 0.7 }}>{c.emoji}</span>
                <span>T-{t.table}</span>
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <div style={{ background: '#fff', borderRadius: 18, border: `1px solid ${COLORS.line}`, padding: 20, boxShadow: '0 4px 12px rgba(0,0,0,0.03)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, flexWrap: 'wrap', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ fontSize: 24 }}>🍽️</span>
          <div>
            <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 20, fontWeight: 800 }}>Table Status Board</div>
            <div style={{ fontSize: 12, color: COLORS.textLight, fontWeight: 600 }}>Live · {tables} tables</div>
          </div>
        </div>

        {showStats && (
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
            <div style={{ background: '#FFEBEE', border: `1px solid ${COLORS.error}`, borderRadius: 10, padding: '8px 14px', display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontSize: 18 }}>🔴</span>
              <div>
                <div style={{ fontSize: 10, color: COLORS.error, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 0.5 }}>Occupied</div>
                <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 16, fontWeight: 800, color: COLORS.error }}>{stats.occupied}</div>
              </div>
            </div>
            <div style={{ background: '#E8F5E9', border: `1px solid ${COLORS.sage}`, borderRadius: 10, padding: '8px 14px', display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontSize: 18 }}>🟢</span>
              <div>
                <div style={{ fontSize: 10, color: COLORS.sageDark, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 0.5 }}>Free</div>
                <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 16, fontWeight: 800, color: COLORS.sageDark }}>{stats.empty}</div>
              </div>
            </div>
            <div style={{ background: '#F0EFEB', border: `1px solid ${COLORS.line}`, borderRadius: 10, padding: '8px 14px', display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontSize: 18 }}>💰</span>
              <div>
                <div style={{ fontSize: 10, color: COLORS.textLight, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 0.5 }}>Running</div>
                <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 16, fontWeight: 800, color: COLORS.copper }}>{inr(stats.running)}</div>
              </div>
            </div>
          </div>
        )}
      </div>

      <div style={{ display: 'flex', gap: 16, marginBottom: 16, fontSize: 11, fontWeight: 700, color: COLORS.textLight, flexWrap: 'wrap' }}>
        <span><span style={{ color: COLORS.sage }}>●</span> Empty</span>
        <span><span style={{ color: COLORS.error }}>●</span> Occupied</span>
        <span><span style={{ color: '#E65100' }}>●</span> Billing / Ready</span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: 12 }}>
        {tableData.map(t => {
          const c = statusColors[t.status];
          const o = t.order;
          const total = o ? (t.all || [o]).reduce((s, x) => s + getOrderTotal(x), 0) : 0;
const itemCount = o ? (t.all || [o]).reduce((n, x) => n + x.items.reduce((sum, i) => sum + i.qty, 0), 0) : 0;

          return (
            <button
              key={t.table}
              onClick={() => (o ? (onTableClick && onTableClick(o)) : (onEmptyTableClick && onEmptyTableClick(t.table)))}
              style={{
                background: c.bg,
                border: `2px solid ${c.border}`,
                borderRadius: 14, padding: 14,
                cursor: 'pointer',
                textAlign: 'left',
                fontFamily: 'inherit',
                transition: 'all 0.2s ease',
                position: 'relative',
                minHeight: 120,
                display: 'flex', flexDirection: 'column', justifyContent: 'space-between'
              }}
              className={o ? 'hover-lift' : ''}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 26, fontWeight: 800, color: COLORS.ink, lineHeight: 1 }}>
                  {t.table}
                </div>
                <span style={{ fontSize: 16 }}>{c.emoji}</span>
              </div>

              {!o ? (
                <div style={{ fontSize: 11, color: COLORS.textLight, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                  Available
                </div>
              ) : (
                <>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6, fontSize: 10, color: COLORS.textLight, fontWeight: 700 }}>
                    <span>{o.waiter ? `🧑‍🍳 ${o.waiter}` : '🧑‍🍳 —'}</span>
                    <span>⏱️ {formatTime(o.createdAt)}</span>
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                    <div style={{ fontSize: 11, color: COLORS.textLight, fontWeight: 700 }}>
                      #{o.id.slice(1, 5).toUpperCase()}
                    </div>
                    <div style={{ fontSize: 10, color: COLORS.textLight, fontWeight: 700 }}>
                      {itemCount} item{itemCount !== 1 ? 's' : ''}
                    </div>
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginTop: 'auto' }}>
                    <div>
                      <div style={{ fontSize: 9, color: COLORS.textLight, fontWeight: 800, textTransform: 'uppercase' }}>Total</div>
                      <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 15, fontWeight: 800, color: COLORS.copper }}>
                        {inr(total)}
                      </div>
                    </div>
                    {o.status === "ready" && (
                      <div style={{ background: '#E65100', color: '#fff', fontSize: 9, fontWeight: 800, padding: '3px 8px', borderRadius: 6, textTransform: 'uppercase' }}>
                        Ready
                      </div>
                    )}
                    {(o.status === "new" || o.status === "preparing") && (
                      <div style={{ background: COLORS.info, color: '#fff', fontSize: 9, fontWeight: 800, padding: '3px 8px', borderRadius: 6, textTransform: 'uppercase' }}>
                        {o.status === "new" ? "New" : "Cooking"}
                      </div>
                    )}
                  </div>
                </>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
});

// ==)
// 15. WAITER ORDER PANEL (V15 NEW)
// ==

const WaiterOrderPanel = memo(({ menu, table, setTable, onSubmit, onClose, onAddMoreItems, orders, setMenuState, categories }) => {
  const [cart, setCart] = useState({});
  const [search, setSearch] = useState("");
  const [waiterName, setWaiterName] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [notes, setNotes] = useState("");
  const [orderMode, setOrderMode] = useState("dine_in"); 
  const [placedOrder, setPlacedOrder] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showAiModal, setShowAiModal] = useState(false);


  // 🆕 Add Menu Item State
  const [showAddItem, setShowAddItem] = useState(false);
  const [newItem, setNewItem] = useState({
    name: "",
    price: "",
    category: categories[0] || "Thali",
    veg: true,
    portion: "",
    desc: "",
    image: "",
    isBestseller: false
  });
  const [isSavingItem, setIsSavingItem] = useState(false);

  const filtered = menu.filter(m => m.available && (!search.trim() || m.name.toLowerCase().includes(search.toLowerCase())));
  const cartItems = Object.entries(cart).filter(([, e]) => getCartQty(e) > 0);
  const cartCount = cartItems.reduce((s, [, e]) => s + getCartQty(e), 0);
  const subtotal = cartItems.reduce((s, [id, e]) => {
    const item = menu.find((m) => m.id === id);
    return s + getCartLineTotal(e, item);
  }, 0);
    const setQty = (id, q) => {
    setCart(prev => {
      const next = { ...prev };
      if (q <= 0) delete next[id];
      else next[id] = { qty: q };
      return next;
    });
  };
  const inputStyle = { padding: 12, border: `1.5px solid ${COLORS.line}`, borderRadius: 10, fontSize: 14, width: "100%", boxSizing: "border-box", fontFamily: "'Plus Jakarta Sans', sans-serif", background: "#fff", color: COLORS.ink, colorScheme: "light" };


  // 🔥 Running tables
  const runningTables = useMemo(() => {
    return (orders || [])
      .filter(o => o.orderType === "dine_in" && o.status !== "served" && o.status !== "cancelled")
      .sort((a, b) => b.createdAt - a.createdAt);
  }, [orders]);

  const currentTableRunning = runningTables.find(o => Number(o.table) === Number(table));

  // 🆕 SAVE NEW MENU ITEM TO FIREBASE
  const handleSaveNewItem = async () => {
    if (!newItem.name.trim()) { alert("⚠️ Item name required"); return; }
    if (!newItem.price || Number(newItem.price) <= 0) { alert("⚠️ Valid price required"); return; }

    setIsSavingItem(true);
    try {
      // Naya item banao
      const newDish = mi(
        uid("m"),
        newItem.name.trim(),
        Number(newItem.price),
        newItem.category,
        newItem.veg,
        newItem.desc.trim(),
        newItem.portion.trim(),
        newItem.isBestseller,
        true,
        newItem.image.trim()
      );

      // Menu mein sabse upar add karo
      const updatedMenu = [newDish, ...menu];

      // Firestore mein save karo
      await setDoc(doc(db, "settings", "menu"), { items: updatedMenu });

      // Local state update karo
      if (setMenuState) setMenuState(updatedMenu);

      // Success message
      alert(`✅ "${newDish.name}" added to menu!\n\nAb ise cart mein add kar sakte ho.`);

      // Form reset karo
      setNewItem({
        name: "",
        price: "",
        category: categories[0] || "Thali",
        veg: true,
        portion: "",
        desc: "",
        image: "",
        isBestseller: false
      });
      setShowAddItem(false);

      // Search mein naya item dikhane ke liye
      setSearch(newDish.name);

    } catch (error) {
      console.error("Save new item error:", error);
      alert("❌ Failed to save item. Check internet and try again.");
    } finally {
      setIsSavingItem(false);
    }
  };

  const handleSubmit = async () => {
    if (cartItems.length === 0) return;
    setIsSubmitting(true);
    try {
      const items = cartItems.map(([id, entry]) => {
        const m = menu.find(x => x.id === id);
        return {
          itemId: id,
          name: m.name,
          portion: m.portion || "",
          price: entry.priceOverride ?? m.price,
          qty: getCartQty(entry)
        };
      });
      let created = null;
      try {
      created = await onSubmit({
  table: orderMode === "parcel" ? 0 : table,
  orderType: orderMode,
  items, waiterName,
  customerName: customerName || "Walk-in",
  customerPhone: customerPhone || "",
  notes
});
      } catch (err) {
        console.error(err);
        alert("❌ Order send nahi hua:\n" + (err.code || err.message || err));
      }
      if (created) {
        setPlacedOrder(created);
        setCart({});
        setNotes("");
      }
    } catch (e) { console.error(e); }
    finally { setIsSubmitting(false); }
  };

  const handlePrintKOT = (order) => {
    const w = window.open('', '_blank', 'width=300,height=600');
    if (!w) return;
    const totalAmount = getOrderTotal(order);
    w.document.write(`<html><head><title>KOT</title>
      <style>body{font-family:monospace;font-size:13px;padding:12px;width:280px}
      h2,h4{text-align:center;margin:4px 0}
      .row{display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px dashed #000}</style></head><body>
      <h2>${escapeHtml(RESTAURANT.name)}</h2>
      <h4>WAITER ORDER — TABLE ${escapeHtml(order.table)}</h4>
      <p>Order: #${escapeHtml(order.id.toUpperCase())}<br/>Waiter: ${escapeHtml(order.waiter || "-")}<br/>Customer: ${escapeHtml(order.customer.name)}</p>
      <div style="margin-top:10px">
        ${order.items.map(it => `<div class="row"><span>${it.qty}x ${escapeHtml(it.name)}</span><span>₹${it.price * it.qty}</span></div>`).join('')}
      </div>
      <div style="text-align:right;font-weight:bold;margin-top:12px;font-size:15px">Total: ₹${totalAmount}</div>
      <p style="text-align:center;margin-top:12px;font-size:11px">— Thank You —</p>
      <script>window.print();setTimeout(()=>window.close(),500)</script></body></html>`);
    w.document.close();
  };
  const handlePrintKOTOld = (order) => {
    const w = window.open('', '_blank', 'width=300,height=600');
    if (!w) return;
    const totalAmount = order.items.reduce((s, it) => s + (it.price * it.qty), 0);
    w.document.write(`<html><head><title>KOT</title>
      <style>body{font-family:monospace;font-size:13px;padding:12px;width:280px}
      h2,h4{text-align:center;margin:4px 0}
      .row{display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px dashed #000}</style></head><body>
      <h2>${RESTAURANT.name}</h2>
      <h4>WAITER ORDER — TABLE ${order.table}</h4>
      <p>Order: #${order.id.toUpperCase()}<br/>Waiter: ${order.waiter || "-"}<br/>Customer: ${order.customer.name}</p>
      <div style="margin-top:10px">
        ${order.items.map(it => `<div class="row"><span>${it.qty}x ${it.name}</span><span>₹${it.price * it.qty}</span></div>`).join('')}
      </div>
      <div style="text-align:right;font-weight:bold;margin-top:12px;font-size:15px">Total: ₹${totalAmount}</div>
      <p style="text-align:center;margin-top:12px;font-size:11px">— Thank You —</p>
      <script>window.print();setTimeout(()=>window.close(),500)</script></body></html>`);
    w.document.close();
  };

  // Running Tables List Component
  const renderRunningTables = () => {
    if (runningTables.length === 0) return null;
    return (
      <div style={{ background: 'linear-gradient(135deg, #FFF8E1 0%, #FFE0B2 100%)', borderRadius: 14, padding: 14, marginBottom: 16, border: `1.5px solid ${COLORS.warning}` }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
          <div style={{ fontWeight: 800, fontSize: 14, color: '#E65100', display: 'flex', alignItems: 'center', gap: 6 }}>
            🔥 Running Tables ({runningTables.length})
          </div>
          <div style={{ fontSize: 11, color: '#BF360C', fontWeight: 700 }}>Tap to add items</div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, maxHeight: 220, overflowY: 'auto' }}>
          {runningTables.map(o => (
            <button
              key={o.id}
              onClick={() => onAddMoreItems(o.id)}
              style={{
                background: '#fff', border: `1px solid ${COLORS.line}`,
                borderRadius: 10, padding: 10, cursor: 'pointer',
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                textAlign: 'left', fontFamily: 'inherit', width: '100%'
              }}
            >
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 800, fontSize: 14, color: COLORS.ink, marginBottom: 2 }}>
                  🍽️ Table {o.table}
                  <span style={{ marginLeft: 6, fontSize: 11, color: COLORS.textLight, fontWeight: 600 }}>
                    #{o.id.slice(1, 5).toUpperCase()}
                  </span>
                  {o.kots?.length > 1 && (
                    <span style={{ marginLeft: 6, background: COLORS.info, color: '#fff', fontSize: 9, padding: '1px 6px', borderRadius: 6, fontWeight: 800 }}>
                      {o.kots.length} KOT
                    </span>
                  )}
                </div>
                <div style={{ fontSize: 11, color: COLORS.textLight, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                  {o.waiter && <span>🧑‍🍳 {o.waiter}</span>}
                  <span>· {o.items.length} item{o.items.length !== 1 ? 's' : ''}</span>
                  <span>· ₹{getOrderTotal(o)}</span>
                  <span>· {timeAgo(o.createdAt)}</span>
                </div>
              </div>
              <div style={{
                background: COLORS.info, color: '#fff', borderRadius: 8,
                padding: '6px 10px', fontWeight: 800, fontSize: 12,
                display: 'flex', alignItems: 'center', gap: 4, flexShrink: 0, marginLeft: 8
              }}>
                ➕ Add
              </div>
            </button>
          ))}
        </div>
      </div>
    );
  };

  // ═══════════════════════════════════════════
  // 🆕 ADD NEW ITEM SCREEN
  // ═══════════════════════════════════════════
  if (showAddItem) {
    return (
      <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)", zIndex: 85, display: "flex", alignItems: "flex-end" }} onClick={() => setShowAddItem(false)}>
        <div onClick={e => e.stopPropagation()} className="slide-up" style={{ background: "#fff", width: "100%", maxWidth: 480, margin: "0 auto", borderRadius: "24px 24px 0 0", padding: "20px", maxHeight: "92vh", overflowY: "auto" }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 20 }}>
            <div>
              <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 22, fontWeight: 800 }}>➕ Add New Menu Item</div>
              <div style={{ fontSize: 12, color: COLORS.textLight, marginTop: 2 }}>Ye item direct Firebase mein save hoga</div>
            </div>
            <button onClick={() => setShowAddItem(false)} style={{ background: "rgba(0,0,0,0.05)", border: "none", borderRadius: "50%", width: 36, height: 36, fontSize: 18, cursor: "pointer" }}>✕</button>
          </div>

          {/* Item Name */}
          <div style={{ marginBottom: 12 }}>
            <label style={{ fontSize: 12, fontWeight: 800, color: COLORS.textLight, textTransform: 'uppercase', marginBottom: 6, display: 'block' }}>Item Name *</label>
            <input
              type="text"
              placeholder="e.g. Paneer Tikka"
              value={newItem.name}
              onChange={e => setNewItem({ ...newItem, name: e.target.value })}
              style={inputStyle}
              autoFocus
            />
          </div>

          {/* Price + Category */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
            <div>
              <label style={{ fontSize: 12, fontWeight: 800, color: COLORS.textLight, textTransform: 'uppercase', marginBottom: 6, display: 'block' }}>Price (₹) *</label>
              <input
                type="number"
                placeholder="250"
                value={newItem.price}
                onChange={e => setNewItem({ ...newItem, price: e.target.value })}
                style={inputStyle}
              />
            </div>
            <div>
              <label style={{ fontSize: 12, fontWeight: 800, color: COLORS.textLight, textTransform: 'uppercase', marginBottom: 6, display: 'block' }}>Category</label>
              <select
                value={newItem.category}
                onChange={e => setNewItem({ ...newItem, category: e.target.value })}
                style={{ ...inputStyle, background: '#fff' }}>
                {(categories || []).map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          </div>

          {/* Veg + Portion */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
            <div>
              <label style={{ fontSize: 12, fontWeight: 800, color: COLORS.textLight, textTransform: 'uppercase', marginBottom: 6, display: 'block' }}>Type</label>
              <div style={{ display: 'flex', gap: 8 }}>
                <button
                  onClick={() => setNewItem({ ...newItem, veg: true })}
                  style={{
                    flex: 1, padding: 10, borderRadius: 10,
                    border: `2px solid ${newItem.veg ? COLORS.sage : COLORS.line}`,
                    background: newItem.veg ? COLORS.sageLight : '#fff',
                    color: newItem.veg ? COLORS.sageDark : COLORS.textLight,
                    fontWeight: 800, fontSize: 13, cursor: 'pointer'
                  }}>
                  🟢 Veg
                </button>
                <button
                  onClick={() => setNewItem({ ...newItem, veg: false })}
                  style={{
                    flex: 1, padding: 10, borderRadius: 10,
                    border: `2px solid ${!newItem.veg ? COLORS.rust : COLORS.line}`,
                    background: !newItem.veg ? '#FFEBEE' : '#fff',
                    color: !newItem.veg ? COLORS.rust : COLORS.textLight,
                    fontWeight: 800, fontSize: 13, cursor: 'pointer'
                  }}>
                  🔴 Non-Veg
                </button>
              </div>
            </div>
            <div>
              <label style={{ fontSize: 12, fontWeight: 800, color: COLORS.textLight, textTransform: 'uppercase', marginBottom: 6, display: 'block' }}>Portion</label>
              <input
                type="text"
                placeholder="Half / Full"
                value={newItem.portion}
                onChange={e => setNewItem({ ...newItem, portion: e.target.value })}
                style={inputStyle}
              />
            </div>
          </div>

          {/* Description */}
          <div style={{ marginBottom: 12 }}>
            <label style={{ fontSize: 12, fontWeight: 800, color: COLORS.textLight, textTransform: 'uppercase', marginBottom: 6, display: 'block' }}>Description</label>
            <textarea
              placeholder="Short description (optional)"
              value={newItem.desc}
              onChange={e => setNewItem({ ...newItem, desc: e.target.value })}
              style={{ ...inputStyle, resize: 'none' }}
              rows={2}
            />
          </div>

          {/* Image URL */}
          <div style={{ marginBottom: 12 }}>
            <label style={{ fontSize: 12, fontWeight: 800, color: COLORS.textLight, textTransform: 'uppercase', marginBottom: 6, display: 'block' }}>Image URL (optional)</label>
            <input
              type="url"
              placeholder="https://..."
              value={newItem.image}
              onChange={e => setNewItem({ ...newItem, image: e.target.value })}
              style={inputStyle}
            />
          </div>

          {/* Bestseller toggle */}
          <label style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', marginBottom: 20, padding: 12, background: COLORS.paper, borderRadius: 10 }}>
            <input
              type="checkbox"
              checked={newItem.isBestseller}
              onChange={e => setNewItem({ ...newItem, isBestseller: e.target.checked })}
              style={{ width: 20, height: 20 }}
            />
            <span style={{ fontWeight: 700, fontSize: 14 }}>⭐ Mark as Bestseller</span>
          </label>

          {/* Save button */}
          <button
            onClick={handleSaveNewItem}
            disabled={isSavingItem || !newItem.name.trim() || !newItem.price}
            style={{
              width: "100%",
              padding: 16,
              border: "none",
              borderRadius: 14,
              background: (isSavingItem || !newItem.name.trim() || !newItem.price) ? COLORS.paper2 : COLORS.sage,
              color: (isSavingItem || !newItem.name.trim() || !newItem.price) ? COLORS.textLight : "#fff",
              fontWeight: 800,
              fontSize: 16,
              cursor: (isSavingItem || !newItem.name.trim() || !newItem.price) ? "not-allowed" : "pointer"
            }}>
            {isSavingItem ? "⏳ Saving to Firebase..." : "💾 Save Item to Menu"}
          </button>

          <div style={{ fontSize: 11, color: COLORS.textLight, textAlign: 'center', marginTop: 12, lineHeight: 1.5 }}>
            💡 Ye item turant menu mein add ho jayega aur baaki sab waiters ko bhi dikhega.
          </div>
        </div>
      </div>
    );
  }

  // ✅ ORDER PLACED — Confirmation view
  if (placedOrder) {
    const total = placedOrder.items.reduce((s, it) => s + (it.price * it.qty), 0);
    return (
      <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)", zIndex: 85, display: "flex", alignItems: "flex-end" }} onClick={onClose}>
        <div onClick={e => e.stopPropagation()} className="slide-up" style={{ background: "#fff", width: "100%", maxWidth: 480, margin: "0 auto", borderRadius: "24px 24px 0 0", padding: "20px", maxHeight: "92vh", overflowY: "auto" }}>
          <div style={{ textAlign: "center", marginBottom: 20 }}>
            <div style={{ fontSize: 56, marginBottom: 8 }} className="scale-bounce">✅</div>
            <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 24, fontWeight: 800, color: COLORS.sage }}>Order Placed!</div>
            <div style={{ fontSize: 13, color: COLORS.textLight, marginTop: 4 }}>KOT sent to kitchen successfully</div>
          </div>

          <div style={{ background: COLORS.paper, borderRadius: 16, padding: 16, marginBottom: 16, border: `1px solid ${COLORS.line}` }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
              <div>
                <div style={{ fontSize: 11, color: COLORS.textLight, textTransform: 'uppercase', fontWeight: 800, letterSpacing: 0.5 }}>Order</div>
                <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 22, fontWeight: 800 }}>#{placedOrder.id.slice(1, 5).toUpperCase()}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: 11, color: COLORS.textLight, textTransform: 'uppercase', fontWeight: 800, letterSpacing: 0.5 }}>Table</div>
                <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 22, fontWeight: 800, color: COLORS.copper }}>{placedOrder.table}</div>
              </div>
            </div>
            {placedOrder.waiter && (
              <div style={{ fontSize: 12, color: COLORS.textLight, marginBottom: 8 }}>
                🧑‍🍳 Waiter: <strong style={{ color: COLORS.ink }}>{placedOrder.waiter}</strong>
              </div>
            )}
            <div style={{ borderTop: `1px dashed ${COLORS.line}`, paddingTop: 12, marginTop: 4 }}>
              <div style={{ fontSize: 12, color: COLORS.textLight, marginBottom: 6, fontWeight: 700, textTransform: 'uppercase' }}>Items ({placedOrder.items.length})</div>
              {placedOrder.items.map((it, i) => (
                <div key={i} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, padding: '4px 0', fontWeight: 600 }}>
                  <span>{it.qty}× {it.name}</span>
                  <span style={{ fontFamily: "'JetBrains Mono', monospace" }}>₹{it.price * it.qty}</span>
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', borderTop: `2px solid ${COLORS.line}`, marginTop: 12, paddingTop: 12, fontWeight: 800, fontSize: 18 }}>
              <span>Total</span>
              <span style={{ fontFamily: "'JetBrains Mono', monospace", color: COLORS.copper }}>₹{total}</span>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 10 }}>
            <button onClick={() => handlePrintKOT(placedOrder)}
              style={{ padding: 14, borderRadius: 12, border: `2px solid ${COLORS.ink}`, background: 'transparent', color: COLORS.ink, fontWeight: 800, fontSize: 14, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
              🖨️ Print KOT
            </button>
            {onAddMoreItems && (
              <button onClick={() => onAddMoreItems(placedOrder.id)}
                style={{ padding: 14, borderRadius: 12, border: 'none', background: COLORS.info, color: '#fff', fontWeight: 800, fontSize: 14, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                ➕ Add More Items
              </button>
            )}
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 16 }}>
            <button onClick={() => { setPlacedOrder(null); setWaiterName(""); setCustomerName(""); setCustomerPhone(""); }}
              style={{ padding: 14, borderRadius: 12, border: `2px solid ${COLORS.sage}`, background: 'transparent', color: COLORS.sage, fontWeight: 800, fontSize: 14, cursor: 'pointer' }}>
              🆕 New Order
            </button>
            <button onClick={onClose}
              style={{ padding: 14, borderRadius: 12, border: 'none', background: COLORS.sage, color: '#fff', fontWeight: 800, fontSize: 14, cursor: 'pointer' }}>
              ✓ Done
            </button>
          </div>

          {renderRunningTables()}

          <div style={{ fontSize: 11, color: COLORS.textLight, textAlign: 'center', lineHeight: 1.5 }}>
            💡 Tap any running table above to add extra items (new KOT).
          </div>
        </div>
      </div>
    );
  }

  // Default: Order form
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)", zIndex: 85, display: "flex", alignItems: "flex-end" }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} className="slide-up" style={{ background: "#fff", width: "100%", maxWidth: 480, margin: "0 auto", borderRadius: "24px 24px 0 0", padding: "20px", maxHeight: "92vh", overflowY: "auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16 }}>
          <div>
            <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 22, fontWeight: 800 }}>🧑‍🍳 Waiter Mode</div>
            <div style={{ fontSize: 12, color: COLORS.textLight, marginTop: 2 }}>Take order on behalf of customer</div>
          </div>
          <button onClick={onClose} style={{ background: "rgba(0,0,0,0.05)", border: "none", borderRadius: "50%", width: 36, height: 36, fontSize: 18, cursor: "pointer" }}>✕</button>
        </div>

        {/* 🆕 ADD NEW ITEM BUTTON */}
        <button
          onClick={() => setShowAddItem(true)}
          style={{
            width: '100%',
            padding: 14,
            marginBottom: 16,
            background: 'linear-gradient(135deg, #4A7C59 0%, #2F5C3F 100%)',
            color: '#fff',
            border: 'none',
            borderRadius: 14,
            fontWeight: 800,
            fontSize: 15,
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 8,
            boxShadow: '0 4px 12px rgba(74,124,89,0.3)'
          }}>
          ➕ Add New Menu Item
        </button>

        {renderRunningTables()}

        {currentTableRunning && (
          <div style={{ background: '#FFF3E0', border: `1.5px solid ${COLORS.warning}`, borderRadius: 12, padding: 12, marginBottom: 12 }}>
            <div style={{ fontSize: 13, color: '#E65100', fontWeight: 700, marginBottom: 8 }}>
              ⚠️ Table {table} already has a running order (#{currentTableRunning.id.slice(1, 5).toUpperCase()})
            </div>
            <button
              onClick={() => onAddMoreItems(currentTableRunning.id)}
              style={{
                width: '100%', padding: 10, borderRadius: 10,
                border: 'none', background: COLORS.info, color: '#fff',
                fontWeight: 800, fontSize: 13, cursor: 'pointer'
              }}>
              ➕ Add items to Table {table} instead
            </button>
          </div>
        )}

        <div style={{ marginBottom: 12 }}>
  <input placeholder="Waiter Name" value={waiterName} onChange={e => setWaiterName(e.target.value)} style={{ ...inputStyle, marginBottom: 10 }} />

  {/* 🆕 Dine-in / Parcel toggle */}
  <div style={{ display: "flex", gap: 8 }}>
    <button
      type="button"
      onClick={() => setOrderMode("dine_in")}
      style={{
        flex: 1, padding: "12px 8px", borderRadius: 10,
        border: `2px solid ${orderMode === "dine_in" ? COLORS.copper : COLORS.line}`,
        background: orderMode === "dine_in" ? COLORS.copper : "#fff",
        color: orderMode === "dine_in" ? "#fff" : COLORS.ink,
        fontWeight: 800, fontSize: 13, cursor: "pointer"
      }}>
      🍽️ Table
    </button>
    <button
      type="button"
      onClick={() => setOrderMode("parcel")}
      style={{
        flex: 1, padding: "12px 8px", borderRadius: 10,
        border: `2px solid ${orderMode === "parcel" ? COLORS.copper : COLORS.line}`,
        background: orderMode === "parcel" ? COLORS.copper : "#fff",
        color: orderMode === "parcel" ? "#fff" : COLORS.ink,
        fontWeight: 800, fontSize: 13, cursor: "pointer"
      }}>
      🛍️ Parcel
    </button>
  </div>

  {/* Table dropdown sirf Dine-in me */}
  {orderMode === "dine_in" && (
    <select value={table} onChange={e => setTable(Number(e.target.value))} style={{ ...inputStyle, background: "#fff", marginTop: 10 }}>
      {Array.from({ length: 20 }, (_, i) => i + 1).map(n => <option key={n} value={n}>Table {n}</option>)}
    </select>
  )}
</div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 }}>
          <input placeholder="Customer Name (optional)" value={customerName} onChange={e => setCustomerName(e.target.value)} style={inputStyle} />
          <input placeholder="Customer Phone (optional)" value={customerPhone} onChange={e => setCustomerPhone(e.target.value)} style={inputStyle} />
        </div>
        <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 8 }}>
          <div style={{ flex: 1 }}>
            <SearchBar value={search} onChange={setSearch} placeholder="Search items..." />
          </div>
          <button
            type="button"
            onClick={() => setShowAiModal(true)}
            style={{
              background: COLORS.info,
              color: "#fff",
              border: "none",
              borderRadius: 12,
              padding: "12px 14px",
              fontWeight: 800,
              fontSize: 14,
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              gap: 4,
              whiteSpace: "nowrap"
            }}
          >
            🤖 AI
          </button>
        </div>

        <div style={{ marginTop: 16, maxHeight: "32vh", overflowY: "auto" }}>
          {filtered.map(item => {
            const qty = getCartQty(cart[item.id]);
            return (
              <div key={item.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: `1px solid ${COLORS.line}` }}>
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 6 }}><VegDot veg={item.veg} /><strong style={{ fontSize: 14 }}>{item.name}</strong></div>
                  <div style={{ fontSize: 13, color: COLORS.copper, fontWeight: 700, marginTop: 2 }}>{inr(item.price)}</div>
                </div>
                <AddBtnStepper qty={qty} onChange={q => setQty(item.id, q)} available={item.available} />
              </div>
            );
          })}
        </div>
        <textarea placeholder="Notes (e.g., less spicy, no onion)" value={notes} onChange={e => setNotes(e.target.value)} rows={2} style={{ ...inputStyle, marginTop: 12, resize: "none" }} />
        <div style={{ borderTop: `2px solid ${COLORS.line}`, paddingTop: 16, marginTop: 12 }}>
          <div style={{ display: "flex", justifyContent: "space-between", fontWeight: 800, fontSize: 18, marginBottom: 12 }}>
            <span>{cartItems.length} items · Total</span>
            <span style={{ color: COLORS.copper, fontFamily: "'JetBrains Mono', monospace" }}>{inr(subtotal)}</span>
          </div>
                    <button disabled={cartItems.length === 0 || isSubmitting}
            onClick={handleSubmit}
            style={{ width: "100%", padding: 16, border: "none", borderRadius: 14, background: cartItems.length ? COLORS.sage : COLORS.paper2, color: cartItems.length ? "#fff" : COLORS.textLight, fontWeight: 800, fontSize: 16, cursor: cartItems.length && !isSubmitting ? "pointer" : "not-allowed" }}>
            {isSubmitting ? "⏳ Sending..." : "🍳 Send Order to Kitchen"}
          </button>
        </div>
      </div>
      {showAiModal && (
        <AIOrderModal
          menu={menu}
          onClose={() => setShowAiModal(false)}
          onOrderParsed={(data) => {
            (data.items || []).forEach((line) => {
              setQty(line.id, (cart[line.id]?.qty || 0) + line.qty);
            });
            if (data.orderType === "parcel") {
              setOrderMode("parcel");
            } else if (data.table) {
              setOrderMode("dine_in");
              setTable(Number(data.table));
            }
            if (data.notes) {
              setNotes((prev) => (prev ? prev + ", " + data.notes : data.notes));
            }
          }}
        />
      )}
    </div>
  );
});
// ==
// 15.5 WAITER MODE (staff jaisa POS)
// ==

const WAITER_FLAG = "eatpark_waiter_open";
const wasWaiterOpen = () => { try { return sessionStorage.getItem(WAITER_FLAG) === "1"; } catch (e) { return false; } };

// KOT slip print (hidden iframe)
function printKotSlipGlobal(order) {
  try {
    const kot = (order.kots && order.kots.length ? order.kots[order.kots.length - 1] : null) || { kotNumber: 1, items: order.items || [] };
    const rows = (kot.items || []).map((it) => `<div class="r"><span>${it.qty} x ${escapeHtml(it.name)}${it.portion ? " (" + escapeHtml(it.portion) + ")" : ""}</span></div>`).join("");
    const now = new Date().toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
    const iframe = document.createElement("iframe");
    iframe.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0;";
    document.body.appendChild(iframe);
    const w = iframe.contentWindow;
    setTimeout(() => { try { document.body.removeChild(iframe); } catch (e) {} }, 60000);
    w.document.open();
    w.document.write(`<!doctype html><html><head><meta http-equiv="Content-Security-Policy" content="script-src 'none'; object-src 'none'"><title>KOT</title><style>@page{margin:0}*{color:#000!important}body{font-family:Arial,sans-serif;width:280px;margin:0 auto;padding:8px;font-weight:700}h2,h3{text-align:center;margin:3px 0}.r{font-size:17px;padding:4px 0;border-bottom:1px dashed #000}.c{text-align:center;font-size:12px}</style></head><body><h2>KOT #${kot.kotNumber || 1}${kot.isRunning ? " (RUNNING)" : ""}</h2><h3>${order.orderType === "parcel" ? "PARCEL" : "TABLE " + escapeHtml(String(order.table))}</h3><div class="c">${escapeHtml(now)} · #${escapeHtml(order.id.slice(1, 5).toUpperCase())}${order.waiter ? " · " + escapeHtml(order.waiter) : ""}</div><div style="margin-top:8px">${rows}</div>${order.notes ? `<div class="c" style="margin-top:8px">Note: ${escapeHtml(order.notes)}</div>` : ""}</body></html>`);
    w.document.close();
    setTimeout(() => { try { w.focus(); w.print(); } catch (e) { alert("⚠️ KOT print nahi ho paya: " + e.message); } }, 400);
  } catch (e) { console.error("KOT print error:", e); }
}

// Final bill print
function printBillSlip(order, items, calc, opt) {
  if (!order) return;
  const { sub, gstRate, gst, discPctAmt, discAmt, total } = calc;
  const { payMode, showBillNo, notes, discPct } = opt;
  const payLabel = { cash: "Cash", upi: "UPI", card: "Card", razorpay: "Razorpay", due: "Due (Udhaar)" }[payMode] || payMode;
  const billNo = order.id.slice(1, 9).toUpperCase();
  const now = new Date().toLocaleString("en-IN", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
  const itemsHtml = items.map((it) => `<tr><td style="text-align:left">${escapeHtml(it.name)}${it.portion ? ` <small>(${escapeHtml(it.portion)})</small>` : ""}</td><td style="text-align:center">${it.qty}</td><td style="text-align:right">₹${it.price}</td><td style="text-align:right">₹${Math.round(it.price * it.qty * 100) / 100}</td></tr>`).join("");
  const iframe = document.createElement("iframe");
  iframe.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0;";
  document.body.appendChild(iframe);
  const w = iframe.contentWindow;
  setTimeout(() => { try { document.body.removeChild(iframe); } catch (e) {} }, 60000);
  w.document.open();
  w.document.write(`<!doctype html><html><head><meta http-equiv="Content-Security-Policy" content="script-src 'none'; object-src 'none'"><title>Bill ${billNo}</title><style>
*{box-sizing:border-box;color:#000 !important}
@page{margin:0}
body{font-family:Arial,Helvetica,sans-serif;font-size:14px;font-weight:700;padding:8px;width:290px;margin:0 auto}
h2{text-align:center;margin:4px 0;font-size:24px;font-weight:900}
.line{border-top:2px dashed #000;margin:8px 0}
table{width:100%;border-collapse:collapse;font-size:14px}
th,td{padding:4px 2px}
th{border-bottom:2px solid #000;text-align:left;font-size:13px}
.grand td{font-size:20px;font-weight:900;border-top:3px solid #000;padding-top:8px}
.center{text-align:center}
.badge{display:inline-block;padding:3px 10px;border:2px solid #000;border-radius:10px;font-size:13px;margin:2px}
</style></head><body>
<h2>${escapeHtml(RESTAURANT.name)}</h2>
<div class="center" style="font-size:10px">${escapeHtml(RESTAURANT.address)}</div>
<div class="center" style="font-size:10px">Ph: ${RESTAURANT.phones.join(" / ")}</div>
${RESTAURANT.gstin ? `<div class="center" style="font-size:10px">GSTIN: ${escapeHtml(RESTAURANT.gstin)}</div>` : ""}
<div class="line"></div>
<div style="display:flex;justify-content:space-between;font-size:11px">${showBillNo ? `<div>Bill #: ${billNo}</div>` : `<div>&nbsp;</div>`}<div>${order.orderType === "parcel" ? "PARCEL" : "T-" + escapeHtml(String(order.table))}</div></div>
<div style="font-size:10px;text-align:center;margin-top:4px">${now}</div>
${order.customer && order.customer.name && !isWalkIn(order.customer.name) ? `<div style="font-size:10px;margin-top:2px">Customer: ${escapeHtml(order.customer.name)}${order.customer.phone && !isWalkIn(order.customer.phone) ? " · " + escapeHtml(order.customer.phone) : ""}</div>` : ""}
${order.waiter ? `<div style="font-size:10px;margin-top:4px">Waiter: ${escapeHtml(order.waiter)}</div>` : ""}
<div class="line"></div>
<table><thead><tr><th>Item</th><th style="text-align:center">Qty</th><th style="text-align:right">Rate</th><th style="text-align:right">Amt</th></tr></thead><tbody>${itemsHtml}</tbody></table>
<div class="line"></div>
<table>
<tr><td>Subtotal</td><td style="text-align:right">₹${sub}</td></tr>
${discPct > 0 ? `<tr><td>Discount (${discPct}%)</td><td style="text-align:right">-₹${discPctAmt}</td></tr>` : ""}
${discAmt > 0 ? `<tr><td>Extra Discount</td><td style="text-align:right">-₹${discAmt}</td></tr>` : ""}
${gstRate > 0 ? `<tr><td>CGST @ ${gstRate / 2}%</td><td style="text-align:right">+₹${Math.round(gst / 2)}</td></tr><tr><td>SGST @ ${gstRate / 2}%</td><td style="text-align:right">+₹${gst - Math.round(gst / 2)}</td></tr>` : ""}
${calc.delivery > 0 ? `<tr><td>Delivery</td><td style="text-align:right">+₹${calc.delivery}</td></tr>` : ""}
<tr class="grand"><td>GRAND TOTAL</td><td style="text-align:right">₹${total}</td></tr>
</table>
<div class="line"></div>
<div class="center"><span class="badge">${payLabel}</span><span class="badge">${order.paymentStatus === "paid" ? "PAID" : "PENDING"}</span></div>
${notes ? `<div style="font-size:10px;margin-top:8px;border-top:1px dashed #000;padding-top:6px"><b>Notes:</b> ${escapeHtml(notes)}</div>` : ""}
<div class="center" style="font-size:10px;margin-top:10px">** Thank you! Visit again **<br/>${escapeHtml(RESTAURANT.tagline)}</div>
</body></html>`);
  w.document.close();
  setTimeout(() => { try { w.focus(); w.print(); } catch (e) { alert("⚠️ Print nahi ho paya: " + e.message); } }, 400);
}

const deriveBill = (o) => ({
  items: (o.items || []).map((it, i) => ({ ...it, _origQty: it.qty, _rowId: i + "_" + Math.random().toString(36).slice(2, 6) })),
  gstRate: o.gstRate ?? 0,
  disc: o.billEditedAt ? (o.billDiscount || 0) : (o.loyaltyDiscount || 0),
  discPct: o.billEditedAt ? (o.billDiscountPct || 0) : (o.discount || 0),
  payMode: o.payment || "cash",
  payStatus: o.paid ? "paid" : "pending",
  custName: isWalkIn(o.customer?.name) ? "" : (o.customer?.name || ""),
  custPhone: isWalkIn(o.customer?.phone) ? "" : (o.customer?.phone || ""),
  gstin: o.customerGstin || "",
  notes: o.notes || "",
  table: Number(o.table) || 1,
  orderType: o.orderType || "dine_in",
  waiter: o.waiter || "",
  sendKot: !!o.isDraft
});

// Staff wale POS ka hi logic — waiter ke liye
function POSController({ initialOrder, orders, menu, categories, viewMode, placeOrder, advanceStatus, setMenuState, onClose, waiterMode, onDraftChange }) {
  const [init] = useState(() => deriveBill(initialOrder));
  const [billOrder, setBillOrder] = useState(initialOrder);
  const [items, setItems] = useState(init.items);
  const [gstRate, setGstRate] = useState(init.gstRate);
  const [gstCustom, setGstCustom] = useState("");
  const [disc, setDisc] = useState(init.disc);
  const [discPct, setDiscPct] = useState(init.discPct);
  const [payMode, setPayMode] = useState(init.payMode);
  const [payStatus, setPayStatus] = useState(init.payStatus);
  const [custName, setCustName] = useState(init.custName);
  const [custPhone, setCustPhone] = useState(init.custPhone);
  const [gstin, setGstin] = useState(init.gstin);
  const [notes, setNotes] = useState(init.notes);
  const [showBillNo, setShowBillNo] = useState(true);
  const [table, setTable] = useState(init.table);
  const [orderType, setOrderType] = useState(init.orderType);
  const [waiter, setWaiter] = useState(init.waiter);
  const [sendKot, setSendKot] = useState(init.sendKot);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (billOrder.isDraft && onDraftChange) {
      onDraftChange(table, items, billOrder);
    }
  }, [items, table]);

  // Dusra order kholna ho (table clash pe "Wahi kholo")
  const load = (o) => {
    const d = deriveBill(o);
    setBillOrder(o); setItems(d.items); setGstRate(d.gstRate); setGstCustom("");
    setDisc(d.disc); setDiscPct(d.discPct); setPayMode(d.payMode); setPayStatus(d.payStatus);
    setCustName(d.custName); setCustPhone(d.custPhone); setGstin(d.gstin); setNotes(d.notes);
    setTable(d.table); setOrderType(d.orderType); setWaiter(d.waiter); setSendKot(d.sendKot);
  };

  const calc = useMemo(() => {
    const sub = Math.round(items.reduce((s, it) => s + (it.price || 0) * (it.qty || 0), 0));
    const gr = gstRate === "custom" ? Number(gstCustom) || 0 : Number(gstRate) || 0;
    const discPctAmt = Math.round((sub * discPct) / 100);
    const afterPct = sub - discPctAmt;
    const gst = Math.round((afterPct * gr) / 100);
    const delivery = Number(billOrder.deliveryFee) || 0;
    const total = Math.max(0, afterPct - disc) + gst + delivery;
    return { sub, gstRate: gr, gst, discPctAmt, discAmt: disc, total, delivery };
  }, [billOrder, items, gstRate, gstCustom, disc, discPct]);

  const saveBill = async (override = {}) => {
    try {
      const { sub, gstRate: gr, gst, discPctAmt, discAmt, total } = calc;
      const updated = {
        items: items.map(({ _rowId, _new, _origQty, ...rest }) => (!billOrder.isDraft && _new ? { ...rest, kotNumber: getNextKotNo(billOrder) } : rest)),
        subtotal: sub, gstRate: gr, gstAmount: gst,
        billDiscount: discAmt, billDiscountPct: discPct, billDiscountAmt: discPctAmt,
        finalTotal: total, payment: payMode,
        paid: (override.payStatus ?? payStatus) === "paid",
        paymentStatus: override.payStatus ?? payStatus,
        customer: { ...(billOrder.customer || {}), name: custName || "Walk-in", phone: custPhone || "WALK-IN" },
        customerGstin: gstin || "", notes,
        billEditedAt: Date.now(),
        billEditedBy: (auth.currentUser && auth.currentUser.email) || "waiter"
      };
      const clean = JSON.parse(JSON.stringify(updated));
      if (billOrder.isDraft) {
        const { isDraft, ...base } = billOrder;
        const kotItems = clean.items.map((it) => ({ ...it, kotNumber: 1 }));
        const fullOrder = JSON.parse(JSON.stringify({
          ...base, ...clean,
          createdBy: auth.currentUser ? auth.currentUser.uid : "waiter",
          table: orderType === "parcel" ? 0 : table,
          orderType, waiter: waiter || "Staff", items: kotItems,
          kots: sendKot ? [{ id: uid("kot"), kotNumber: 1, items: kotItems, createdAt: Date.now(), status: "new", isRunning: false }] : [],
          status: (sendKot && !clean.paid) ? "new" : "served",
          ...((sendKot && !clean.paid) ? {} : { servedAt: Date.now() })
        }));
        await placeOrder(fullOrder);
        return fullOrder;
      }
      const addedRows = items.map((it) => {
        if (it._new) return (it.qty || 0) > 0 ? it : null;
        const extra = (it.qty || 0) - (it._origQty ?? it.qty);
        return extra > 0 ? { ...it, qty: extra } : null;
      }).filter(Boolean);
      if (addedRows.length > 0) {
        const no = getNextKotNo(billOrder);
        const runKot = { id: uid("kot"), kotNumber: no, items: addedRows.map(({ _rowId, _new, _origQty, ...r }) => ({ ...r, kotNumber: no })), createdAt: Date.now(), status: "new", isRunning: true };
        clean.kots = JSON.parse(JSON.stringify([...getBaseKots(billOrder), runKot]));
        clean.status = "new";
        clean.lastKotAt = Date.now();
await guardedOrderUpdate(billOrder, clean);

        return { ...billOrder, ...clean, _ranKot: true };
      }
      await guardedOrderUpdate(billOrder, clean);
      return { ...billOrder, ...updated };
    } catch (e) {
      console.error("waiter saveBill error:", e);
      alert("⚠️ Save fail: " + e.message);
      return null;
    }
  };

  const onAction = async (mode) => {
    if (saving) return;
    if (items.length === 0) { alert("⚠️ Pehle items add karo"); return; }
    setSaving(true);
    try {
      const wasDraft = !!billOrder.isDraft;
      // Waiter mode: koi print nahi — sirf save / KOT kitchen ko
      const saved = await saveBill({});
      if (!saved) return;
      addDoc(collection(db, "auditLogs"), { orderId: saved.id, action: "save", by: (auth.currentUser && auth.currentUser.email) || "?", before: getOrderTotal(billOrder), after: saved.finalTotal, at: Date.now() }).catch(() => {});
      onClose();
    } finally { setSaving(false); }
  };

  return (
    <BillPOSScreen
      order={billOrder} orders={orders} menu={menu} categories={categories} viewMode={viewMode} setMenuState={setMenuState}
      items={items} setItems={setItems} calc={calc}
      orderType={orderType} setOrderType={setOrderType} table={table} setTable={setTable}
      waiter={waiter} setWaiter={setWaiter} sendKot={sendKot} setSendKot={setSendKot}
      custName={custName} setCustName={setCustName} custPhone={custPhone} setCustPhone={setCustPhone}
      gstin={gstin} setGstin={setGstin} gstRate={gstRate} setGstRate={setGstRate}
      gstCustom={gstCustom} setGstCustom={setGstCustom} disc={disc} setDisc={setDisc}
      discPct={discPct} setDiscPct={setDiscPct} payMode={payMode} setPayMode={setPayMode}
      payStatus={payStatus} setPayStatus={setPayStatus} notes={notes} setNotes={setNotes}
      showBillNo={showBillNo} setShowBillNo={setShowBillNo} saving={saving}
      hidePrint waiterMode={waiterMode}
      onClose={onClose} onOpenOrder={load} onAction={onAction}
    />
  );
}

// 🧑‍🍳 Waiter Mode — fullscreen, back dabane pe band nahi hota
function WaiterMode({ orders, menu, categories, setMenuState, placeOrder, advanceStatus, onClose }) {
  useLiveNow(5000);
  const [viewMode] = useViewMode();
  const [target, setTarget] = useState(null);
  const [drafts, setDrafts] = useState({});
  const [showKitchenOnly, setShowKitchenOnly] = useState(false);
  const [waiterTab, setWaiterTab] = useState("tables");

  const handleDraftChange = (t, items, orderData) => {
    if (items && items.length > 0) {
      setDrafts(prev => ({ ...prev, [t]: { ...orderData, items, isDraft: true, table: t } }));
    } else {
      setDrafts(prev => { const n = {...prev}; delete n[t]; return n; });
    }
  };

  const openNew = (t) => {
    if (drafts[t] && drafts[t].items && drafts[t].items.length > 0) {
      setTarget(drafts[t]);
    } else {
      setTarget({
        id: uid("o"), isDraft: true,
        table: Number(t) || 1, orderType: "dine_in",
        customer: { name: "Walk-in", phone: "WALK-IN", address: "" },
        items: [], kots: [], waiter: "", takenBy: "waiter",
        notes: "", payment: "cash", paymentStatus: "pending", paid: false,
        status: "new", createdAt: Date.now(),
        coinsClaimed: true, earnedCoins: 0, rewardUsedCoins: 0,
        deliveryFee: 0, loyaltyDiscount: 0, discount: 0
      });
    }
  };

  const exit = () => { if (window.confirm("Waiter Mode band karna hai?")) onClose(); };
  const combinedOrders = [...(orders || []), ...Object.values(drafts).map(d => ({ ...d, status: 'draft', orderType: 'dine_in' }))];

  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 85, background: "#0B111A", overflowY: "auto", colorScheme: "dark" }}>
      <div style={{ background: "#161F2F", padding: "12px 20px", display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "1px solid #273449", position: "sticky", top: 0, zIndex: 10 }}>
        <div style={{ color: "#fff", fontWeight: 800, fontSize: 20, fontFamily: "'Outfit', sans-serif" }}>🧑‍🍳 Waiter Panel</div>
        <div style={{ display: "flex", gap: 8 }}>
          <div style={{ display: "flex", background: "#273449", borderRadius: 8, padding: 4, gap: 4, flexWrap: "wrap" }}>
              <button onClick={() => setWaiterTab("tables")} style={{ background: waiterTab === "tables" ? "#38BDF8" : "transparent", color: waiterTab === "tables" ? "#0B111A" : "#fff", border: "none", borderRadius: 6, padding: "6px 12px", fontWeight: 800, fontSize: 13, cursor: "pointer" }}>🪑 Tables</button>
              <button onClick={() => setWaiterTab("parcel")} style={{ background: waiterTab === "parcel" ? "#38BDF8" : "transparent", color: waiterTab === "parcel" ? "#0B111A" : "#fff", border: "none", borderRadius: 6, padding: "6px 12px", fontWeight: 800, fontSize: 13, cursor: "pointer" }}>🛍️ Parcel</button>
              <button onClick={() => setWaiterTab("kitchen")} style={{ background: waiterTab === "kitchen" ? "#38BDF8" : "transparent", color: waiterTab === "kitchen" ? "#0B111A" : "#fff", border: "none", borderRadius: 6, padding: "6px 12px", fontWeight: 800, fontSize: 13, cursor: "pointer" }}>🍳 Kitchen</button>
            </div>
          <button onClick={() => openNew()} style={{ background: "#FF5A1F", color: "#fff", border: "none", borderRadius: 8, padding: "8px 16px", fontWeight: 800, fontSize: 13, cursor: "pointer", boxShadow: "0 4px 10px rgba(255,90,31,0.3)" }}>➕ New Order</button>
          <button onClick={exit} style={{ background: "#273449", color: "#fff", border: "none", borderRadius: 8, padding: "8px 16px", fontWeight: 800, fontSize: 13, cursor: "pointer" }}>✕ Exit</button>
        </div>
      </div>

      <div style={{ padding: "20px", maxWidth: 1200, margin: "0 auto" }}>
        {waiterTab === "tables" && (
          <TableStatusBoard orders={combinedOrders} tables={20} compact={false} isDark={true} showStats onTableClick={(o) => setTarget(o)} onEmptyTableClick={(t) => openNew(t)} />
        )}
        
        {waiterTab === "parcel" && (
          <div style={{ color: "#fff" }}>
            <h2 style={{ margin: "0 0 20px", fontSize: 22, fontWeight: 800, display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ fontSize: 28 }}>🛍️</span> Running Parcels
            </h2>
            <div style={{ display: "grid", gridTemplateColumns: viewMode === "desktop" ? "repeat(auto-fill, minmax(300px, 1fr))" : "1fr", gap: 12 }}>
              {orders.filter(o => o.orderType === "parcel" && o.status !== "served" && o.status !== "cancelled" && !o.paid).map(o => (
                <div key={o.id} onClick={() => setTarget(o)} style={{ background: "#161F2F", border: "1px solid #273449", borderRadius: 12, padding: 14, cursor: "pointer" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                    <span style={{ color: "#FCD34D", fontWeight: 800 }}>#{o.id.slice(1,5).toUpperCase()}</span>
                    <span style={{ color: "#9CA3AF", fontSize: 12 }}>{timeAgo(o.createdAt)}</span>
                  </div>
                  <div style={{ color: "#fff", fontSize: 14, marginBottom: 8 }}>
                    {o.customer?.name || "Walk-in"} {o.customer?.phone ? `(${o.customer.phone})` : ""}
                  </div>
                  <div style={{ color: "#9CA3AF", fontSize: 13, marginBottom: 8 }}>
                    {o.items?.length || 0} items · ₹{getOrderTotal(o)}
                  </div>
                  <div style={{ background: "#3B82F6", color: "#fff", padding: "8px 0", textAlign: "center", borderRadius: 8, fontWeight: 800, fontSize: 13 }}>Open POS</div>
                </div>
              ))}
              {orders.filter(o => o.orderType === "parcel" && o.status !== "served" && o.status !== "cancelled" && !o.paid).length === 0 && (
                <div style={{ gridColumn: "1 / -1", textAlign: "center", padding: 40, color: "#8B9BB4", fontStyle: "italic" }}>No running parcel orders</div>
              )}
            </div>
          </div>
        )}

        {waiterTab === "kitchen" && (
          <div style={{ color: "#fff" }}>
            <h2 style={{ margin: "0 0 20px", fontSize: 22, fontWeight: 800, color: "#fff", display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ fontSize: 28 }}>🧑‍🍳</span> Live Kitchen Orders
            </h2>
            <div style={{ display: "grid", gridTemplateColumns: viewMode === "desktop" ? "repeat(3, minmax(0, 1fr))" : "1fr", gap: 16 }}>
              {["new", "preparing", "ready"].map((status) => {
                const list = orders.filter(o => o.status === status);
                return (
                  <div key={status} style={{ background: "#161F2F", border: "1px solid #273449", borderRadius: 18, padding: 20 }}>
                    <div style={{ display: "flex", gap: 10, marginBottom: 20, alignItems: "center" }}>
                      <div style={{ width: 12, height: 12, borderRadius: "50%", background: STATUS_COLOR[status] || "#fff" }} />
                      <div style={{ fontSize: 15, textTransform: "uppercase", fontWeight: 800, letterSpacing: "0.05em", color: STATUS_COLOR[status] || "#fff" }}>{STATUS_LABEL[status] || status}</div>
                      <span style={{ fontSize: 13, background: STATUS_COLOR[status] || "#fff", color: "#0B111A", padding: "3px 10px", borderRadius: 14, fontWeight: 800, marginLeft: "auto" }}>{list.length}</span>
                    </div>
                    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                      {list.map((o) => (
                        <div key={o.id} onClick={() => setTarget(o)} style={{ background: "#1F2937", border: "2px solid #374151", borderRadius: 12, padding: 14, cursor: "pointer", transition: "all 0.2s" }}>
                          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10, alignItems: "center" }}>
                            <div style={{ fontSize: 16, fontWeight: 800, color: "#FCD34D" }}>
                              {o.orderType === "parcel" ? "🛍️ PARCEL" : `🍽️ Table ${o.table}`}
                            </div>
                            <div style={{ fontSize: 12, fontWeight: 700, color: "#9CA3AF" }}>{timeAgo(o.createdAt)}</div>
                          </div>
                          <div style={{ borderTop: "1.5px dashed #374151", paddingTop: 10, marginBottom: 12 }}>
                            {(o.items || []).map((it, idx) => (
                              <div key={idx} style={{ fontSize: 14, marginBottom: 6, fontWeight: 600, color: "#E5E7EB" }}>
                                <span style={{ fontWeight: 800, display: "inline-block", width: 28 }}>{it.qty}×</span> {it.name}
                              </div>
                            ))}
                          </div>
                          <div style={{ display: "flex", gap: 8 }}>
                            <button onClick={(e) => { e.stopPropagation(); advanceStatus(o.id, status); }} style={{ flex: 1, padding: "10px 8px", border: "none", borderRadius: 10, fontWeight: 800, fontSize: 13, cursor: "pointer", background: STATUS_COLOR[status] || "#38BDF8", color: "#0B111A" }}>
                              {status === "new" ? "👨‍🍳 Start Cooking" : status === "preparing" ? "✅ Mark Ready" : "🍽️ Mark Served"}
                            </button>
                          </div>
                        </div>
                      ))}
                      {list.length === 0 && (
                        <div style={{ textAlign: "center", padding: "40px 0", color: "#6B7280", fontSize: 14, fontStyle: "italic" }}>No orders</div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {target && (
        <div style={{ position: "fixed", inset: 0, zIndex: 99999, background: "#0B111A", overflow: "hidden", height: "100dvh", display: "flex", flexDirection: "column" }}>
          <POSController
            key={target.id}
            initialOrder={target}
            orders={orders} menu={menu} categories={categories} viewMode={viewMode}
            placeOrder={placeOrder} advanceStatus={advanceStatus} setMenuState={setMenuState}
            waiterMode={true}
            onDraftChange={handleDraftChange}
            onClose={() => setTarget(null)}
          />
        </div>
      )}
    </div>
  );
}

// ==
// 16. CUSTOMER VIEW
// ==

// 🛍️ Parcel timing: roz 11:00 AM - 10:00 PM (India time)
const PARCEL_OPEN = 11, PARCEL_CLOSE = 22;
const parcelOpenNow = () => {
  const ist = new Date(Date.now() + (new Date().getTimezoneOffset() + 330) * 60000);
  const h = ist.getHours() + ist.getMinutes() / 60;
  return h >= PARCEL_OPEN && h < PARCEL_CLOSE;
};
const PARCEL_MSG = "🛍️ Parcel order roz subah 11 baje se raat 10 baje tak hi liya jata hai. Abhi Dine-in order kar sakte ho.";

const openUpiApp = (amount, ref) => {
  const am = Math.max(0, Math.round((Number(amount) || 0) * 100) / 100);
  const note = "Order " + String(ref || "").replace(/^O/i, "").slice(0, 6).toUpperCase();
  const url = "upi://pay?pa=" + encodeURIComponent(RESTAURANT.upiId) + "&pn=" + encodeURIComponent(RESTAURANT.name) + "&am=" + am + "&cu=INR&tn=" + encodeURIComponent(note);
  const isMobile = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent || "");
  if (!isMobile) {
    const qr = "https://api.qrserver.com/v1/create-qr-code/?size=260x260&data=" + encodeURIComponent(url);
    const w = window.open("", "_blank");
    if (w) { w.document.write('<h3>Scan karke pay karo</h3><img src="' + qr + '"/>'); w.document.close(); }
    else alert("UPI ID: " + RESTAURANT.upiId + " Amount: Rs " + am);
    return;
  }
  window.location.href = url;
};

function CustomerView({ menu, orders, placeOrder, bookEvent, gallery, offersList, table, setTable, requestPinPrompt, settings, isDark, setIsDark, requestWaiter, loyaltyRules, loyaltyUsers, coinHistory, setOrdersState, categories, flashSaleItems, comboOffers, setMenuState, setLoyaltyRules, advanceStatus }) {
  const [category, setCategory] = useState(categories[0] || "Thali");
  /* ENP-CAT-FIRST */ const [catPickerOpen, setCatPickerOpen] = useState(true);
  const [viewMode, setViewMode] = useViewMode();
  const cartRef = useRef({});
  const lastStatusRef = useRef({});
  const payIdRef = useRef(null);
  const pendingOrderIdRef = useRef(null);
  const aiTimerRef = useRef(null);
  const waiterLock = usePinLockout();  const [cart, setCart] = useState({});
  const [showAiModal, setShowAiModal] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [showSidebar, setShowSidebar] = useState(false);
  const [activeModal, setActiveModal] = useState(null);
  const [myOrderIds, setMyOrderIds] = useState([]);
  const [orderType, setOrderType] = useState("dine_in");
  const [custName, setCustName] = useState(() => localStorage.getItem("enp_cust_name") || "");
  const [custPhone, setCustPhone] = useState(() => localStorage.getItem("enp_cust_phone") || "");
  const [custAddress, setCustAddress] = useState("");
  const [custPinCode, setCustPinCode] = useState("");
  const [custExactAddress, setCustExactAddress] = useState("");
  const [notes, setNotes] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [vegOnly, setVegOnly] = useState(false);
  const [toast, setToast] = useState(null);
  const [toastType, setToastType] = useState('info');
  const [aiSuggestion, setAiSuggestion] = useState(null);
  const [claimedReward, setClaimedReward] = useState(null);
  const [otpStep, setOtpStep] = useState("phone");
  const [otpCode, setOtpCode] = useState("");
  const [generatedOtp, setGeneratedOtp] = useState("");
  const [isLoggedIn, setIsLoggedIn] = useState(() => localStorage.getItem("enp_cust_logged_in") === "true");
  const [couponCode, setCouponCode] = useState("");
  const [appliedDiscount, setAppliedDiscount] = useState(0);
  const [couponMin, setCouponMin] = useState(0);
  const [bookType, setBookType] = useState("table");
  const [bookData, setBookData] = useState({ name: "", phone: "", date: "", time: "", guests: "" });
  const [confirmedBooking, setConfirmedBooking] = useState(null);
  const [favorites, setFavorites] = useLocalStorage('favorites', []);
  const [scheduleDate, setScheduleDate] = useState("");
  const [scheduleTime, setScheduleTime] = useState("");
  const [isScheduled, setIsScheduled] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState("cash");
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [activeOrderIdForChat, setActiveOrderIdForChat] = useState(null);
  const [runningOrderId, setRunningOrderId] = useState(null);
  const [otpSending, setOtpSending] = useState(false);
  const [resendIn, setResendIn] = useState(0);
  useEffect(() => {
    if (resendIn <= 0) return;
    const t = setTimeout(() => setResendIn((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [resendIn]);

  cartRef.current = cart;
  const settingsRef = useRef(settings);
  settingsRef.current = settings;
    const visibleCategories = useMemo(() => {
    const hidden = settings?.hiddenCategories || [];
    const actualMenuCats = Array.from(new Set(menu.map((m) => m.category).filter(Boolean)));
    const matched = categories.filter((c) => actualMenuCats.includes(c) && !hidden.includes(c));
    const extras = actualMenuCats.filter((c) => !categories.includes(c) && !hidden.includes(c));
    const finalCats = [...matched, ...extras];
    return finalCats.length > 0 ? finalCats : actualMenuCats;
  }, [categories, menu, settings?.hiddenCategories]);
  useEffect(() => {
    if (visibleCategories.length > 0 && !visibleCategories.includes(category)) setCategory(visibleCategories[0]);
  }, [visibleCategories, category]);
  useEffect(() => () => clearTimeout(aiTimerRef.current), []);
 
  const [showWaiterMode, setShowWaiterMode] = useState(wasWaiterOpen);
    const [showWaiterPinModal, setShowWaiterPinModal] = useState(false);
  const [waiterPinInput, setWaiterPinInput] = useState("");
  const [waiterEmail, setWaiterEmail] = useState("");
  useEffect(() => {
  try { sessionStorage.setItem(WAITER_FLAG, showWaiterMode ? "1" : "0"); } catch (e) {}
}, [showWaiterMode]);
  const [waiterUnlocked, setWaiterUnlocked] = useState(wasWaiterOpen);

  // 🎂 DOB popup (login ke baad)
  const [showDobModal, setShowDobModal] = useState(false);
  const [dobInput, setDobInput] = useState("");
  const [dobSaving, setDobSaving] = useState(false);
  const [dobErr, setDobErr] = useState("");
  useEffect(() => {
    if (!isLoggedIn || waiterUnlocked) return;
    const p = String(custPhone || "").replace(/\D/g, "").slice(-10);
    if (p.length !== 10) return;
    let off = false;
    (async () => {
      try {
        if (localStorage.getItem("enp_dob_done_" + p) === "1") return;
        const skipAt = Number(localStorage.getItem("enp_dob_skip_" + p) || 0);
        if (Date.now() - skipAt < 3 * 86400000) return;
        let hasDob = false;
        try {
          const s = await getDoc(doc(db, "customers", p));
          hasDob = s.exists() && !!s.data().dob;
        } catch (e) {}
        if (off) return;
        if (hasDob) { localStorage.setItem("enp_dob_done_" + p, "1"); return; }
        setShowDobModal(true);
      } catch (e) {}
    })();
    return () => { off = true; };
  }, [isLoggedIn, custPhone]);
  const saveDob = async () => {
    const p = String(custPhone || "").replace(/\D/g, "").slice(-10);
    if (!dobInput) { setDobErr("Apni date of birth chuno"); return; }
    if (new Date(dobInput) > new Date()) { setDobErr("Future ki date nahi chalegi"); return; }
    setDobErr(""); setDobSaving(true);
    try {
      await setDoc(doc(db, "customers", p), { phone: p, name: custName || "Guest", dob: dobInput, dobSavedAt: Date.now() }, { merge: true });
      try { localStorage.setItem("enp_dob_done_" + p, "1"); } catch (e) {}
      setShowDobModal(false);
      showToast("🎂 Thanks! Birthday pe special offer milega", "success");
    } catch (e) { console.error("DOB save:", e); setDobErr("Save nahi hua: " + (e.code || e.message)); }
    finally { setDobSaving(false); }
  };
  const skipDob = () => {
    const p = String(custPhone || "").replace(/\D/g, "").slice(-10);
    try { localStorage.setItem("enp_dob_skip_" + p, String(Date.now())); } catch (e) {}
    setShowDobModal(false);
  };

useEffect(() => {
  if (!showWaiterMode) return;
  window.history.pushState({ w: 1 }, "");
  const onPop = () => window.history.pushState({ w: 1 }, "");
  window.addEventListener("popstate", onPop);
  return () => window.removeEventListener("popstate", onPop);
}, [showWaiterMode]);

  const filteredItems = useMemo(() => {
    const _hid = settings?.hiddenCategories || [];
    const _veg = !!settings?.vegMode;
    const _vis = (m) => (!_veg || m.veg) && [m.category, ...(m.alsoIn || [])].some((c) => !_hid.includes(c));
    let items = (searchQuery.trim() ? menu : menu.filter((m) => m.category === category || (m.alsoIn || []).includes(category))).filter(_vis);
    items = items.filter((m) => {
      if (vegOnly && !m.veg) return false;
if (searchQuery.trim()) { const q = searchQuery.toLowerCase(); return (m.name || "").toLowerCase().includes(q) || (m.desc || "").toLowerCase().includes(q); }      return true;
    });
    return items;
  }, [menu, category, searchQuery, vegOnly, settings]);

  let emptyReason = 'category_empty';
  if (vegOnly) emptyReason = 'veg_filtered';
  else if (searchQuery && searchQuery.trim() !== '') emptyReason = 'search_no_results';

  const cartItems = Object.entries(cart).filter(([id, entry]) => getCartQty(entry) > 0 && menu.some(m => m.id === id));
const cartCount = cartItems.reduce((s, [, entry]) => s + getCartQty(entry), 0);
const subtotal = cartItems.reduce((s, [id, entry]) => {
  const item = menu.find((m) => m.id === id);
  return s + getCartLineTotal(entry, item);
}, 0);
  const deliveryFee = orderType === "parcel" ? 40 : 0;
  useEffect(() => { if (appliedDiscount > 0 && subtotal < couponMin) setAppliedDiscount(0); }, [appliedDiscount, couponMin, subtotal]);
  const discountAmount = Math.round((subtotal * appliedDiscount) / 100);


  const cartTotal = Math.max(0, subtotal - discountAmount) + deliveryFee;
  const [myLoyalty, setMyLoyalty] = useState(null);
  useEffect(() => {
    const _p = HX.cleanPhone(custPhone);
    if (!HX.isValidPhone(_p)) { setMyLoyalty(null); return; }
    let off = false;
    getDoc(doc(db, "loyaltyUsers", _p)).then((s) => { if (!off) setMyLoyalty(s.exists() ? s.data() : null); }).catch(() => {});
    return () => { off = true; };
  }, [custPhone]);
  const activeUser = isLoggedIn ? (loyaltyUsers.find(u => u.phone === custPhone) || myLoyalty) : null;

// 👇 VIP wala code yahan aayega 👇
const isVip = activeUser?.isVip === true;
const vipDiscount = isVip ? Math.round(subtotal * 0.20) : 0; 

const currentCoins = activeUser ? activeUser.coins : 0;
const loyaltyTier = getLoyaltyTier(currentCoins);
const loyaltyDiscount = activeUser && appliedDiscount === 0 ? Math.round(loyaltyTier.discount * subtotal) : 0;

// Final Total (isme vipDiscount minus ho raha hai)
const finalTotal = Math.max(0, subtotal - discountAmount - loyaltyDiscount - vipDiscount) + deliveryFee;
const newEarnedCoins = Math.floor(finalTotal / (Number(loyaltyRules?.rate) || 10));
  const myActiveOrders = orders.filter(o => myOrderIds.includes(o.id) && o.status !== "served" && o.status !== "cancelled");
  const [pastOrders, setPastOrders] = useState([]);
  useEffect(() => {
    if (activeModal !== "orderHistory") return;
    const missing = myOrderIds.slice(-15).filter(id => !orders.some(o => o.id === id));
    if (missing.length === 0) return;
    let off = false;
    Promise.all(missing.map(id => getDoc(doc(db, "orders", id)).then(s => (s.exists() ? { id: s.id, ...s.data(), items: s.data().items || [] } : null)).catch(() => null)))
      .then(list => { if (!off) setPastOrders(list.filter(Boolean)); });
    return () => { off = true; };
  }, [activeModal, myOrderIds.join(",")]);
  const myOrders = [...pastOrders.filter(p => !orders.some(o => o.id === p.id)), ...orders.filter(o => myOrderIds.includes(o.id))].sort((a, b) => a.createdAt - b.createdAt);
  const myCoinLogs = coinHistory.filter(c => c.phone === custPhone);
  const cartQrSrc = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(`upi://pay?pa=${RESTAURANT.upiId}&pn=${encodeURIComponent(RESTAURANT.name)}&am=${finalTotal}&cu=INR`)}`;
  const loyaltyQrSrc = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(`upi://pay?pa=${RESTAURANT.upiId}&pn=${encodeURIComponent(RESTAURANT.name)}&am=999&cu=INR`)}`;

  const toastTimerRef = useRef(null);

const showToast = useCallback((msg, type = 'info') => {
  const config = TOAST_CONFIG[type] || TOAST_CONFIG.info;
  if (type === 'reward' && navigator.vibrate) navigator.vibrate([100, 50, 100]);
  if (type === 'order') playNotificationSound();
  setToast(msg);
  setToastType(type);
  clearTimeout(toastTimerRef.current);
  toastTimerRef.current = setTimeout(() => setToast(null), config.duration);
}, []);

useEffect(() => {
  return () => clearTimeout(toastTimerRef.current);
}, []);

  useEffect(() => {
    const _g = (k) => { try { return localStorage.getItem(k); } catch (e) { return null; } };
    const savedCustomer = _g('eatpark_customer');

    if (savedCustomer) { try { const data = JSON.parse(savedCustomer); if (data.name) setCustName(data.name); if (data.phone) setCustPhone(data.phone); if (data.address) setCustAddress(data.address); /* isLoggedIn localStorage se restore nahi hoga */
 } catch (e) { } }
    const savedCart = _g('eatpark_cart');
if (savedCart) {
  try {
    const parsed = JSON.parse(savedCart);
    const migrated = {};
    Object.entries(parsed).forEach(([id, val]) => {
      if (typeof val === 'number') migrated[id] = { qty: val };
      else migrated[id] = { qty: Number(val?.qty) || 0 };
    });
    setCart(migrated);
  } catch (e) {}
}
    const savedOrders = _g('eatpark_orders');
    if (savedOrders) { try { const ordersData = JSON.parse(savedOrders); setMyOrderIds(ordersData.map(o => o.id)); } catch (e) { } }
    /* permission ab staff login par maangi jati hai */
  }, []);

  useEffect(() => {
    if (custName || custPhone) safeSet('eatpark_customer', { name: custName, phone: custPhone, address: custAddress, isLoggedIn });
  }, [custName, custPhone, custAddress, isLoggedIn]);

  useEffect(() => {
    try {
      if (Object.keys(cart).length > 0) localStorage.setItem('eatpark_cart', JSON.stringify(cart));
      else localStorage.removeItem('eatpark_cart');
    } catch (e) {}
  }, [cart]);

  useEffect(() => {
    if (myOrderIds.length === 0) return;
    const unsubs = myOrderIds.slice(-3).map(id => {
      return onSnapshot(doc(db, "orders", id), (snap) => {
        if (!snap.exists()) return;
        const data = snap.data();
        const prevStatus = lastStatusRef.current[id]; lastStatusRef.current[id] = data.status;
        if (prevStatus && prevStatus !== data.status) {
          const labels = { new: "🍽️ Received", preparing: "👨‍🍳 Cooking", ready: "✅ Ready!", out_for_delivery: "🛵 Out for Delivery", served: "🎉 Delivered" };
          showToast(`${labels[data.status] || data.status} — Order #${id.slice(1, 5)}`, 'order');
        }
      });
    });
    return () => unsubs.forEach(u => u());
  }, [myOrderIds.join(",")]);

  // Login ke baad apne saare orders (Firebase se) apne aap load ho jayein
  useEffect(() => {
    if (!isLoggedIn) return;
    const uid = auth.currentUser && auth.currentUser.uid;
    if (!uid) return;
    const mine = orders.filter((o) => o.createdBy === uid).map((o) => o.id);
    if (mine.length === 0) return;
    setMyOrderIds((prev) => {
      const next = Array.from(new Set([...prev, ...mine]));
      return next.length === prev.length ? prev : next;
    });
  }, [orders, isLoggedIn]);

  // Page reload / naya device: phone-verified session ho to login apne aap ho jaye
  useEffect(() => {
    return onAuthStateChanged(auth, (u) => {
      if (u && u.phoneNumber) {
        setCustPhone(u.phoneNumber.replace(/\D/g, "").slice(-10));
        localStorage.setItem("enp_cust_logged_in", "true");
      localStorage.setItem("enp_cust_phone", custPhone);
      localStorage.setItem("enp_cust_name", custName);
      setIsLoggedIn(true);
      }
    });
  }, []);

  const handleSetQty = useCallback((id, q) => {
    const prevCart = cartRef.current;
    const oldQty = getCartQty(prevCart[id]);
    const flashRow = flashSaleItems.find(f => f.active && f.id === id && f.stock != null && prevCart[id]?.priceOverride === f.discountPrice);
    if (flashRow && q > flashRow.stock) { showToast(`⚠️ Sirf ${flashRow.stock} bache hain`, 'warning'); return; }
    if (q > oldQty && q === 1) {
      const _s = settingsRef.current || {};
      const options = getSmartSuggestionPool(menu.filter((m) => (!_s.vegMode || m.veg) && !(_s.hiddenCategories || []).includes(m.category)), prevCart);
      if (options.length > 0) {
        setAiSuggestion(options[Math.floor(Math.random() * options.length)]);
        clearTimeout(aiTimerRef.current);
        aiTimerRef.current = setTimeout(() => setAiSuggestion(null), 6000);
      }
    }

    setCart((prev) => {
      const next = { ...prev };
      if (q <= 0) delete next[id];
      else {
        const existingOverride = prev[id]?.priceOverride;
        next[id] = existingOverride != null ? { qty: q, priceOverride: existingOverride, ovQty: prev[id].ovQty } : { qty: q };
      }
      return next;
    });
  }, [menu, flashSaleItems, showToast]);

    const toggleFavorite = useCallback((itemId) => {
    if (favorites.includes(itemId)) {
      setFavorites(favorites.filter(id => id !== itemId));
      showToast('Removed from favorites', 'info');
    } else {
      setFavorites([...favorites, itemId]);
      showToast('Added to favorites!', 'success');
 
    }
  }, [favorites, setFavorites, showToast]);
  const toggleFavoriteOld = useCallback((itemId) => {
    setFavorites(prev => {
      if (prev.includes(itemId)) { showToast('Removed from favorites', 'info'); return prev.filter(id => id !== itemId); }
      showToast('Added to favorites!', 'success');
      return [...prev, itemId];
    });
  }, [setFavorites, showToast]);

  const sendPushNotification = useCallback((title, message) => {
    if ('Notification' in window && Notification.permission === 'granted') {
      safeNotify(title, { body: message, icon: '/icon-192.png' });
    }
  }, []);

  const cancelOrder = useCallback(async (orderId) => {
    // 🆕 Check karo ki order abhi bhi "new" status me hai ya nahi
    const order = orders.find(o => o.id === orderId);
    if (!order) return;
    
    if (order.status !== 'new') {
      showToast("⚠️ Khana ban chuka hai (Cooking shuru), ab cancel nahi ho sakta. Restaurant se baat karein.", 'error');
      return;
    }

    if (!window.confirm("Kya aap sach me ye order cancel karna chahte hain?")) return;
    
    try {
      await updateDoc(doc(db, "orders", orderId), { status: "cancelled", cancelledAt: Date.now() });
      setOrdersState(prev => prev.map(o => o.id === orderId ? { ...o, status: "cancelled" } : o));
      showToast("❌ Order cancelled", 'warning');
    } catch (e) { 
      console.error(e);
      showToast("⚠️ Failed to cancel. Server rules ne block kiya.", 'error'); 
    }
  }, [orders, setOrdersState, showToast]);

  const reorderOrder = useCallback((order) => {
    const newCart = {};
    order.items.forEach(item => {
      if (!menu.some(m => m.id === item.itemId)) return;
      newCart[item.itemId] = { qty: getCartQty(newCart[item.itemId]) + item.qty };
    });
    if (Object.keys(newCart).length === 0) { showToast("⚠️ Ye items ab menu mein nahi hain", 'warning'); return; }
    setCart(newCart);
    setCartOpen(true);
    showToast("🔄 Items added to cart!", 'success');
  }, [menu, showToast]);
  const reorderOrderOld = useCallback((order) => {
    const newCart = {};
    order.items.forEach(item => { newCart[item.itemId] = (newCart[item.itemId] || 0) + item.qty; });
    setCart(newCart);
    setCartOpen(true);
    showToast("🔄 Items added to cart!", 'success');
  }, [showToast]);

  const addRunningItems = useCallback(async (orderId, newItems) => {
    try {
      let taggedItems = [];
      let tableNo = "";
      await runTransaction(db, async (tx) => {
        const ref = doc(db, "orders", orderId);
        const snap = await tx.get(ref);
        if (!snap.exists()) throw new Error("Order not found");
        const o = snap.data();
        if (o.status === "cancelled") throw new Error("Order cancelled hai");
        const baseKots = (o.kots?.length
          ? o.kots
          : [{ id: uid("kot"), kotNumber: 1, items: o.items, createdAt: o.createdAt, status: o.status }]
        ).map(k => (k.status === "new" && o.status !== "new") ? { ...k, status: o.status } : k);
        const nextNo = Math.max(...baseKots.map(k => k.kotNumber || 1)) + 1;
        taggedItems = newItems.map(it => ({ ...it, kotNumber: nextNo }));
        tableNo = o.table;
        tx.update(ref, {
          kots: [...baseKots, { id: uid("kot"), kotNumber: nextNo, items: taggedItems, createdAt: Date.now(), status: "new", isRunning: true }],
          items: [...(o.items || []), ...taggedItems],
          ...runningPatch(o, taggedItems),
          status: "new",
          lastKotAt: Date.now()
        });
      });
      const addedTotal = taggedItems.reduce((s, it) => s + it.price * it.qty, 0);
      const waText = `🍳 *RUNNING KOT* — Order #${orderId.slice(1, 5).toUpperCase()}\nTable ${tableNo}\n` + taggedItems.map(i => `• ${i.qty}x ${i.name}`).join("\n") + `\n\nAdditional: ₹${addedTotal}`;
      /* WhatsApp band */
      setRunningOrderId(null);
      showToast("🍳 New KOT sent to kitchen!", "success");
    } catch (e) { console.error(e); showToast("⚠️ Failed to add items", "error"); }
  }, [showToast]);
  const addRunningItemsPrev = useCallback(async (orderId, newItems) => {
    try {
      const order = orders.find(o => o.id === orderId);
      if (!order) return;
      const baseKots = order.kots?.length
        ? order.kots
        : [{ id: uid("kot"), kotNumber: 1, items: order.items, createdAt: order.createdAt, status: order.status }];
      const existingKots = baseKots.map(k => (k.status === "new" && order.status !== "new") ? { ...k, status: order.status } : k);
      const nextKotNumber = Math.max(...existingKots.map(k => k.kotNumber || 1)) + 1;
      const taggedItems = newItems.map(it => ({ ...it, kotNumber: nextKotNumber }));
      const newKot = { id: uid("kot"), kotNumber: nextKotNumber, items: taggedItems, createdAt: Date.now(), status: "new", isRunning: true };
      const updatedKots = [...existingKots, newKot];
      const updatedItems = [...order.items, ...taggedItems];
      const addedTotal = taggedItems.reduce((s, it) => s + it.price * it.qty, 0);
      await updateDoc(doc(db, "orders", orderId), { kots: updatedKots, items: updatedItems, status: "new", lastKotAt: Date.now() });
      const waText = `🍳 *RUNNING KOT* — Order #${orderId.slice(1, 5).toUpperCase()}\nTable ${order.table}\n` + taggedItems.map(i => `• ${i.qty}x ${i.name}`).join("\n") + `\n\nAdditional: ₹${addedTotal}`;
/* WhatsApp band */      setRunningOrderId(null);
      showToast("🍳 New KOT sent to kitchen!", "success");
    } catch (e) { console.error(e); showToast("⚠️ Failed to add items", "error"); }
  }, [orders, showToast]);
  const addRunningItemsOld = useCallback(async (orderId, newItems) => {
    try {
      const order = orders.find(o => o.id === orderId);
      if (!order) return;
      const nextKotNumber = (order.kots?.length || 1) + 1;
      const taggedItems = newItems.map(it => ({ ...it, kotNumber: nextKotNumber }));
      const newKot = { id: uid("kot"), kotNumber: nextKotNumber, items: taggedItems, createdAt: Date.now(), status: "new", isRunning: true };
      const updatedKots = [...(order.kots || [{ id: uid("kot"), kotNumber: 1, items: order.items, createdAt: order.createdAt, status: "new" }]), newKot];
      const updatedItems = [...order.items, ...taggedItems];
      const addedTotal = taggedItems.reduce((s, it) => s + it.price * it.qty, 0);
      await updateDoc(doc(db, "orders", orderId), { kots: updatedKots, items: updatedItems, status: "new", lastKotAt: Date.now() });
      const waText = `🍳 *RUNNING KOT* — Order #${orderId.slice(1, 5).toUpperCase()}\nTable ${order.table}\n` + taggedItems.map(i => `• ${i.qty}x ${i.name}`).join("\n") + `\n\nAdditional: ₹${addedTotal}`;
      window.open(`https://wa.me/${RESTAURANT.whatsapp}?text=${encodeURIComponent(waText)}`, "_blank");
      setRunningOrderId(null);
      showToast("🍳 New KOT sent to kitchen!", "success");
    } catch (e) { showToast("⚠️ Failed to add items", "error"); }
  }, [orders, showToast]);

  const handleWaiterOrder = useCallback(async ({ table: t, orderType: ot, items, waiterName, customerName, customerPhone, notes: orderNotes }) => {
    const orderId = uid("o");
    const total = items.reduce((s, it) => s + it.price * it.qty, 0);
    const order = {
      id: orderId, table: t, orderType: ot || "dine_in",
      customer: { name: customerName, phone: customerPhone || "WALK-IN", address: "" },
      items, waiter: waiterName || "Staff", takenBy: "waiter",
      kots: [{ id: uid("kot"), kotNumber: 1, items: items.map(it => ({ ...it, kotNumber: 1 })), createdAt: Date.now(), status: "new", isRunning: false }],
      notes: orderNotes, payment: "cash", paymentStatus: "pending",
      status: "new", paid: false, createdAt: Date.now(),
      coinsClaimed: true, earnedCoins: 0, rewardUsedCoins: 0,
      deliveryFee: 0, loyaltyDiscount: 0, discount: 0,
      subtotal: total, finalTotal: total
    };
    await placeOrder(order);
    playNotificationSound();
    const typeLabel = ot === "parcel" ? "🛍️ *PARCEL ORDER*" : `🍽️ Table ${t}`;
    const waText = `🧑‍🍳 *WAITER ORDER* (#${orderId.slice(1, 5).toUpperCase()})\n${typeLabel} · Waiter: ${waiterName || "Staff"}\nCustomer: ${customerName}\n` + items.map(i => `• ${i.qty}x ${i.name}`).join("\n") + (orderNotes ? `\nNotes: ${orderNotes}` : "") + `\n\nTotal: ₹${total}`;
    window.open(`https://wa.me/${RESTAURANT.whatsapp}?text=${encodeURIComponent(waText)}`, "_blank");
    return order;
  }, [placeOrder]);
  
  const handleWaiterOrderOld = useCallback(async ({ table: t, items, waiterName, customerName, customerPhone, notes: orderNotes }) => {
    const orderId = uid("o");
    const total = items.reduce((s, it) => s + it.price * it.qty, 0);
    const order = {
      id: orderId, table: t, orderType: "dine_in",
      customer: { name: customerName, phone: customerPhone || "WALK-IN", address: "" },
      items, waiter: waiterName || "Staff", takenBy: "waiter",
      kots: [{ id: uid("kot"), kotNumber: 1, items: items.map(it => ({ ...it, kotNumber: 1 })), createdAt: Date.now(), status: "new", isRunning: false }],
      notes: orderNotes, payment: "cash", paymentStatus: "pending",
      status: "new", paid: false, createdAt: Date.now(),
      coinsClaimed: true, earnedCoins: 0, rewardUsedCoins: 0,
      deliveryFee: 0, loyaltyDiscount: 0, discount: 0
    };
    await placeOrder(order, 0);
    playNotificationSound();
    const waText = `🧑‍🍳 *WAITER ORDER* (#${orderId.slice(1, 5).toUpperCase()})\nTable ${t} · Waiter: ${waiterName || "Staff"}\nCustomer: ${customerName}\n` + items.map(i => `• ${i.qty}x ${i.name}`).join("\n") + (orderNotes ? `\nNotes: ${orderNotes}` : "") + `\n\nTotal: ₹${total}`;
    window.open(`https://wa.me/${RESTAURANT.whatsapp}?text=${encodeURIComponent(waText)}`, "_blank");
       return order;
  }, [placeOrder, showToast]);

const handleWaiterPinSubmit = async () => {
  if (!waiterEmail.trim() || !waiterPinInput) { showToast("⚠️ Email aur password daalo", "error"); return; }
  try {
    const cred = await signInWithEmailAndPassword(auth, waiterEmail.trim(), waiterPinInput);
    const s = await getDoc(doc(db, "staff", cred.user.uid));
    if (!s.exists()) { await signOut(auth); showToast("❌ Ye account staff/waiter ka nahi hai", "error"); setWaiterPinInput(""); return; }
    setWaiterUnlocked(true); setShowWaiterPinModal(false); setWaiterPinInput(""); setShowWaiterMode(true);
    showToast("🔓 Waiter Mode Unlocked!", "success");
  } catch (e) { console.error(e); showToast("❌ Login fail: " + (e.code || e.message), "error"); setWaiterPinInput(""); }
};
const handleWaiterPinSubmitUnused = () => {
  if (waiterLock.isLocked()) {
    showToast(`⏳ Bahut galat attempts. ${waiterLock.secondsLeft()}s ruko`, "error");
    setWaiterPinInput("");
    return;
  }
  const wPin = (settings?.waiterPin ?? "1234").toString().trim();
  const sPin = (settings?.staffPin ?? "5432").toString().trim();
  const aPin = (settings?.adminPin ?? "9876").toString().trim();
  if (waiterPinInput === wPin || waiterPinInput === sPin || waiterPinInput === aPin) {
    waiterLock.reset();
    setWaiterUnlocked(true);
    setShowWaiterPinModal(false);
    setWaiterPinInput("");
    setShowWaiterMode(true);
    showToast("🔓 Waiter Mode Unlocked!", "success");
  } else {
    waiterLock.registerFail();
    showToast("❌ Incorrect Waiter PIN", "error");
    setWaiterPinInput("");
  }
};
const handleWaiterPinSubmitOld = () => {
  const wPin = (settings?.waiterPin ?? "1234").toString().trim();
  const sPin = (settings?.staffPin ?? "5432").toString().trim();
  const aPin = (settings?.adminPin ?? "9876").toString().trim();
    if (waiterPinInput === wPin || waiterPinInput === sPin || waiterPinInput === aPin) {
      setWaiterUnlocked(true);
      setShowWaiterPinModal(false);
      setWaiterPinInput("");
      setShowWaiterMode(true);
      showToast("🔓 Waiter Mode Unlocked!", "success");
    } else {
      showToast("❌ Incorrect Waiter PIN", "error");
      setWaiterPinInput("");
    }
  };

  const otpConfRef = useRef(null);
  const otpRecRef = useRef(null);
  useEffect(() => {
    if (DEMO_OTP) return;
    const u = auth.currentUser;
    const p = String(custPhone || "").replace(/\D/g, "").slice(-10);
    setIsLoggedIn(!!(u && u.phoneNumber && u.phoneNumber === "+91" + p));
  }, [custPhone]);
  const handleSendOtp = async () => {
    if (otpSending || resendIn > 0) return;
    if (!String(custName || "").trim()) { showToast("⚠️ Pehle apna naam daalo", 'error'); return; }
    const p = String(custPhone || "").replace(/\D/g, "").slice(-10);
    if (p.length !== 10) { showToast("⚠️ 10 digit phone daalo", 'error'); return; }
    if (DEMO_OTP) { handleSendOtpDemo(); return; }
    setOtpSending(true);
    try {
      const u = auth.currentUser || await ensureUser();
      if (u.phoneNumber) { setIsLoggedIn(true); showToast("✅ Phone pehle se verified hai", 'success'); return; }
      if (!u.isAnonymous) { showToast("ℹ️ Staff login chal raha hai - pehle logout karo", 'info'); return; }
      if (!otpRecRef.current) {
        otpRecRef.current = new RecaptchaVerifier(auth, "otp-recaptcha", { size: "invisible" });
      }
      otpConfRef.current = await linkWithPhoneNumber(u, "+91" + p, otpRecRef.current);
      setCustPhone(p); setOtpCode(""); setOtpStep("verify"); setResendIn(30);
      showToast("📩 OTP SMS bheja gaya", 'success');
    } catch (e) {
      console.error("OTP send:", e.code, e.message);
      try { otpRecRef.current && otpRecRef.current.clear(); } catch (x) {}
      otpRecRef.current = null;
      const _b = document.getElementById("otp-recaptcha");
      if (_b) _b.innerHTML = "";
      const m = {
        "auth/operation-not-allowed": "Phone SMS blocked: Firebase me SMS region policy me India allow karo",
        "auth/invalid-phone-number": "Phone number galat hai",
        "auth/too-many-requests": "Bahut try ho gaye, thodi der baad try karo",
        "auth/quota-exceeded": "SMS limit khatam (Firebase quota/billing)",
        "auth/captcha-check-failed": "Captcha fail - domain Authorized domains me add karo",
        "auth/billing-not-enabled": "Real SMS ke liye Firebase billing (Blaze) chahiye"
      };
      showToast("❌ " + (m[e.code] || e.code || e.message), 'error');
    } finally {
      setOtpSending(false);
    }
  };
  const handleSendOtpDemo = () => {
    if (!String(custName || "").trim()) { showToast("⚠️ Pehle apna naam daalo", 'error'); return; }
    if (!custPhone || custPhone.length < 10) { showToast("⚠️ Enter valid phone", 'error'); return; }
    if (!DEMO_OTP) {
      showToast("ℹ️ OTP service abhi connected nahi — naam & phone se order karo", 'info');
      return;
    }
    const code = Math.floor(1000 + Math.random() * 9000).toString();
    setGeneratedOtp(code);
    setOtpStep("verify");
    showToast(`🔐 Demo OTP: ${code}`, 'success');
  };
  const handleSendOtpOld = () => {
    if (!custPhone || custPhone.length < 10) { showToast("⚠️ Enter valid phone", 'error'); return; }
    const code = Math.floor(1000 + Math.random() * 9000).toString();
    setGeneratedOtp(code); setOtpStep("verify");
    showToast(`🔐 OTP: ${code}`, 'success');
    alert(`🔐 Demo OTP: ${code}`);
  };
  const handleVerifyOtp = async () => {
    if (!String(custName || "").trim()) { showToast("⚠️ Pehle apna naam daalo", 'error'); return; }
    if (DEMO_OTP && !otpConfRef.current) { handleVerifyOtpDemo(); return; }
    if (!otpConfRef.current) { showToast("⚠️ Pehle OTP bhejo", 'error'); return; }
    const p = String(custPhone || "").replace(/\D/g, "").slice(-10);
    try {
      await otpConfRef.current.confirm(String(otpCode).trim());
    } catch (e) {
      if (e.code === "auth/credential-already-in-use" || e.code === "auth/account-exists-with-different-credential") {
        try {
          const cred = PhoneAuthProvider.credentialFromError(e);
          if (!cred) throw e;
          await signInWithCredential(auth, cred);
        } catch (e2) { showToast("❌ OTP verify fail: " + (e2.code || e2.message), 'error'); return; }
      } else {
        showToast(e.code === "auth/invalid-verification-code" ? "❌ OTP galat hai" : "❌ OTP fail: " + (e.code || e.message), 'error');
        return;
      }
    }
    try { await auth.currentUser.getIdToken(true); } catch (e) {}
    otpConfRef.current = null;
    setIsLoggedIn(true); setOtpStep("phone");
    showToast("✅ Phone verify ho gaya", 'success');
    try {
      const _cref = doc(db, "customers", p);
      const _cs = await getDoc(_cref);
      const _old = _cs.exists() ? _cs.data() : null;
      const _patch = { phone: p, address: custAddress || "", uid: auth.currentUser.uid, lastLogin: Date.now(), loginCount: (Number(_old && _old.loginCount) || 0) + 1 };
      if (!_old) _patch.createdAt = Date.now();
      const _nm = String(custName || "").trim();
      if (_nm) _patch.name = _nm;
      await setDoc(doc(db, "customers", p), _patch, { merge: true });
    } catch (e) {}
  };
  const handleVerifyOtpDemo = () => {
  if (!String(custName || "").trim()) { showToast("⚠️ Pehle apna naam daalo", "error"); return; }
  if (generatedOtp && otpCode === generatedOtp) {
    setIsLoggedIn(true); setOtpStep("phone");
    (async () => {
      try {
        const cleanName = String(custName).trim();
        const userRef = doc(db, "customers", custPhone);
        const userSnap = await getDoc(userRef);
        if (!userSnap.exists()) {
          await setDoc(userRef, { phone: custPhone, name: cleanName, address: custAddress || "", createdAt: Date.now(), lastLogin: Date.now(), totalOrders: 0, totalSpent: 0 });
          showToast("✅ New customer registered!", "success");
        } else {
          await updateDoc(userRef, { lastLogin: Date.now(), name: cleanName });
          showToast("✅ Welcome back!", "success");
        }
        localStorage.setItem("eatpark_customer", JSON.stringify({ name: cleanName, phone: custPhone, address: custAddress, isLoggedIn: true }));
      } catch (error) { console.error(error); }
    })();
  } else showToast("❌ Incorrect OTP", "error");
};
  const handleVerifyOtpOld = () => {
    if (otpCode === generatedOtp || otpCode === "1234") {
      setIsLoggedIn(true); setOtpStep("phone");
      (async () => {
        try {
          const userRef = doc(db, "customers", custPhone);
          const userSnap = await getDoc(userRef);
          if (!userSnap.exists()) {
            await setDoc(userRef, { phone: custPhone, name: custName || "Guest", address: custAddress || "", createdAt: Date.now(), lastLogin: Date.now(), totalOrders: 0, totalSpent: 0 });
            showToast("✅ New customer registered!", 'success');
          } else {
            await updateDoc(userRef, { lastLogin: Date.now(), name: custName || userSnap.data().name });
            showToast("✅ Welcome back!", 'success');
          }
          localStorage.setItem('eatpark_customer', JSON.stringify({ name: custName, phone: custPhone, address: custAddress, isLoggedIn: true }));
        } catch (error) { console.error(error); }
      })();
    } else showToast("❌ Incorrect OTP", 'error');
  };

  const checkExistingCustomer = useCallback(async (phone) => {
    if (phone.length === 10) {
      try {
        const userSnap = await getDoc(doc(db, "customers", phone));
        if (userSnap.exists()) {
          const data = userSnap.data();
          /* privacy: phone type karne se auto-fill / auto-login band */

          /* welcome toast hata diya (naam leak hota tha) */

        }
      } catch (e) { }
    }
  }, [showToast]);

  const handleLogout = async () => {
    if (!window.confirm("Logout karna hai?")) return;
    try { await signOut(auth); } catch (e) { console.error("logout:", e); }
    try {
      localStorage.removeItem("eatpark_customer");
      localStorage.removeItem("eatpark_orders");
      localStorage.removeItem("eatpark_cart");
    } catch (e) {}
    otpConfRef.current = null;
    setWaiterUnlocked(false);
    setShowWaiterMode(false);
    setCustName(""); setCustPhone(""); setCustAddress("");
    setOtpStep("phone"); setOtpCode("");
    setCart({}); setMyOrderIds([]);
    setShowSidebar(false);
    showToast("👋 Logout ho gaye", "info");
  };

  const handleGetLocation = () => {
    if (!navigator.geolocation) { showToast("Geolocation not supported", 'error'); return; }
    showToast("📍 Fetching location...", 'info');
    navigator.geolocation.getCurrentPosition(
      (position) => { 
        const { latitude, longitude } = position.coords; 
        setCustAddress(`Lat: ${latitude.toFixed(5)}, Lng: ${longitude.toFixed(5)}`); 
        showToast("✅ GPS Location aagayi! Ab exact address likhein.", 'success'); 
      },
      () => { showToast("⚠️ Location permission block hai ya GPS off hai.", 'error'); }
    );
  };

  const handleApplyCoupon = () => {
    const code = couponCode.toUpperCase().trim();
    const coupons = {
      "EAT20": { discount: 20, min: 0, ok: () => true, msg: "🎉 20% Applied!" },
      "EATS10": { discount: 10, min: 0, ok: () => true, msg: "🎉 10% Applied!" },
      "WELCOME20": { discount: 20, min: 0, ok: () => myOrderIds.length === 0, msg: "🎉 Welcome 20% Applied!", failMsg: "💳 First order only" },
      "COMEBACK15": { discount: 15, min: 199, ok: () => true, msg: "🎉 15% Applied!" },
      "LOYALTY50": { discount: 50, min: 0, ok: () => currentCoins >= 500, msg: "👑 VIP 50% Applied!", failMsg: "👑 Requires 500+ coins" }
    };
    const coupon = coupons[code];
    if (!coupon) { showToast("❌ Invalid coupon", 'error'); return; }
    if (!coupon.ok()) { showToast(coupon.failMsg || "⚠️ Conditions not met", 'warning'); return; }
    if (subtotal < coupon.min) { showToast(`⚠️ Min ₹${coupon.min} required`, 'warning'); return; }
    setAppliedDiscount(coupon.discount); setCouponMin(coupon.min || 0);
    showToast(coupon.msg, 'success');
  };

  const consumeFlashStock = useCallback(async (lines) => {
    const used = lines.filter(l => flashSaleItems.some(f => f.active && f.id === l.itemId && f.discountPrice === l.price));
    if (used.length === 0) return;
    try {
      await runTransaction(db, async (tx) => {
        const ref = doc(db, "settings", "promotions");
        const snap = await tx.get(ref);
        if (!snap.exists()) return;
        const flash = (snap.data().flashSale || []).map(f => {
          const u = used.find(l => l.itemId === f.id);
          if (!u) return f;
          const left = Math.max(0, (f.stock || 0) - u.qty);
          return { ...f, stock: left, active: left > 0 ? f.active : false };
        });
        tx.update(ref, { flashSale: flash });
      });
    } catch (e) { console.error("Flash stock update failed:", e); }
  }, [flashSaleItems]);

  const handlePlaceOrder = useCallback(async () => {
    if (isProcessingPayment) return;
    if (isScheduled && (!scheduleDate || !scheduleTime)) { showToast("⚠️ Schedule ki date aur time dono daalo", 'error'); return; }
    if (orderType === "parcel" && !parcelOpenNow()) { showToast(PARCEL_MSG, 'error'); return; }
    const _gone = cartItems.filter(([id]) => !menu.some((m) => m.id === id && m.available));
    if (_gone.length > 0) { showToast("⚠️ " + _gone.map(([id]) => (menu.find((m) => m.id === id) || {}).name || "Item").join(", ") + " ab available nahi hai — cart se hata do", 'error'); return; }
    if (cartItems.length === 0) return;
    if (!custName.trim()) { showToast("⚠️ Enter Name", 'error'); return; }
    if (!custPhone.trim() || custPhone.length < 10) { showToast("⚠️ Enter valid Phone", 'error'); return; }
    if (orderType === "parcel" && (!custAddress.trim() || !custExactAddress.trim() || !custPinCode || custPinCode.length !== 6)) { showToast("⚠️ Location, Exact Address aur 6-digit Pincode zaroori hai!", 'error'); return; }

    setIsProcessingPayment(true);
    try {
      if (!pendingOrderIdRef.current) pendingOrderIdRef.current = uid("o");
      const orderId = pendingOrderIdRef.current;
      payIdRef.current = null;
      let paymentInfo = { paid: false, status: "pending", paymentId: null };

      if (paymentMethod === "upi") {
        showToast("📱 UPI app khul raha hai — payment ke baad order confirm karein", 'info');
      }

      const itemStrings = cartItems.map(([id, entry]) => {
        const m = menu.find((x) => x.id === id);
        return `${getCartQty(entry)}x ${m.name}`;
      }).join(", ");

      const initialItems = cartItems.map(([id, entry]) => {
        const m = menu.find((x) => x.id === id);
        return {
          itemId: id, name: m.name, portion: m.portion || "",
          price: Math.round((getCartLineTotal(entry, m) / Math.max(1, getCartQty(entry))) * 100) / 100, originalPrice: m.price,
          qty: getCartQty(entry), kotNumber: 1
        };
      });

      const order = {
        id: orderId, table, orderType,
        customer: { name: custName, phone: custPhone, address: orderType === "parcel" ? custAddress : "", exactAddress: custExactAddress, pincode: custPinCode },
        items: initialItems,
        claimedReward: claimedReward ? claimedReward.item : null,
        rewardUsedCoins: claimedReward ? claimedReward.cost : 0,
        earnedCoins: newEarnedCoins,
        discount: appliedDiscount,
        couponDiscountAmount: discountAmount,
        loyaltyDiscount, loyaltyTier: loyaltyTier.name,
        deliveryFee, subtotal, finalTotal,
        notes, payment: paymentMethod,
        paymentStatus: paymentInfo.status, paymentId: paymentInfo.paymentId,
        status: "new", paid: false,
        createdAt: Date.now(),
        scheduledDate: isScheduled ? scheduleDate : null,
        scheduledTime: isScheduled ? scheduleTime : null,
        isScheduled, coinsClaimed: false,
        kots: [{ id: uid("kot"), kotNumber: 1, items: initialItems, createdAt: Date.now(), status: "new", isRunning: false }]
      };

      await placeOrder(order);

      pendingOrderIdRef.current = null;
      const orderHistory = safeJSON('eatpark_orders', []);
      orderHistory.push(order);
      safeSet('eatpark_orders', orderHistory.slice(-30));

      const customerData = safeJSON('eatpark_customer', {});
      customerData.lastOrderDate = Date.now();
      if (paymentInfo.paid) {
        customerData.totalOrders = (customerData.totalOrders || 0) + 1;
        customerData.totalSpent = (customerData.totalSpent || 0) + finalTotal;
      }
      safeSet('eatpark_customer', customerData);
      try {
        const _cPatch = { lastOrderDate: Date.now() };
        if (paymentInfo.paid) {
          _cPatch.totalOrders = customerData.totalOrders;
          _cPatch.totalSpent = customerData.totalSpent;
        }
        await updateDoc(doc(db, "customers", custPhone), _cPatch);
      } catch (e) { }

      if (paymentMethod === "upi") setTimeout(() => openUpiApp(finalTotal, orderId), 700);
      consumeFlashStock(initialItems);

      const claimedText = claimedReward ? `\n🎁 *Free Reward:* ${claimedReward.item}` : "";
      const scheduleText = isScheduled && scheduleDate && scheduleTime ? `\n📅 *Scheduled:* ${scheduleDate} at ${scheduleTime}` : "";
      const waText = `🚨 *NEW ORDER* (#${orderId.slice(1, 5).toUpperCase()})\n\n*Type:* ${orderType === 'parcel' ? '🛍️ Parcel' : `🍽️ Table ${table}`}\n*Customer:* ${custName} (${custPhone})\n` + (orderType === 'parcel' ? `*Address:* ${custAddress}\n\n` : `\n`) + `*Items:* ${itemStrings}${claimedText}\n` + (appliedDiscount > 0 ? `*Coupon:* ${appliedDiscount}%\n` : ``) + (loyaltyDiscount > 0 ? `*Loyalty:* ${loyaltyTier.name}\n` : ``) + `*Total:* ₹${finalTotal}\n*Payment:* ${paymentMethod} (${paymentInfo.paid ? "PAID" : "PENDING"})\n` + scheduleText + (notes ? `\n*Notes:* ${notes}` : ``);
      const link = document.createElement('a');
      link.href = `https://wa.me/${RESTAURANT.whatsapp}?text=${encodeURIComponent(waText)}`;
      /* WhatsApp band */

      playNotificationSound();
      sendPushNotification("🛎️ New Order", `Order #${orderId.slice(1, 5)} - ₹${finalTotal}`);
      setMyOrderIds(prev => [...prev, order.id]);
      setCart({});
      setNotes(""); setClaimedReward(null); setCartOpen(false); setActiveModal('track');
      setIsScheduled(false); setScheduleDate(""); setScheduleTime("");
      showToast("🎉 Order Placed!", 'success');
    } catch (e) {
      console.error("Order error:", e);
      if (payIdRef.current) alert("⚠️ Payment ho gaya hai par order save nahi hua.\nPayment ID: " + payIdRef.current + "\nYe ID staff ko dikhao.");
      else showToast("⚠️ " + authMsg(e), 'error');
    } finally { setIsProcessingPayment(false); }
  }, [isProcessingPayment, cartItems, custName, custPhone, custAddress, orderType, table, paymentMethod, finalTotal, subtotal, discountAmount, deliveryFee, claimedReward, newEarnedCoins, isScheduled, scheduleDate, scheduleTime, appliedDiscount, loyaltyDiscount, loyaltyTier, notes, menu, placeOrder, sendPushNotification, consumeFlashStock, showToast]);

  const handlePlaceOrderOld = useCallback(async () => {
    if (cartItems.length === 0) return;
    if (!custName.trim()) { showToast("⚠️ Enter Name", 'error'); return; }
    if (!custPhone.trim() || custPhone.length < 10) { showToast("⚠️ Enter valid Phone", 'error'); return; }
    if (orderType === "parcel" && !custAddress.trim()) { showToast("⚠️ Enter Address", 'error'); return; }

    setIsProcessingPayment(true);
    try {
      if (paymentMethod === "razorpay") {
        const success = await processRazorpayPayment(finalTotal, uid("o"), custName, custPhone);
        if (!success) { setIsProcessingPayment(false); return; }
      } else if (paymentMethod === "phonepe") {
        showToast("📱 Redirecting to PhonePe...", 'info');
        await new Promise(resolve => setTimeout(resolve, 1500));
      }

      const orderId = uid("o");
      const itemStrings = cartItems.map(([id, entry]) => {
  const m = menu.find((mi) => mi.id === id);
  return `${getCartQty(entry)}x ${m.name}`;
}).join(", ");
      const claimedText = claimedReward ? `\n🎁 *Free Reward:* ${claimedReward.item}` : "";
      const scheduleText = isScheduled && scheduleDate && scheduleTime ? `\n📅 *Scheduled:* ${scheduleDate} at ${scheduleTime}` : "";
      const waText = `🚨 *NEW ORDER* (#${orderId.slice(1, 5).toUpperCase()})\n\n*Type:* ${orderType === 'parcel' ? '🛍️ Parcel' : `🍽️ Table ${table}`}\n*Customer:* ${custName} (${custPhone})\n` + (orderType === 'parcel' ? `*Address:* ${custAddress}\n\n` : `\n`) + `*Items:* ${itemStrings}${claimedText}\n` + (appliedDiscount > 0 ? `*Coupon:* ${appliedDiscount}%\n` : ``) + (loyaltyDiscount > 0 ? `*Loyalty:* ${loyaltyTier.name}\n` : ``) + `*Total:* ₹${finalTotal}\n*Payment:* ${paymentMethod}\n` + scheduleText + (notes ? `*Notes:* ${notes}` : ``);

      const link = document.createElement('a');
      link.href = `https://wa.me/${RESTAURANT.whatsapp}?text=${encodeURIComponent(waText)}`;
      link.target = '_blank'; document.body.appendChild(link); link.click(); document.body.removeChild(link);

      const initialItems = cartItems.map(([id, entry]) => {
  const m = menu.find((mi) => mi.id === id);
  const qty = getCartQty(entry);
  const finalPrice = entry.priceOverride ?? m.price;
  return {
    itemId: id,
    name: m.name,
    portion: m.portion || "",
    price: finalPrice,
    originalPrice: m.price,
    qty,
    kotNumber: 1
  };
});

      const order = {
        id: orderId, table, orderType,
        customer: { name: custName, phone: custPhone, address: orderType === "parcel" ? custAddress : "" },
        items: initialItems,
        claimedReward: claimedReward ? claimedReward.item : null,
        rewardUsedCoins: claimedReward ? claimedReward.cost : 0,
        earnedCoins: newEarnedCoins,
        discount: appliedDiscount,
        loyaltyDiscount, loyaltyTier: loyaltyTier.name,
        deliveryFee, notes, payment: paymentMethod,
        paymentStatus: paymentMethod === "cash" ? "pending" : "paid",
        status: "new", paid: paymentMethod !== "cash",
        createdAt: Date.now(),
        scheduledDate: isScheduled ? scheduleDate : null,
        scheduledTime: isScheduled ? scheduleTime : null,
        isScheduled,
        coinsClaimed: false,
        kots: [{ id: uid("kot"), kotNumber: 1, items: initialItems, createdAt: Date.now(), status: "new", isRunning: false }]
      };

      const orderHistory = JSON.parse(localStorage.getItem('eatpark_orders') || '[]');
      orderHistory.push(order);
      localStorage.setItem('eatpark_orders', JSON.stringify(orderHistory));

      const customerData = JSON.parse(localStorage.getItem('eatpark_customer') || '{}');
      customerData.totalOrders = (customerData.totalOrders || 0) + 1;
      customerData.totalSpent = (customerData.totalSpent || 0) + finalTotal;
      customerData.lastOrderDate = Date.now();
      localStorage.setItem('eatpark_customer', JSON.stringify(customerData));

      await placeOrder(order, claimedReward ? claimedReward.cost : 0);
      try { await updateDoc(doc(db, "customers", custPhone), { totalOrders: customerData.totalOrders, totalSpent: customerData.totalSpent, lastOrderDate: Date.now() }); } catch (e) { }

      playNotificationSound();
      sendPushNotification("🛎️ New Order", `Order #${orderId.slice(1, 5)} - ₹${finalTotal}`);
      setMyOrderIds([...myOrderIds, order.id]);
      setCart({});
      localStorage.removeItem('eatpark_cart');
      setNotes(""); setClaimedReward(null); setCartOpen(false); setActiveModal('track');
      setIsScheduled(false); setScheduleDate(""); setScheduleTime("");
      showToast("🎉 Order Placed!", 'success');
    } catch (e) {
      console.error("Order error:", e);
      showToast("⚠️ Failed. Try again.", 'error');
    } finally { setIsProcessingPayment(false); }
  }, [cartItems, custName, custPhone, custAddress, orderType, table, paymentMethod, finalTotal, claimedReward, isScheduled, scheduleDate, scheduleTime, appliedDiscount, loyaltyDiscount, loyaltyTier, notes, menu, placeOrder, sendPushNotification, myOrderIds, showToast]);

 const handleBooking = async () => {
  if (!bookData.name || !bookData.phone || !bookData.date || !bookData.time || !bookData.guests) { 
    showToast("⚠️ Fill all fields", 'error'); 
    return; 
  }

  const newBooking = { 
    ...bookData, 
    type: bookType, 
    id: uid("b"), 
    status: "pending", 
    createdAt: Date.now() 
  };

  try { await bookEvent(newBooking); } catch (e) { console.error(e); showToast("⚠️ Booking send nahi hui. Internet check karo.", 'error'); return; }

  // 📲 WhatsApp notification to restaurant
  const bookingType = bookType === "party" ? "🎉 PARTY BOOKING" : "🍽️ TABLE BOOKING";
  const waText = 
    `*${bookingType} REQUEST*%0A%0A` +
    `*Name:* ${bookData.name}%0A` +
    `*Phone:* ${bookData.phone}%0A` +
    `*Date:* ${bookData.date}%0A` +
    `*Time:* ${bookData.time}%0A` +
    `*Guests:* ${bookData.guests}%0A` +
    `*Booking ID:* #${newBooking.id.slice(1, 6).toUpperCase()}%0A%0A` +
    `_Sent from Eat & Park App_`;

  window.open(
    `https://wa.me/${RESTAURANT.whatsapp}?text=${encodeURIComponent(waText.replace(/%0A/g, "\n"))}`,
    "_blank"
  );

  setConfirmedBooking(newBooking);
  setBookData({ name: "", phone: "", date: "", time: "", guests: "" });
  showToast("✅ Booking Sent! WhatsApp kholo aur Send dabao.", 'success');
};
  const addComboToCart = useCallback((combo) => {
    try {
      const lines = (combo.items || []).map(it => ({ ...it, quantity: Number(it.quantity) || 1, menuItem: menu.find(m => m.id === it.id) }));
      if (lines.length === 0 || lines.some(l => !l.menuItem || !l.menuItem.available)) { showToast("⚠️ Combo ka koi item available nahi", 'warning'); return; }
      const totalMenuPrice = lines.reduce((s, l) => s + l.menuItem.price * l.quantity, 0);
      const finalPrice = Number(combo.finalPrice);
      if (!(totalMenuPrice > 0) || !Number.isFinite(finalPrice)) { showToast("⚠️ Combo ka price set nahi hai", 'warning'); return; }
      const ratio = finalPrice / totalMenuPrice;
      setCart(prev => {
        const next = { ...prev };
        lines.forEach(l => {
          const prevEntry = next[l.id];
          const prevQty = getCartQty(prevEntry);
          const prevPrice = prevEntry?.priceOverride ?? l.menuItem.price;
          const newQty = prevQty + l.quantity;
          const _k = prevEntry?.priceOverride != null ? (prevEntry.ovQty ?? prevQty) : 0;
          const _o = prevEntry?.priceOverride != null ? prevEntry.priceOverride : 0;
          const _cp = l.menuItem.price * ratio;
          next[l.id] = { qty: newQty, priceOverride: Math.round((_k * _o + l.quantity * _cp) / (_k + l.quantity)), ovQty: _k + l.quantity };
        });
        return next;
      });
      showToast(`🎉 ${combo.name} added!`, 'success');
    } catch (e) {
      console.error("Combo error:", e);
      showToast("⚠️ Combo error: " + (e?.message || e), 'error');
    }
  }, [menu, showToast]);
  const addComboToCartPrev = useCallback((combo) => {
    const lines = combo.items.map(it => ({ ...it, menuItem: menu.find(m => m.id === it.id) }));
    if (lines.some(l => !l.menuItem || !l.menuItem.available)) { showToast("⚠️ Combo ka koi item available nahi", 'warning'); return; }
    const totalMenuPrice = lines.reduce((s, l) => s + l.menuItem.price * l.quantity, 0);
    if (totalMenuPrice <= 0) return;
    const ratio = combo.finalPrice / totalMenuPrice;
    setCart(prev => {
      const next = { ...prev };
      lines.forEach(l => {
        next[l.id] = { qty: getCartQty(next[l.id]) + l.quantity, priceOverride: Math.round(l.menuItem.price * ratio) };
      });
      return next;
    });
    showToast(`🎉 ${combo.name} added!`, 'success');
  }, [menu, showToast]);
  const addComboToCartOld = useCallback((combo) => {
  const totalMenuPrice = combo.items.reduce((s, it) => s + it.price * it.quantity, 0);
  const ratio = combo.finalPrice / totalMenuPrice;

  setCart(prev => {
    const next = { ...prev };
    combo.items.forEach(item => {
      const existing = next[item.id];
      const newQty = getCartQty(existing) + item.quantity;
      const newOverride = Math.round(item.price * ratio);
      next[item.id] = { qty: newQty, priceOverride: newOverride };
    });
    return next;
  });
  showToast(`🎉 ${combo.name} added!`, 'success');
}, [showToast]);

  const addFlashSaleToCart = useCallback((item) => {
    const menuItem = menu.find(m => m.id === item.id);
    if (!menuItem || !menuItem.available) { showToast("⚠️ Item available nahi", 'warning'); return; }
    if (item.stock != null && getCartQty(cartRef.current[item.id]) + 1 > item.stock) {
      showToast(`⚠️ Sirf ${item.stock} bache hain`, 'warning'); return;
    }
    setCart(prev => {
      const e = prev[item.id];
      const q = getCartQty(e);
      const k = e?.priceOverride != null ? (e.ovQty ?? q) : 0;
      const o = e?.priceOverride != null ? e.priceOverride : 0;
      return { ...prev, [item.id]: { qty: q + 1, priceOverride: Math.round((k * o + item.discountPrice) / (k + 1)), ovQty: k + 1 } };
    });
    showToast(`⚡ ${item.name} added!`, 'success');
  }, [menu, showToast]);
  const addFlashSaleToCartOld = useCallback((item) => {
  setCart(prev => {
    const existing = prev[item.id];
    const qty = getCartQty(existing) + 1;
    return {
      ...prev,
      [item.id]: { qty, priceOverride: item.discountPrice }
    };
  });
  showToast(`⚡ ${item.name} added!`, 'success');
}, [showToast]);

  const inputStyle = { padding: "12px 16px", border: `1.5px solid ${COLORS.line}`, borderRadius: 12, fontSize: 16, width: "100%", boxSizing: "border-box" };

  return (
    <div style={{ maxWidth: viewMode === "desktop" ? 1100 : 480, margin: "0 auto", paddingBottom: cartCount ? 120 : 60, background: "#0B111A", color: "#fff", minHeight: "100vh", position: "relative" }}>
      {toast && <Toast message={toast} type={toastType} />}

      
      {toast && <Toast message={toast} type={toastType} />}

      {/* ENP-DARK-LOGIN */}
      {!isLoggedIn && !waiterUnlocked && (
        <div style={{ position: "fixed", inset: 0, zIndex: 150, background: "#0B111A", overflowY: "auto", display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
          <div style={{ width: "100%", maxWidth: 400, background: "#161F2F", borderRadius: 24, padding: 32, border: "1px solid #273449", boxShadow: "0 24px 70px rgba(0,0,0,0.55)" }}>
            <div style={{ textAlign: "center", marginBottom: 28 }}>
              <div style={{ width: 70, height: 70, background: "#FF5A1F", borderRadius: 18, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 34, margin: "0 auto 14px", boxShadow: "0 12px 30px rgba(255,90,31,0.35)" }}>🍽️</div>
              <div style={{ fontSize: 24, fontWeight: 800, color: "#fff" }}>Eat & Park Restaurant</div>
              <div style={{ fontSize: 13, color: "#8B9BB4", marginTop: 4 }}>Customer Login</div>
            </div>
            <div id="otp-recaptcha"></div>
            {otpStep === "phone" ? (
              <div>
                <div style={{ marginBottom: 16 }}>
                  <label style={{ display: "block", fontSize: 11, fontWeight: 800, color: "#8B9BB4", textTransform: "uppercase", marginBottom: 8, letterSpacing: 0.5 }}>Your Name</label>
                  <input type="text" placeholder="Apna naam likho" value={custName} onChange={(e) => setCustName(e.target.value)} style={{ width: "100%", boxSizing: "border-box", padding: "14px 16px", background: "#0B111A", border: "1px solid #273449", borderRadius: 12, color: "#fff", fontSize: 15, outline: "none" }} />
                </div>
                <div style={{ marginBottom: 22 }}>
                  <label style={{ display: "block", fontSize: 11, fontWeight: 800, color: "#8B9BB4", textTransform: "uppercase", marginBottom: 8, letterSpacing: 0.5 }}>Phone Number</label>
                  <input type="tel" inputMode="numeric" maxLength={10} placeholder="10-digit number" value={custPhone} onChange={(e) => setCustPhone(e.target.value.replace(/\D/g, "").slice(0, 10))} style={{ width: "100%", boxSizing: "border-box", padding: "14px 16px", background: "#0B111A", border: "1px solid #273449", borderRadius: 12, color: "#fff", outline: "none", fontSize: 20, letterSpacing: 2, fontWeight: 700, textAlign: "center" }} />
                </div>
                <button disabled={otpSending || resendIn > 0} onClick={() => { if (!custName.trim()) { showToast("⚠️ Pehle naam daalo", "error"); return; } handleSendOtp(); }}
                  style={{ width: "100%", padding: 16, background: "#FF5A1F", border: "none", borderRadius: 14, color: "#fff", fontSize: 16, fontWeight: 800, cursor: "pointer", boxShadow: "0 8px 20px rgba(255,90,31,0.3)", opacity: (otpSending || resendIn > 0) ? 0.6 : 1 }}>
                  {otpSending ? "⏳ Bhej raha hai..." : resendIn > 0 ? "Dobara bhejo (" + resendIn + "s)" : "Send OTP"}
                </button>
              </div>
            ) : (
              <div>
                <label style={{ display: "block", fontSize: 11, fontWeight: 800, color: "#8B9BB4", textTransform: "uppercase", marginBottom: 8, letterSpacing: 0.5, textAlign: "center" }}>OTP {custPhone} par bheja gaya</label>
                <input type="text" inputMode="numeric" maxLength={6} placeholder="••••••" value={otpCode} onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ""))} style={{ width: "100%", boxSizing: "border-box", padding: "14px 16px", background: "#0B111A", border: "1px solid #273449", borderRadius: 12, color: "#fff", outline: "none", fontSize: 28, letterSpacing: 10, fontWeight: 800, textAlign: "center", marginBottom: 20 }} />
                <button onClick={handleVerifyOtp} style={{ width: "100%", padding: 16, background: "#10B981", border: "none", borderRadius: 14, color: "#fff", fontSize: 16, fontWeight: 800, cursor: "pointer", marginBottom: 10, boxShadow: "0 8px 20px rgba(16,185,129,0.3)" }}>Verify & Start</button>
                <button disabled={otpSending || resendIn > 0} onClick={handleSendOtp} style={{ width: "100%", padding: 10, background: "none", border: "none", color: "#FF8C5A", fontWeight: 800, cursor: "pointer", opacity: resendIn > 0 ? 0.5 : 1 }}>{resendIn > 0 ? "Resend OTP (" + resendIn + "s)" : "🔁 Resend OTP"}</button>
                <button onClick={() => { setOtpStep("phone"); setOtpCode(""); }} style={{ width: "100%", padding: 10, background: "none", border: "none", color: "#8B9BB4", fontWeight: 700, cursor: "pointer" }}>← Change Number</button>
              </div>
            )}
            <div style={{ display: "flex", gap: 8, marginTop: 26 }}>
              <button onClick={() => requestPinPrompt("staff")} style={{ flex: 1, padding: "10px 0", background: "transparent", border: "1px solid #273449", borderRadius: 12, color: "#8B9BB4", fontWeight: 700, fontSize: 12, cursor: "pointer" }}>Staff</button>
              <button onClick={() => setShowWaiterPinModal(true)} style={{ flex: 1, padding: "10px 0", background: "transparent", border: "1px solid #273449", borderRadius: 12, color: "#8B9BB4", fontWeight: 700, fontSize: 12, cursor: "pointer" }}>Waiter</button>
              <button onClick={() => requestPinPrompt("admin")} style={{ flex: 1, padding: "10px 0", background: "transparent", border: "1px solid #273449", borderRadius: 12, color: "#8B9BB4", fontWeight: 700, fontSize: 12, cursor: "pointer" }}>Admin</button>
            </div>
          </div>
        </div>
      )}

      {/* 🎂 DOB POPUP */}
      {showDobModal && isLoggedIn && (
        <div style={{ position: "fixed", inset: 0, zIndex: 160, background: "rgba(0,0,0,0.75)", backdropFilter: "blur(4px)", display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
          <div style={{ width: "100%", maxWidth: 380, background: "#161F2F", borderRadius: 24, padding: 28, border: "1px solid #273449", boxShadow: "0 24px 70px rgba(0,0,0,0.55)", textAlign: "center" }}>
            <div style={{ fontSize: 54, marginBottom: 8 }}>🎂</div>
            <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 22, fontWeight: 800, color: "#fff", lineHeight: 1.3 }}>Give your date of birth and get offer on birthday</div>
            <div style={{ fontSize: 13, color: "#8B9BB4", marginTop: 8, marginBottom: 18 }}>Apna birthday batao, us din aapko special offer milega 🎁</div>
            <input type="date" value={dobInput} min="1940-01-01" max={new Date().toISOString().split("T")[0]} onChange={(e) => { setDobInput(e.target.value); setDobErr(""); }}
              style={{ width: "100%", boxSizing: "border-box", padding: "14px 16px", background: "#0B111A", border: "1px solid #273449", borderRadius: 12, color: "#fff", fontSize: 18, fontWeight: 700, textAlign: "center", outline: "none", colorScheme: "dark" }} />
            {dobErr && <div style={{ color: "#EF4444", fontSize: 12, fontWeight: 700, marginTop: 8 }}>{dobErr}</div>}
            <button onClick={saveDob} disabled={dobSaving} style={{ width: "100%", padding: 15, marginTop: 16, background: "#FF5A1F", border: "none", borderRadius: 14, color: "#fff", fontSize: 16, fontWeight: 800, cursor: dobSaving ? "wait" : "pointer", opacity: dobSaving ? 0.6 : 1, boxShadow: "0 8px 20px rgba(255,90,31,0.3)" }}>
              {dobSaving ? "⏳ Saving..." : "🎁 Save & Get Offer"}
            </button>
            <button onClick={skipDob} style={{ width: "100%", padding: 10, marginTop: 6, background: "none", border: "none", color: "#8B9BB4", fontWeight: 700, cursor: "pointer" }}>Baad me</button>
          </div>
        </div>
      )}

      {/* ENP-CUSTOMER-UI */}
      <style>{"body{background:#0B111A} .slide-up { color: #111827 !important; } .slide-up div, .slide-up span { color: inherit; }.enp-hs::-webkit-scrollbar{display:none}.enp-hs{scrollbar-width:none}"}</style>

      <div style={{ position: "sticky", top: 0, zIndex: 60, background: "rgba(11,17,26,0.94)", backdropFilter: "blur(10px)", borderBottom: "1px solid #273449", padding: "10px 14px", display: "flex", alignItems: "center", gap: 8 }}>
        <button onClick={() => setShowSidebar(true)} aria-label="Menu" style={{ width: 40, height: 40, borderRadius: 12, border: "1px solid #273449", background: "#161F2F", color: "#fff", fontSize: 18, cursor: "pointer", flexShrink: 0 }}>☰</button>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: "'Outfit', sans-serif", fontWeight: 800, fontSize: 17, color: "#fff", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>Eat & Park</div>
          <div style={{ fontSize: 11, color: "#8B9BB4", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{RESTAURANT.tagline}</div>
        </div>
        <select value={table} onChange={(e) => setTable(Number(e.target.value))} style={{ background: "#161F2F", color: "#fff", border: "1px solid #273449", borderRadius: 10, padding: "9px 8px", fontWeight: 800, fontSize: 13, outline: "none" }}>
          {Array.from({ length: 20 }, (_, i) => i + 1).map((n) => (<option key={n} value={n} style={{ color: "#000" }}>Table {n}</option>))}
        </select>
        <button onClick={() => { requestWaiter(table); showToast("🔔 Waiter notified!", 'success'); }} title="Waiter Call" style={{ width: 40, height: 40, borderRadius: 12, border: "none", background: "#EF4444", color: "#fff", fontSize: 17, cursor: "pointer", flexShrink: 0 }}>🔔</button>
        <button onClick={() => { if (waiterUnlocked) setShowWaiterMode(true); else setShowWaiterPinModal(true); }} title="Waiter Mode" style={{ width: 40, height: 40, borderRadius: 12, border: "1px solid #273449", background: waiterUnlocked ? "#3B82F6" : "#161F2F", color: "#fff", fontSize: 17, cursor: "pointer", flexShrink: 0 }}>{waiterUnlocked ? "🧑‍🍳" : "🔒"}</button>
      </div>

      <div style={{ margin: "14px 14px 0", position: "relative", height: 150, borderRadius: 20, overflow: "hidden", border: "1px solid #273449" }}>
        <div className="keep-color" style={{ position: "absolute", inset: 0, backgroundImage: "url('" + (settings?.heroImage || "https://images.unsplash.com/photo-1514933651103-005eec06c04b?auto=format&fit=crop&w=800&q=80") + "')", backgroundSize: "cover", backgroundPosition: "center" }} />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(11,17,26,0.96) 0%, rgba(11,17,26,0.4) 65%, rgba(11,17,26,0.15) 100%)" }} />
        <div style={{ position: "absolute", left: 16, right: 16, bottom: 14 }}>
          <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 24, fontWeight: 800, color: "#fff", marginBottom: 8 }}>{RESTAURANT.name}</div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <a href={"tel:" + RESTAURANT.phones[0]} style={{ background: "rgba(255,255,255,0.14)", color: "#fff", padding: "5px 12px", borderRadius: 20, fontSize: 12, fontWeight: 700, textDecoration: "none" }}>📞 Call</a>
            <a href={GOOGLE_REVIEW_URL} target="_blank" rel="noopener noreferrer" style={{ background: "rgba(255,255,255,0.14)", color: "#fff", padding: "5px 12px", borderRadius: 20, fontSize: 12, fontWeight: 700, textDecoration: "none" }}>⭐ Rate us</a>
          </div>
        </div>
      </div>

      {myActiveOrders.length > 0 && (
        <div style={{ padding: "12px 14px 0", display: "flex", gap: 8 }}>
          <button onClick={() => setActiveModal('track')} style={{ flex: 1, background: "#0A2A20", border: "1.5px solid #10B981", color: "#10B981", borderRadius: 14, padding: 12, fontWeight: 800, display: "flex", justifyContent: "space-between", alignItems: "center", cursor: "pointer", fontSize: 14 }}>
            <span>📦 {myActiveOrders.length} Active Order{myActiveOrders.length > 1 ? 's' : ''}</span><span>Track ➔</span>
          </button>
          <button onClick={() => setRunningOrderId(myActiveOrders[0].id)} style={{ background: "#3B82F6", color: "#fff", border: "none", borderRadius: 14, padding: "0 16px", fontWeight: 800, cursor: "pointer", fontSize: 18 }}>➕</button>
        </div>
      )}

      {!searchQuery.trim() && comboOffers && comboOffers.filter((c) => c.active).length > 0 && (
        <div style={{ paddingTop: 18 }}>
          <div style={{ padding: "0 14px 10px", fontFamily: "'Outfit', sans-serif", fontSize: 17, fontWeight: 800, color: "#fff" }}>🎯 Combo Offers</div>
          <div className="enp-hs" style={{ display: "flex", gap: 12, overflowX: "auto", padding: "0 14px 4px" }}>
            {comboOffers.filter((c) => c.active).map((combo) => (
              <div key={combo.id} style={{ minWidth: 260, maxWidth: 260, flexShrink: 0, background: "linear-gradient(135deg, #1E293B 0%, #161F2F 100%)", border: "1px solid rgba(255,90,31,0.4)", borderRadius: 16, padding: 14, display: "flex", flexDirection: "column", gap: 8 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <span style={{ fontSize: 30 }}>{combo.image}</span>
                  <div style={{ flex: 1, minWidth: 0, fontWeight: 800, fontSize: 15, color: "#fff" }}>{combo.name}</div>
                  <span style={{ background: "#FF5A1F", color: "#fff", padding: "3px 9px", borderRadius: 20, fontSize: 11, fontWeight: 800 }}>{combo.discount}% OFF</span>
                </div>
                <div style={{ fontSize: 12, color: "#8B9BB4", lineHeight: 1.5 }}>{(combo.items || []).map((i) => i.quantity + "× " + i.name).join(" · ")}</div>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: "auto" }}>
                  <div><span style={{ fontSize: 18, fontWeight: 800, color: "#FF8C5A" }}>₹{combo.finalPrice}</span> <span style={{ fontSize: 12, color: "#8B9BB4", textDecoration: "line-through" }}>₹{combo.totalPrice}</span></div>
                  <button onClick={() => addComboToCart(combo)} style={{ background: "#FF5A1F", color: "#fff", border: "none", borderRadius: 10, padding: "8px 16px", fontWeight: 800, fontSize: 13, cursor: "pointer" }}>Add</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {!searchQuery.trim() && flashSaleItems && flashSaleItems.filter((f) => f.active && (f.stock == null || f.stock > 0)).length > 0 && (
        <div style={{ paddingTop: 18 }}>
          <div style={{ padding: "0 14px 10px", fontFamily: "'Outfit', sans-serif", fontSize: 17, fontWeight: 800, color: "#EF4444" }}>⚡ Flash Sale</div>
          <div className="enp-hs" style={{ display: "flex", gap: 12, overflowX: "auto", padding: "0 14px 4px" }}>
            {flashSaleItems.filter((f) => f.active && (f.stock == null || f.stock > 0)).map((item) => (
              <div key={item.id} style={{ minWidth: 170, flexShrink: 0, background: "#161F2F", border: "1px solid rgba(239,68,68,0.5)", borderRadius: 16, padding: 12 }}>
                <div style={{ fontWeight: 800, fontSize: 14, color: "#fff", marginBottom: 6 }}>🔥 {item.name}</div>
                <div style={{ marginBottom: 6 }}><span style={{ fontSize: 18, fontWeight: 800, color: "#EF4444" }}>₹{item.discountPrice}</span> <span style={{ fontSize: 12, color: "#8B9BB4", textDecoration: "line-through" }}>₹{item.price}</span></div>
                {item.stock != null && item.stock <= 5 && <div style={{ fontSize: 11, color: "#F59E0B", fontWeight: 700, marginBottom: 6 }}>Sirf {item.stock} bache!</div>}
                <button onClick={() => addFlashSaleToCart(item)} style={{ width: "100%", background: "#EF4444", color: "#fff", border: "none", borderRadius: 10, padding: 8, fontWeight: 800, cursor: "pointer" }}>Add</button>
              </div>
            ))}
          </div>
        </div>
      )}

      <div style={{ padding: "18px 14px 12px", display: "flex", gap: 8 }}>
        <div style={{ position: "relative", flex: 1 }}>
          <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Dish search karo..." className="keep-color" style={{ width: "100%", boxSizing: "border-box", padding: "13px 40px 13px 42px", background: "#161F2F", border: "1px solid #273449", borderRadius: 14, color: "#fff", fontSize: 15, outline: "none" }} />
          <span style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", fontSize: 16 }}>🔍</span>
          {searchQuery && <button onClick={() => setSearchQuery("")} style={{ position: "absolute", right: 8, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", color: "#8B9BB4", fontSize: 16, cursor: "pointer", padding: 6 }}>✕</button>}
        </div>
        <button onClick={() => setVegOnly(!vegOnly)} style={{ padding: "0 14px", borderRadius: 14, border: "1px solid " + (vegOnly ? "#10B981" : "#273449"), background: vegOnly ? "#0A2A20" : "#161F2F", color: vegOnly ? "#10B981" : "#8B9BB4", fontWeight: 800, fontSize: 13, display: "flex", alignItems: "center", gap: 6, cursor: "pointer", whiteSpace: "nowrap" }}>
          <VegDot veg={true} />{vegOnly ? "Veg" : "All"}
        </button>
      </div>

      {!searchQuery.trim() && !catPickerOpen && (
        <div style={{ position: "sticky", top: 60, zIndex: 50, display: "flex", alignItems: "center", gap: 8, padding: "10px 14px", background: "#0B111A", borderBottom: "1px solid #273449" }}>
          <button onClick={() => setCatPickerOpen(true)} style={{ flexShrink: 0, padding: "8px 14px", borderRadius: 999, border: "1px solid #273449", background: "#161F2F", color: "#FF8C5A", fontWeight: 800, fontSize: 13, cursor: "pointer" }}>← Categories</button>
          <div className="enp-hs" style={{ display: "flex", gap: 8, overflowX: "auto", flex: 1 }}>
            {visibleCategories.map((c) => {
              const on = category === c;
              return (
                <button key={c} onClick={() => setCategory(c)} style={{ whiteSpace: "nowrap", flexShrink: 0, padding: "8px 16px", borderRadius: 999, border: "1px solid " + (on ? "#FF5A1F" : "#273449"), background: on ? "#FF5A1F" : "#161F2F", color: on ? "#fff" : "#8B9BB4", fontWeight: 700, fontSize: 13, cursor: "pointer", boxShadow: on ? "0 6px 16px rgba(255,90,31,0.3)" : "none" }}>{c}</button>
              );
            })}
          </div>
        </div>
      )}

      {!searchQuery.trim() && catPickerOpen && (
        <div style={{ padding: "18px 14px 0" }}>
          <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 22, fontWeight: 800, color: "#fff", marginBottom: 4 }}>Kya khana hai? 🍽️</div>
          <div style={{ fontSize: 13, color: "#8B9BB4", marginBottom: 16 }}>Category chuno, phir items dekho</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 12 }}>
            {visibleCategories.map((c) => {
              const catItems = menu.filter(m => m.category === c || (m.alsoIn || []).includes(c));
              const img = (catItems.find(x => x.image) || {}).image;
              return (
                <button key={c} onClick={() => { setCategory(c); setCatPickerOpen(false); }} style={{ position: "relative", height: 130, borderRadius: 16, border: "1px solid #273449", overflow: "hidden", cursor: "pointer", padding: 0, background: "#161F2F" }}>
                  {img && <img src={img} alt={c} loading="lazy" className="keep-color" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", filter: "brightness(0.55)" }} onError={(e) => { e.target.style.display = "none"; }} />}
                  <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(11,17,26,0.95) 10%, rgba(11,17,26,0.2) 100%)" }} />
                  <div style={{ position: "absolute", left: 12, right: 12, bottom: 10, textAlign: "left" }}>
                    <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 15, fontWeight: 800, color: "#fff", lineHeight: 1.2 }}>{c}</div>
                    <div style={{ fontSize: 11, color: "#FF8C5A", fontWeight: 700, marginTop: 2 }}>{catItems.length} items →</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      <div style={{ padding: "14px 14px 0", display: (catPickerOpen && !searchQuery.trim()) ? "none" : "block" }}>
        {!searchQuery.trim() && filteredItems.length > 0 && (
          <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 12 }}>
            <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 21, fontWeight: 800, color: "#fff" }}>{category}</div>
            <div style={{ fontSize: 12, color: "#8B9BB4", fontWeight: 700 }}>{filteredItems.length} items</div>
          </div>
        )}
        {filteredItems.length === 0 && (
          <div style={{ textAlign: "center", padding: "50px 20px", color: "#8B9BB4" }}>
            <div style={{ fontSize: 44, marginBottom: 12, opacity: 0.6 }}>{EMPTY_STATES[emptyReason].icon}</div>
            <div style={{ fontWeight: 800, fontSize: 17, color: "#fff", marginBottom: 6 }}>{EMPTY_STATES[emptyReason].title}</div>
            <div style={{ fontSize: 13, lineHeight: 1.5 }}>{EMPTY_STATES[emptyReason].subtitle}</div>
          </div>
        )}
        <div style={{ display: "grid", gridTemplateColumns: viewMode === "desktop" ? "repeat(auto-fill, minmax(340px, 1fr))" : "1fr", gap: 12 }}>
          {filteredItems.map((item) => {
            const qty = getCartQty(cart[item.id]);
            const fav = favorites.includes(item.id);
            return (
              <div key={item.id} style={{ display: "flex", gap: 12, padding: 14, background: "#161F2F", border: "1px solid " + (qty > 0 ? "#FF5A1F" : "#273449"), borderRadius: 16, opacity: item.available ? 1 : 0.5, alignItems: "flex-start" }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6, flexWrap: "wrap" }}>
                    <VegDot veg={item.veg} />
                    {item.isBestseller && <span style={{ fontSize: 10, color: "#FF8C5A", fontWeight: 800, letterSpacing: "0.04em", textTransform: "uppercase" }}>★ Bestseller</span>}
                    {searchQuery.trim() && <span style={{ fontSize: 10, color: "#8B9BB4", fontWeight: 700 }}>{item.category}</span>}
                  </div>
                  <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 16, fontWeight: 700, color: "#fff", lineHeight: 1.3, marginBottom: 3 }}>{item.name}</div>
                  {item.portion && <div style={{ fontSize: 11, color: "#8B9BB4", fontWeight: 600, marginBottom: 4 }}>{item.portion}</div>}
                  <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 16, fontWeight: 800, color: "#FF8C5A", marginBottom: 6 }}>{inr(item.price)}</div>
                  {item.desc && <div style={{ fontSize: 12, color: "#8B9BB4", lineHeight: 1.5, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>{item.desc}</div>}
                </div>
                <div style={{ width: 104, flexShrink: 0, display: "flex", flexDirection: "column", alignItems: "center" }}>
                  <div style={{ position: "relative", width: 104, height: 104 }}>
                    <div style={{ position: "absolute", inset: 0, borderRadius: 14, background: "#1E293B", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 34 }}>🍽️</div>
                    {item.image ? <img src={item.image} alt={item.name} loading="lazy" className="keep-color" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", borderRadius: 14, filter: item.available ? "none" : "grayscale(1)" }} onError={(e) => { e.target.style.display = "none"; }} /> : null}
                    <button onClick={() => toggleFavorite(item.id)} aria-label="Favorite" style={{ position: "absolute", top: 5, right: 5, width: 28, height: 28, borderRadius: "50%", border: "none", background: "rgba(11,17,26,0.7)", color: fav ? "#FFB800" : "#fff", fontSize: 15, cursor: "pointer" }}>{fav ? "★" : "☆"}</button>
                  </div>
                  <div style={{ marginTop: -17, position: "relative", zIndex: 1 }}>
                    {!item.available ? (
                      <div style={{ background: "#451A1A", color: "#EF4444", borderRadius: 10, fontWeight: 800, fontSize: 11, padding: "9px 12px", whiteSpace: "nowrap" }}>Out of stock</div>
                    ) : qty === 0 ? (
                      <button onClick={() => handleSetQty(item.id, 1)} style={{ width: 88, height: 36, background: "#0B111A", border: "1.5px solid #FF5A1F", borderRadius: 10, color: "#FF5A1F", fontWeight: 800, fontSize: 14, cursor: "pointer", boxShadow: "0 6px 14px rgba(0,0,0,0.35)" }}>ADD</button>
                    ) : (
                      <div style={{ width: 88, height: 36, background: "#FF5A1F", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "space-between", boxShadow: "0 6px 14px rgba(255,90,31,0.35)" }}>
                        <button onClick={() => handleSetQty(item.id, qty - 1)} style={{ width: 30, height: 36, border: "none", background: "transparent", color: "#fff", fontSize: 20, fontWeight: 800, cursor: "pointer" }}>−</button>
                        <span style={{ color: "#fff", fontWeight: 800, fontSize: 15 }}>{qty}</span>
                        <button onClick={() => handleSetQty(item.id, qty + 1)} style={{ width: 30, height: 36, border: "none", background: "transparent", color: "#fff", fontSize: 20, fontWeight: 800, cursor: "pointer" }}>+</button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div style={{ textAlign: "center", padding: "30px 20px 70px", fontSize: 12, color: "#8B9BB4", lineHeight: 1.7 }}>
        📍 {RESTAURANT.address}<br />📞 {RESTAURANT.phones.join(" · ")}
        <div style={{ display: "flex", justifyContent: "center", gap: 10, marginTop: 14 }}>
          <button onClick={() => requestPinPrompt("staff")} style={{ background: "none", border: "1px solid #273449", color: "#8B9BB4", borderRadius: 10, padding: "8px 14px", fontSize: 12, cursor: "pointer", fontWeight: 700 }}>🔒 Staff Login</button>
          <button onClick={() => requestPinPrompt("admin")} style={{ background: "none", border: "1px solid #273449", color: "#8B9BB4", borderRadius: 10, padding: "8px 14px", fontSize: 12, cursor: "pointer", fontWeight: 700 }}>⚙️ Admin Login</button>
        </div>
      </div>

      {aiSuggestion && !cartOpen && !activeModal && (
        <div className="smooth-slide-up" style={{ position: 'fixed', bottom: cartCount > 0 ? 100 : 20, left: 16, right: 16, background: 'linear-gradient(135deg, #f6d365 0%, #fda085 100%)', padding: 14, borderRadius: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center', zIndex: 4 }}>
          <div>
            <div style={{ fontSize: 12, fontWeight: 800, color: '#d35400' }}>🤖 AI Suggests:</div>
            <div style={{ fontSize: 16, fontWeight: 800 }}>{aiSuggestion.name}</div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <button onClick={() => { handleSetQty(aiSuggestion.id, 1); setAiSuggestion(null); }} style={{ background: COLORS.ink, color: '#fff', border: 'none', padding: '8px 16px', borderRadius: 10, fontWeight: 800, cursor: 'pointer' }}>+ Add</button>
            <button onClick={() => setAiSuggestion(null)} style={{ background: 'transparent', border: 'none', fontSize: 20, cursor: 'pointer' }}>&times;</button>
          </div>
        </div>
      )}

      {cartCount > 0 && !cartOpen && !activeModal && (
        <button onClick={() => setCartOpen(true)} style={{ position: "fixed", bottom: 20, left: "50%", transform: "translateX(-50%)", width: "calc(100% - 28px)", maxWidth: 440, background: "linear-gradient(135deg, #FF5A1F 0%, #E04814 100%)", color: "#fff", border: "none", borderRadius: 16, padding: "15px 20px", display: "flex", justifyContent: "space-between", alignItems: "center", fontWeight: 800, fontSize: 16, cursor: "pointer", zIndex: 55, boxShadow: "0 12px 30px rgba(255,90,31,0.45)" }}>
          <span>🛒 {cartCount} item{cartCount > 1 ? "s" : ""}</span><span>{inr(finalTotal)} ➔</span>
        </button>
      )}

      {showSidebar && (
        <div style={{ position: "fixed", inset: 0, zIndex: 80, display: "flex" }}>
          <div style={{ width: "80%", maxWidth: 300, background: "#fff", height: "100%", padding: "24px", display: "flex", flexDirection: "column", overflowY: "auto" }} className="slide-right">
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 30 }}>
              <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 24, fontWeight: 800, color: COLORS.copper }}>Eat & Park</div>
              <button onClick={() => setShowSidebar(false)} style={{ background: "none", border: "none", fontSize: 22, cursor: "pointer" }}>✕</button>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 12, flex: 1 }}>
              <SidebarBtn icon={isDark ? "☀️" : "🌙"} text={isDark ? "Light Mode" : "Dark Mode"} onClick={() => { setIsDark(!isDark); setShowSidebar(false); }} highlight />
              <SidebarBtn icon={viewMode === "desktop" ? "📱" : "🖥️"} text={viewMode === "desktop" ? "App Mode" : "Desktop Mode"} onClick={() => { setViewMode(viewMode === "desktop" ? "app" : "desktop"); setShowSidebar(false); }} highlight />
              <SidebarBtn icon="🖼️" text="Photo Gallery" onClick={() => { setShowSidebar(false); setActiveModal('gallery'); }} />
              <SidebarBtn icon="📜" text="Order History" onClick={() => { setShowSidebar(false); setActiveModal('orderHistory'); }} />
              <SidebarBtn icon="🪙" text="Coin History" onClick={() => { setShowSidebar(false); setActiveModal('coinHistory'); }} />
              <SidebarBtn icon="🎁" text="Today's Offers" onClick={() => { setShowSidebar(false); setActiveModal('offers'); }} />
              <SidebarBtn icon="🍽️" text="Table Booking" onClick={() => { setShowSidebar(false); setBookType("table"); setActiveModal('booking'); }} />
              <SidebarBtn icon="🎉" text="Party Booking" onClick={() => { setShowSidebar(false); setBookType("party"); setActiveModal('booking'); }} />
              <SidebarBtn icon="👑" text="VIP Loyalty" onClick={() => { setShowSidebar(false); setActiveModal('loyalty'); }} />
              <SidebarBtn icon="⭐" text="Rate on Google" onClick={() => { setShowSidebar(false); window.open(GOOGLE_REVIEW_URL, '_blank'); }} highlight />
              {isLoggedIn && (
                <div style={{ marginTop: 8, padding: 12, background: COLORS.paper, borderRadius: 12, textAlign: "center", fontSize: 12, color: COLORS.textLight, fontWeight: 600 }}>
                  👤 {custName || "Guest"} · {custPhone}
                </div>
              )}
              <SidebarBtn icon="🚪" text="Logout" onClick={handleLogout} />
              {isLoggedIn && (
                <div style={{ marginTop: 8, padding: 12, background: COLORS.paper, borderRadius: 12, textAlign: "center", fontSize: 12, color: COLORS.textLight, fontWeight: 600 }}>
                  👤 {custName || "Guest"} · {custPhone}
                </div>
              )}
              <SidebarBtn icon="🚪" text="Logout" onClick={handleLogout} />
              <div style={{ marginTop: 16, padding: 12, background: COLORS.paper, borderRadius: 12, textAlign: 'center' }}>
                <QRCodeSVG value={window.location.href} size={100} />
                <p style={{ fontSize: 11, color: COLORS.textLight, marginTop: 6 }}>📲 Scan to order</p>
              </div>
              <SidebarBtn icon="💬" text="Chat with Restaurant" onClick={() => { setShowSidebar(false); setActiveOrderIdForChat(myActiveOrders[0]?.id || ('general_' + (custPhone || 'guest')));
 setActiveModal('chat'); }} />
            </div>
          </div>
          <div style={{ flex: 1, background: "rgba(0,0,0,0.6)" }} onClick={() => setShowSidebar(false)} />
        </div>
      )}

      {(cartOpen || activeModal) && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", display: "flex", alignItems: "flex-end", zIndex: 70 }} onClick={() => { setCartOpen(false); setActiveModal(null); setConfirmedBooking(null); }}>
          <div onClick={(e) => e.stopPropagation()} style={{ background: "#fff", width: "100%", maxWidth: 480, margin: "0 auto", borderRadius: "24px 24px 0 0", padding: "24px 20px 30px", maxHeight: "85vh", overflowY: "auto" }} className="slide-up">

            {cartOpen && (
              <>
                <ModalHeader title="Checkout" onClose={() => setCartOpen(false)} />
                {cartItems.map(([id, entry]) => {
  const item = menu.find((m) => m.id === id);
  const qty = getCartQty(entry);
  const hasOverride = entry.priceOverride != null && entry.priceOverride !== item.price;
  return (
    <div key={id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12, padding: "12px", background: COLORS.paper, borderRadius: 12 }}>
      <div>
        <div style={{ fontSize: 15, fontWeight: 700 }}>{item.name}</div>
        {hasOverride && (
          <div style={{ fontSize: 11, color: COLORS.error, fontWeight: 700, marginTop: 2 }}>
            ⚡ Deal: ₹{entry.priceOverride} <span style={{ textDecoration: 'line-through', color: COLORS.textLight }}>₹{item.price}</span>
          </div>
        )}
      </div>
      <Stepper qty={qty} onChange={(nq) => handleSetQty(id, nq)} />
    </div>
  );
})}

                <div style={{ display: "flex", gap: 12, marginTop: 20, marginBottom: 16 }}>
                  <button onClick={() => setOrderType("dine_in")} style={{ flex: 1, padding: "12px", border: `2px solid ${orderType === "dine_in" ? COLORS.copper : COLORS.line}`, background: orderType === "dine_in" ? COLORS.copper : "#fff", color: orderType === "dine_in" ? "#fff" : COLORS.ink, borderRadius: 12, fontWeight: 800, cursor: "pointer" }}>🍽️ Dine-in</button>
                  <button onClick={() => { if (!parcelOpenNow()) { showToast(PARCEL_MSG, 'warning'); return; } setOrderType("parcel"); }} style={{ flex: 1, padding: "12px", border: `2px solid ${orderType === "parcel" ? COLORS.copper : COLORS.line}`, background: orderType === "parcel" ? COLORS.copper : "#fff", color: orderType === "parcel" ? "#fff" : COLORS.ink, borderRadius: 12, fontWeight: 800, cursor: "pointer" }}>🛍️ Parcel</button>
                </div>

                <div style={{ marginBottom: 16 }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }}>
                    <input type="checkbox" checked={isScheduled} onChange={(e) => setIsScheduled(e.target.checked)} />
                    <span style={{ fontWeight: 700, fontSize: 14 }}>📅 Schedule Order</span>
                  </label>
                  {isScheduled && (<div style={{ display: 'flex', gap: 12, marginTop: 10 }}>
                    <input type="date" value={scheduleDate} onChange={(e) => setScheduleDate(e.target.value)} style={{ ...inputStyle, flex: 1 }} />
                    <input type="time" value={scheduleTime} onChange={(e) => setScheduleTime(e.target.value)} style={{ ...inputStyle, flex: 1 }} />
                  </div>)}
                </div>

                <div style={{ background: COLORS.paper2, padding: 16, borderRadius: 16, marginBottom: 16 }}>
                  <div style={{ fontWeight: 800, fontSize: 14, marginBottom: 10 }}>🔐 Quick OTP</div>
                  <div id="otp-recaptcha"></div>
                  {!isLoggedIn ? (
                    <div>
                      {otpStep === "phone" ? (
                        <div style={{ display: "flex", gap: 8 }}>
                          <input type="tel" placeholder="10-digit Phone" value={custPhone} onChange={(e) => { setCustPhone(e.target.value); checkExistingCustomer(e.target.value); }} style={{ ...inputStyle, flex: 1 }} />
                          <button onClick={handleSendOtp} disabled={otpSending || resendIn > 0} style={{ background: COLORS.ink, color: "#fff", border: "none", borderRadius: 12, padding: "0 16px", fontWeight: 800, cursor: "pointer", opacity: (otpSending || resendIn > 0) ? 0.6 : 1 }}>{otpSending ? "⏳" : resendIn > 0 ? resendIn + "s" : "Send"}</button>
                        </div>
                      ) : (
                        <div style={{ display: "flex", gap: 8 }}>
                          <input type="text" placeholder="Enter OTP" value={otpCode} onChange={(e) => setOtpCode(e.target.value)} style={{ ...inputStyle, flex: 1 }} />
                          <button onClick={handleVerifyOtp} style={{ background: COLORS.success, color: "#fff", border: "none", borderRadius: 12, padding: "0 16px", fontWeight: 800, cursor: "pointer" }}>Verify</button>
                        </div>
                      )}
                    </div>
                  ) : (<div style={{ color: COLORS.success, fontWeight: 800, fontSize: 14 }}>✓ Verified ({custPhone})</div>)}
                </div>

                <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 16, borderBottom: `1px solid ${COLORS.line}`, paddingBottom: 20 }}>
                  <input type="text" placeholder="Your Name *" value={custName} onChange={(e) => setCustName(e.target.value)} style={inputStyle} />
                  <input type="tel" placeholder="Phone *" value={custPhone} onChange={(e) => setCustPhone(e.target.value)} style={inputStyle} />
                  {orderType === "parcel" && (
                    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                      {/* Auto GPS Box */}
                      <div style={{ display: "flex", gap: 8 }}>
                        <input 
                          type="text" 
                          placeholder="📍 Click button to fetch GPS Location" 
                          value={custAddress} 
                          readOnly
                          style={{ ...inputStyle, flex: 1, background: COLORS.paper2 }} 
                        />
                        <button 
                          onClick={handleGetLocation} 
                          style={{ background: COLORS.sage, color: "#fff", border: "none", borderRadius: 12, padding: "0 16px", fontWeight: 800, cursor: "pointer", whiteSpace: "nowrap" }}
                        >
                          📍 Get Location
                        </button>
                      </div>
                      
                      {/* Exact Address Box */}
                      <textarea 
                        placeholder="Exact Address (House No, Building, Landmark, Area) *" 
                        value={custExactAddress} 
                        onChange={(e) => setCustExactAddress(e.target.value)} 
                        style={{ ...inputStyle, resize: "none" }} 
                        rows={2} 
                      />
                      
                      {/* Pincode Box */}
                      <input 
                        type="text" 
                        placeholder="Pincode (6 digits) *" 
                        maxLength={6}
                        value={custPinCode || ""} 
                        onChange={(e) => setCustPinCode && setCustPinCode(e.target.value.replace(/\D/g, ""))} 
                        style={{ ...inputStyle }} 
                      />
                    </div>
                  )}
                </div>

                <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
                  <input type="text" placeholder="Coupon (EAT20)" value={couponCode} onChange={(e) => setCouponCode(e.target.value)} style={inputStyle} />
                  <button onClick={handleApplyCoupon} style={{ background: COLORS.gold, color: COLORS.ink, border: "none", borderRadius: 12, padding: "0 16px", fontWeight: 800, cursor: "pointer" }}>Apply</button>
                </div>

                {custPhone.length >= 10 && (
                  <div style={{ background: 'linear-gradient(135deg, #fdfbfb, #ebedee)', borderRadius: 16, padding: 16, marginBottom: 20, border: `1.5px solid ${COLORS.gold}` }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
                      <div style={{ fontWeight: 800, fontSize: 16 }}>🪙 EatCoins</div>
                      <div><div style={{ fontSize: 14, fontWeight: 800, color: COLORS.sageDark }}>Bal: {currentCoins}</div><div style={{ fontSize: 11, color: COLORS.gold, fontWeight: 700 }}>{loyaltyTier.name}</div></div>
                    </div>
                    <LoyaltyProgress currentPoints={currentCoins} nextTier={LOYALTY_TIERS.find((t) => t.points > currentCoins) || null} loyaltyRules={loyaltyRules} />
                    {loyaltyRules.rewards.map(r => {
                      const canAfford = currentCoins >= r.cost;
                      const isClaimed = claimedReward?.id === r.id;
                      return (
                        <div key={r.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#fff', padding: 12, borderRadius: 10, marginTop: 8, border: `1px solid ${isClaimed ? COLORS.success : COLORS.line}` }}>
                          <div><div style={{ fontWeight: 700, fontSize: 14 }}>{r.item}</div><div style={{ fontSize: 12, color: COLORS.gold, fontWeight: 800 }}>{r.cost} Coins</div></div>
                          <button onClick={() => { setClaimedReward(isClaimed ? null : r); if (!isClaimed) showToast(`🎁 ${r.item} claimed!`, 'reward'); }} disabled={!canAfford && !isClaimed}
                            style={{ padding: '6px 16px', borderRadius: 8, border: 'none', background: isClaimed ? COLORS.success : (canAfford ? COLORS.ink : COLORS.paper2), color: isClaimed || canAfford ? '#fff' : COLORS.textLight, fontWeight: 800, cursor: canAfford ? 'pointer' : 'not-allowed', fontSize: 13 }}>
                            {isClaimed ? "✓ Claimed" : (canAfford ? "Claim 🎁" : `${r.cost - currentCoins} more`)}
                          </button>
                        </div>
                      );
                    })}
                    <div style={{ fontSize: 12, color: COLORS.copper, fontWeight: 700, textAlign: 'center', marginTop: 8 }}>🎁 You'll earn +{newEarnedCoins} coins!</div>
                  </div>
                )}

                <textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Special instructions?" style={{ ...inputStyle, marginBottom: 20, resize: "none" }} rows={2} />

                <div style={{ marginBottom: 20 }}>
                  <div style={{ fontSize: 13, fontWeight: 800, color: COLORS.textLight, textTransform: 'uppercase', marginBottom: 10 }}>Payment</div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8 }}>
                    <button onClick={() => setPaymentMethod('cash')} style={{ padding: '10px', borderRadius: 10, border: `2px solid ${paymentMethod === 'cash' ? COLORS.copper : COLORS.line}`, background: paymentMethod === 'cash' ? COLORS.copperLight : 'transparent', fontWeight: 700, cursor: 'pointer' }}>💵 Cash</button>
                    <button onClick={() => setPaymentMethod('upi')} style={{ padding: '10px', borderRadius: 10, border: '2px solid ' + (paymentMethod === 'upi' ? COLORS.copper : COLORS.line), background: paymentMethod === 'upi' ? COLORS.copperLight : 'transparent', fontWeight: 700, cursor: 'pointer' }}>📱 UPI (PhonePe / GPay)</button>
                  </div>
                </div>

                <div style={{ marginBottom: 20 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 14, color: COLORS.textLight }}><span>Subtotal</span><span>{inr(subtotal)}</span></div>
                  {appliedDiscount > 0 && (<div style={{ display: "flex", justifyContent: "space-between", fontSize: 14, color: COLORS.success }}><span>Coupon ({appliedDiscount}%)</span><span>-{inr(discountAmount)}</span></div>)}
                  {loyaltyDiscount > 0 && (<div style={{ display: "flex", justifyContent: "space-between", fontSize: 14, color: COLORS.gold }}><span>Loyalty</span><span>-{inr(loyaltyDiscount)}</span></div>)}
                  {vipDiscount > 0 && (<div style={{ display: "flex", justifyContent: "space-between", fontSize: 14, color: COLORS.gold }}><span>👑 VIP Elite (20%)</span><span>-{inr(vipDiscount)}</span></div>)}
                  {orderType === "parcel" && (<div style={{ display: "flex", justifyContent: "space-between", fontSize: 14, color: COLORS.copper }}><span>Delivery</span><span>+{inr(deliveryFee)}</span></div>)}
                  <div style={{ display: "flex", justifyContent: "space-between", fontWeight: 800, fontSize: 18, borderTop: `1px solid ${COLORS.line}`, paddingTop: 8, marginTop: 4 }}>
                    <span>Total</span><span style={{ color: COLORS.copper, fontFamily: "'JetBrains Mono', monospace" }}>{inr(finalTotal)}</span>
                  </div>
                </div>

                <button onClick={handlePlaceOrder} disabled={isProcessingPayment} style={{ background: COLORS.ink, color: "#fff", border: "none", borderRadius: 14, padding: "16px", fontWeight: 800, fontSize: 16, cursor: isProcessingPayment ? 'not-allowed' : 'pointer', width: "100%", opacity: isProcessingPayment ? 0.6 : 1 }}>
                  {isProcessingPayment ? '⏳ Processing...' : '🎉 Place Order'}
                </button>
              </>
            )}

            {activeModal === 'gallery' && (<><ModalHeader title="🖼️ Photo Gallery" onClose={() => setActiveModal(null)} /><div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 12 }}>{gallery.map((imgUrl, idx) => (<img key={idx} src={imgUrl} alt="" style={{ width: "100%", height: 140, objectFit: "cover", borderRadius: 12 }} onError={(e) => { e.target.onerror = null; e.target.src = "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=400&q=80"; }} />))}</div></>)}

            {activeModal === 'orderHistory' && (
              <><ModalHeader title="📜 Order History" onClose={() => setActiveModal(null)} />
                {myOrders.length === 0 ? (<div style={{ textAlign: 'center', padding: "40px 0", color: COLORS.textLight }}>No orders yet</div>) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                    {[...myOrders].reverse().map(o => {
                      const orderTotal = getOrderTotal(o);
                      const isCancelled = o.status === "cancelled";
                      const isCompleted = o.status === "served";
                      return (
                        <div key={o.id} style={{ background: COLORS.paper, border: `1px solid ${COLORS.line}`, padding: 16, borderRadius: 14 }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6, fontWeight: 800 }}>
                            <span>#{o.id.slice(1, 5).toUpperCase()}</span>
                            <span style={{ fontSize: 11, color: isCancelled ? COLORS.error : isCompleted ? COLORS.sage : COLORS.copper }}>{isCancelled ? "❌ Cancelled" : isCompleted ? "✅ Done" : o.status}</span>
                          </div>
                          <div style={{ fontSize: 12, color: COLORS.textLight, marginBottom: 8 }}>{new Date(o.createdAt).toLocaleString('en-IN')}</div>
                          <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 8 }}>{o.items.map(i => `${i.qty}× ${i.name}`).join(", ")}</div>
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderTop: `1px solid ${COLORS.line}`, paddingTop: 10, flexWrap: 'wrap', gap: 8 }}>
                            <div style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 800, color: COLORS.copper }}>💰 {inr(orderTotal)}</div>
                            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                              {!isCancelled && (<button onClick={() => reorderOrder(o)} style={{ padding: '4px 12px', borderRadius: 8, border: `1px solid ${COLORS.sage}`, background: 'transparent', color: COLORS.sage, fontWeight: 700, fontSize: 11, cursor: 'pointer' }}>🔄 Reorder</button>)}
                              <GoogleReviewButton variant="primary" size="sm" />
                              {o.status === "new" && (
                                <button onClick={() => cancelOrder(o.id)} style={{ padding: '4px 12px', borderRadius: 8, border: `1px solid ${COLORS.error}`, background: 'transparent', color: COLORS.error, fontWeight: 700, fontSize: 11, cursor: 'pointer' }}>❌ Cancel</button>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </>
            )}

            {activeModal === 'coinHistory' && (<><ModalHeader title="🪙 Coin History" onClose={() => setActiveModal(null)} />{myCoinLogs.length === 0 ? <div style={{ textAlign: 'center', padding: 40, color: COLORS.textLight }}>No transactions</div> : <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>{[...myCoinLogs].reverse().map((log, idx) => (<div key={idx} style={{ background: COLORS.paper, padding: 14, borderRadius: 12, display: 'flex', justifyContent: 'space-between' }}><div><div style={{ fontWeight: 700, fontSize: 14 }}>{log.reason}</div><div style={{ fontSize: 11, color: COLORS.textLight }}>{new Date(log.timestamp).toLocaleString('en-IN')}</div></div><div style={{ fontWeight: 800, color: log.coins > 0 ? COLORS.success : COLORS.error }}>{log.coins > 0 ? `+${log.coins}` : log.coins} 🪙</div></div>))}</div>}</>)}

            {activeModal === 'offers' && (<><ModalHeader title="🎁 Offers" onClose={() => setActiveModal(null)} />{offersList.length === 0 ? <div style={{ textAlign: 'center', padding: 40, color: COLORS.textLight }}>No offers</div> : <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>{offersList.map(offer => (<div key={offer.id} onClick={() => { setSearchQuery(offer.title); setActiveModal(null); }} style={{ background: 'linear-gradient(135deg, #FF9A9E 0%, #FECFEF 100%)', padding: 20, borderRadius: 16, cursor: 'pointer' }}><div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 22, fontWeight: 800, marginBottom: 8 }}>{offer.title}</div><div style={{ fontSize: 14, fontWeight: 600, lineHeight: 1.5 }}>{offer.desc}</div></div>))}</div>}</>)}

            {activeModal === 'loyalty' && (<><ModalHeader title="VIP Loyalty 👑" onClose={() => setActiveModal(null)} /><div style={{ background: "linear-gradient(135deg, #1A1A1A 0%, #3C3C3C 100%)", borderRadius: 20, padding: 28, color: "#fff", textAlign: "center" }}><div style={{ fontSize: 48, marginBottom: 12 }}>💎</div><div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 26, fontWeight: 800, marginBottom: 10, color: COLORS.gold }}>Eat & Park Elite</div><div style={{ fontSize: 15, marginBottom: 24 }}>Become premium for <strong style={{ fontSize: 20, color: COLORS.gold }}>₹999/month</strong>. Get 20% off!</div><div style={{ background: "#fff", padding: 20, borderRadius: 16 }}><div style={{ color: COLORS.ink, fontWeight: 800, marginBottom: 10 }}>Scan to Join</div><img src={loyaltyQrSrc} alt="" style={{ width: 160, height: 160 }} /></div></div></>)}

            {activeModal === 'booking' && (<><ModalHeader title={bookType === "party" ? "Party Booking 🎉" : "Table Booking 🍽️"} onClose={() => { setActiveModal(null); setConfirmedBooking(null); }} />{confirmedBooking ? (<div style={{ textAlign: "center", padding: "30px 0" }}><div style={{ fontSize: 56, marginBottom: 16 }}>✅</div><h3 style={{ fontSize: 28, fontWeight: 800, marginBottom: 10 }}>Request Sent!</h3><button onClick={() => { setActiveModal(null); setConfirmedBooking(null); }} style={{ background: COLORS.paper2, border: 'none', padding: '12px', borderRadius: 12, width: '100%', fontWeight: 800, cursor: 'pointer' }}>Close</button></div>) : (<div style={{ display: "flex", flexDirection: "column", gap: 14 }}><input type="text" placeholder="Name" value={bookData.name} onChange={(e) => setBookData({ ...bookData, name: e.target.value })} style={inputStyle} /><input type="tel" placeholder="Phone" value={bookData.phone} onChange={(e) => setBookData({ ...bookData, phone: e.target.value })} style={inputStyle} /><div style={{ display: "flex", gap: 14 }}><input type="date" value={bookData.date} onChange={(e) => setBookData({ ...bookData, date: e.target.value })} style={inputStyle} /><input type="time" value={bookData.time} onChange={(e) => setBookData({ ...bookData, time: e.target.value })} style={inputStyle} /></div><input type="number" placeholder="Guests" value={bookData.guests} onChange={(e) => setBookData({ ...bookData, guests: e.target.value })} style={inputStyle} /><button onClick={handleBooking} style={{ background: COLORS.copper, color: '#fff', border: 'none', borderRadius: 14, padding: '13px 20px', fontWeight: 800, cursor: 'pointer' }}>Send Request</button></div>)}</>)}

            {activeModal === 'track' && (
  <>
    <ModalHeader title="Track Active Orders" onClose={() => setActiveModal(null)} />
    {myActiveOrders.length === 0 ? (
      <div style={{ textAlign: 'center', padding: "50px 20px", color: COLORS.textLight }}>
        <div style={{ fontSize: 40, marginBottom: 10 }}>😴</div>
        <div style={{ fontWeight: 700, fontSize: 16, color: COLORS.ink, marginBottom: 6 }}>Koi active order nahi hai</div>
        <div style={{ fontSize: 13 }}>Aapke purane orders "Order History" me dikhenge.</div>
      </div>
    ) : (
      myActiveOrders.map(o => {
        const steps = [
          { id: 'new', label: 'Order Received', icon: '📝', desc: 'Restaurant ne order accept kar liya hai' },
          { id: 'preparing', label: 'Cooking', icon: '👨‍🍳', desc: 'Aapka khana ban raha hai' },
          { id: 'ready', label: 'Ready', icon: '✅', desc: 'Khana taiyar hai, pickup ka wait hai' },
          { id: 'out_for_delivery', label: 'Out for Delivery', icon: '🛵', desc: 'Rider aapke order ke saath nikal chuka hai' },
          { id: 'served', label: 'Delivered', icon: '🎉', desc: 'Order deliver ho gaya!' }
        ];
        
        const currentIndex = steps.findIndex(s => s.id === o.status);
        const activeIndex = currentIndex === -1 ? 0 : currentIndex;

        return (
          <div key={o.id} style={{ background: '#fff', border: `1px solid ${COLORS.line}`, borderRadius: 16, padding: 20, marginBottom: 20 }}>
            
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 }}>
              <div>
                <div style={{ fontSize: 18, fontWeight: 800, color: COLORS.ink }}>Order #{o.id.slice(1, 5).toUpperCase()}</div>
                <div style={{ fontSize: 12, color: COLORS.textLight, marginTop: 2 }}>{new Date(o.createdAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</div>
              </div>
              <div style={{ background: COLORS.paper, padding: "6px 12px", borderRadius: 10, fontSize: 12, fontWeight: 700, color: COLORS.copper }}>
                {inr(getOrderTotal(o))}
              </div>
            </div>

            {/* TIMELINE */}
            <div style={{ margin: "20px 0", paddingLeft: 10 }}>
              {steps.map((step, idx) => {
                const isDone = idx < activeIndex;
                const isCurrent = idx === activeIndex;
                const isPending = idx > activeIndex;
                
                let dotColor = "#E8E6DC";
                let dotIcon = step.icon;
                let textColor = "#8A8375";

                if (isDone) {
                  dotColor = COLORS.sage;
                  textColor = COLORS.ink;
                } else if (isCurrent) {
                  dotColor = COLORS.copper;
                  textColor = COLORS.copper;
                }

                return (
                  <div key={step.id} style={{ display: "flex", gap: 15, position: "relative", paddingBottom: 25 }}>
                    {/* Connecting Line */}
                    {idx !== steps.length - 1 && (
                      <div style={{ position: "absolute", left: 14, top: 30, bottom: 0, width: 2, background: isDone ? COLORS.sage : "#E8E6DC", zIndex: 0 }} />
                    )}
                    
                    {/* Dot */}
                    <div style={{ 
                      width: 30, height: 30, borderRadius: 15, 
                      background: isDone ? COLORS.sageLight : isCurrent ? COLORS.copperLight : "#fff",
                      border: `2px solid ${dotColor}`,
                      display: "flex", alignItems: "center", justifyContent: "center",
                      zIndex: 1, fontSize: 14,
                      animation: isCurrent ? "pulse 2s infinite" : "none"
                    }}>
                      {isDone ? "✓" : step.icon}
                    </div>

                    {/* Text */}
                    <div style={{ paddingTop: 2 }}>
                      <div style={{ fontSize: 14, fontWeight: 800, color: textColor, lineHeight: 1.2 }}>{step.label}</div>
                      {isCurrent && <div style={{ fontSize: 12, color: COLORS.textLight, marginTop: 4, lineHeight: 1.3 }}>{step.desc}</div>}
                    </div>
                  </div>
                );
              })}
            </div>

            <div style={{ borderTop: `1px dashed ${COLORS.line}`, paddingTop: 15, display: 'flex', gap: 10 }}>
              <button onClick={() => setActiveModal(null)} style={{ flex: 1, background: "transparent", color: COLORS.copper, border: `2px solid ${COLORS.copper}`, borderRadius: 12, padding: "10px", fontWeight: 800, cursor: 'pointer', fontSize: 13 }}>Close</button>
              {o.status === "new" && (
                <button onClick={() => cancelOrder(o.id)} style={{ flex: 1, background: 'transparent', color: COLORS.error, border: `2px solid ${COLORS.error}`, borderRadius: 12, padding: "10px", fontWeight: 800, cursor: 'pointer', fontSize: 13 }}>Cancel Order</button>
              )}
            </div>
          </div>
        );
      })
    )}
  </>
)}

{activeModal === 'chat' && (<><ModalHeader title="💬 Chat" onClose={() => setActiveModal(null)} /><ChatBox orderId={activeOrderIdForChat || 'general'} customerId={custPhone || 'customer'} /></>)}
          </div>
        </div>
      )}

            {showWaiterMode && (
  <WaiterMode
    orders={orders}
    menu={menu}
    categories={categories}
    setMenuState={setMenuState}
    placeOrder={placeOrder}
    advanceStatus={advanceStatus}
    onClose={() => setShowWaiterMode(false)}
  />
)}
      {showWaiterPinModal && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)", backdropFilter: "blur(4px)", zIndex: 200, display: "flex", alignItems: "center", justifyContent: "center" }} onClick={() => setShowWaiterPinModal(false)}>
          <div onClick={(e) => e.stopPropagation()} style={{ background: "#fff", padding: "28px", borderRadius: 20, width: "90%", maxWidth: 340, textAlign: "center" }} className="slide-up">
            <div style={{ fontSize: 40, marginBottom: 12 }}>🧑‍🍳</div>
            <h3 style={{ margin: "0 0 8px", fontFamily: "'Outfit', sans-serif", fontSize: 22, fontWeight: 800 }}>Waiter Access</h3>
            <div style={{ fontSize: 13, color: COLORS.textLight, marginBottom: 12 }}>Waiter email + password se login karo</div>
            <input type="email" placeholder="Email" value={waiterEmail} onChange={(e) => setWaiterEmail(e.target.value)} style={{ padding: "12px", border: `1.5px solid ${COLORS.line}`, borderRadius: 12, fontSize: 16, width: "100%", boxSizing: "border-box", marginBottom: 12 }} />
            <input type="password" placeholder="••••" autoFocus value={waiterPinInput}
              onChange={(e) => setWaiterPinInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') handleWaiterPinSubmit(); }}
              style={{ padding: "14px", border: `1.5px solid ${COLORS.line}`, borderRadius: 12, fontSize: 28, width: "100%", boxSizing: "border-box", textAlign: "center", letterSpacing: 10, marginBottom: 20, fontWeight: 800 }} />
            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={() => { setShowWaiterPinModal(false); setWaiterPinInput(""); }}
                style={{ flex: 1, padding: "13px", borderRadius: 12, border: `2px solid ${COLORS.line}`, background: "transparent", fontWeight: 700, cursor: "pointer" }}>Cancel</button>
              <button onClick={handleWaiterPinSubmit}
                style={{ flex: 1, padding: "13px", borderRadius: 12, background: COLORS.info, color: "#fff", border: "none", fontWeight: 800, cursor: "pointer" }}>Unlock</button>
            </div>
            <div style={{ fontSize: 11, color: COLORS.textLight, marginTop: 12 }}></div>
          </div>
        </div>
      )}
            {runningOrderId && orders.find(o => o.id === runningOrderId) && (
        <RunningOrderModal order={orders.find(o => o.id === runningOrderId)} menu={menu} onConfirm={(items) => addRunningItems(runningOrderId, items)} onClose={() => setRunningOrderId(null)} />
      )}
{showAiModal && (
        <AIOrderModal
          menu={menu}
          onClose={() => setShowAiModal(false)}
          onOrderParsed={(data) => {
            if (data.items && data.items.length > 0) {
              setCart((prev) => {
                const next = { ...prev };
                data.items.forEach((line) => {
                  // ID se match karein, agar naam aya ho toh naam se ID dhoondein
                  let targetId = line.id;
                  const found = menu.find((m) => m.id === line.id || m.name.toLowerCase() === String(line.name || line.id).toLowerCase());
                  if (found) targetId = found.id;
                  if (!menu.some((m) => m.id === targetId)) return;

                  const curQty = getCartQty(next[targetId]);
                  next[targetId] = { qty: curQty + (Number(line.qty) || 1) };
                });
                return next;
              });
              setCartOpen(true); // Direct bill/cart khol dega taaki gayab na lage
              showToast("✨ Items cart me add ho gaye!", "success");
            } else {
              showToast("⚠️ Koi item match nahi hua", "warning");
            }
            if (data.orderType === "parcel") setOrderType("parcel");
            else if (data.table) {
              setOrderType("dine_in");
              setTable(Number(data.table));
            }
            if (data.notes) setNotes((prev) => (prev ? prev + ", " + data.notes : data.notes));
          }}
        />
      )}
    </div>
  );
}

// ==
// 17. STAFF VIEW (V15 — TOUCH TO PROCEED)
// ==

const STAFF_SHORTCUTS = {
  'Ctrl+K': 'Focus first order',
  '↑ / ↓': 'Navigate',
  'Ctrl+Enter': 'Advance selected',
  'Shift+?': 'Toggle help'
};


const KeyboardHelpModal = memo(({ onClose }) => (
  <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 999 }} onClick={onClose}>
    <div onClick={e => e.stopPropagation()} style={{ background: '#fff', padding: 28, borderRadius: 20, width: '90%', maxWidth: 440 }}>
      <h2 style={{ margin: '0 0 20px' }}>⌨️ Shortcuts</h2>
      <div style={{ display: 'grid', gap: 10 }}>
        {Object.entries(STAFF_SHORTCUTS).map(([key, desc]) => (
          <div key={key} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 12px', background: COLORS.paper, borderRadius: 10 }}>
            <kbd style={{ background: COLORS.copper, color: '#fff', padding: '4px 10px', borderRadius: 6, fontWeight: 800, fontSize: 12 }}>{key}</kbd>
            <span style={{ fontWeight: 600, fontSize: 14 }}>{desc}</span>
          </div>
        ))}
      </div>
      <button onClick={onClose} style={{ background: COLORS.copper, color: '#fff', border: 'none', borderRadius: 14, padding: '13px 20px', fontWeight: 800, width: '100%', marginTop: 20, cursor: 'pointer' }}>Close</button>
    </div>
  </div>
));

// ═══════════════════════════════════════════════
// 🧾 BILL + ORDER — ONE SCREEN POS
// ═══════════════════════════════════════════════
function BillPOSScreen(p) {
  return <ErrorBoundary compact onReset={p.onClose}><BillPOSScreenInner {...p} /></ErrorBoundary>;
}
function BillPOSScreenInner(p) {
  const { order, orders, menu, viewMode, items, setItems, calc } = p;
  const [tab, setTab] = useState(order && order.isDraft ? "menu" : "bill");
  const [presets] = usePresets();
  const waiterNames = presets.waiters || [];
  const gstList = [0, ...((presets.gstRates && presets.gstRates.length ? presets.gstRates : [5, 12, 18]).filter((r) => Number(r) > 0))];
  const [search, setSearch] = useState("");
  const [cat, setCat] = useState("all");
   const [wide, setWide] = useState(() => window.innerWidth >= 900);
  useEffect(() => {
    const f = () => setWide(window.innerWidth >= 900);
    window.addEventListener("resize", f);
    return () => window.removeEventListener("resize", f);
  }, []);
  const isDesktop = viewMode === "desktop" && wide;

  const isDraft = !!(order && order.isDraft);
  const cats = p.categories && p.categories.length ? p.categories : Array.from(new Set((menu || []).map((m) => m.category)));

  const list = useMemo(() => {
    const q = search.trim().toLowerCase();
    return (menu || []).filter((m) => m.available && (cat === "all" || m.category === cat || (m.alsoIn || []).includes(cat)) && (!q || String(m.name).toLowerCase().includes(q)));
  }, [menu, cat, search]);

  const qtyOf = (id) => items.filter((it) => it.itemId === id).reduce((s, it) => s + (it.qty || 0), 0);
  const itemCount = items.reduce((s, it) => s + (it.qty || 0), 0);

  const addItem = (m) => setItems((prev) => {
    const i = prev.findIndex((it) => it.itemId === m.id && it.price === m.price && it._new);
    if (i >= 0) return prev.map((it, k) => (k === i ? { ...it, qty: it.qty + 1 } : it));
    return [...prev, { _new: true, itemId: m.id, name: m.name, portion: m.portion || "", price: m.price, qty: 1, _rowId: Date.now() + "_" + Math.random().toString(36).slice(2, 6) }];
  });
  const changeQty = (rowId, d) => setItems((prev) => prev.flatMap((it) => (it._rowId !== rowId ? [it] : (it.qty + d <= 0 ? [] : [{ ...it, qty: Math.round((it.qty + d) * 100) / 100 }]))));
  const [showNew, setShowNew] = useState(false);
    const [savingItem, setSavingItem] = useState(false);

  // 🤖 AI ORDER
  const [aiOpen, setAiOpen] = useState(false);
  const [aiText, setAiText] = useState("");
  const [aiBusy, setAiBusy] = useState(false);
  const [aiRes, setAiRes] = useState(null);
  const [aiErr, setAiErr] = useState("");
  const [listening, setListening] = useState(false);
  const recRef = useRef(null);

  const closeAi = () => { try { recRef.current && recRef.current.stop(); } catch (e) {} setAiOpen(false); };

  const startMic = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { setAiErr("Is browser me mic nahi hai. Keyboard ka 🎤 use karo."); return; }
    if (listening && recRef.current) { recRef.current.stop(); return; }
    const r = new SR();
    r.lang = "hi-IN"; r.interimResults = false; r.continuous = false;
    r.onresult = (e) => {
      const t = Array.from(e.results).map((x) => x[0].transcript).join(" ");
      setAiText((prev) => (prev ? prev + " " : "") + t);
    };
    r.onerror = () => setListening(false);
    r.onend = () => setListening(false);
    recRef.current = r; setListening(true); setAiErr("");
    try { r.start(); } catch (e) { setListening(false); }
  };

    const runAi = async () => {
    const text = aiText.trim();
    if (!text || aiBusy) return;
    setAiBusy(true);
    setAiErr("");
    setAiRes(null);
    try {
      // 1. Safe Token extraction (Never pass empty Bearer header)
      let token = null;
      if (auth.currentUser) {
        try {
          token = await auth.currentUser.getIdToken();
        } catch (tokErr) {
          console.warn("Token fetch failed:", tokErr);
        }
      }

      const headers = {
        "Content-Type": "application/json",
      };
      if (token) {
        headers["Authorization"] = `Bearer ${token}`;
      }

      // 2. Fetch call
      const r = await HX.fetchWithTimeout("/api/parse-order", {
        method: "POST",
        headers,
        body: JSON.stringify({
          text,
          menu: (menu || [])
            .filter((m) => m.available)
            .map((m) => ({ id: m.id, name: m.name, portion: m.portion || "" })),
        }),
      });

      // 3. Handle non-JSON or error responses gracefully
      const contentType = r.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) {
        throw new Error(`Server error (${r.status}). Backend API route /api/parse-order check karein.`);
      }

      const data = await r.json();
      if (!r.ok) throw new Error(data.error || "AI processing failed");
      setAiRes(HX.sanitizeAiLines(data, menu));
    } catch (e) {
      console.error("AI Order Error:", e);
      setAiErr("⚠️ " + (e.message || "Failed to process order"));
    } finally {
      setAiBusy(false);
    }
  };


  const applyAi = () => {
    if (!aiRes) return;
    setItems((prev) => {
      const next = [...prev];
      (aiRes.items || []).forEach((line) => {
        const m = (menu || []).find((x) => x.id === line.id);
        if (!m) return;
        const i = next.findIndex((it) => it.itemId === m.id && it.price === m.price && it._new);
        if (i >= 0) next[i] = { ...next[i], qty: next[i].qty + line.qty };
        else next.push({ _new: true, itemId: m.id, name: m.name, portion: m.portion || "", price: m.price, qty: line.qty, _rowId: Date.now() + "_" + Math.random().toString(36).slice(2, 6) });
      });
      return next;
    });
    if (isDraft) {
      const t = Number(aiRes.table);
      if (aiRes.orderType === "parcel") p.setOrderType("parcel");
      else if (t >= 1 && t <= 12) { p.setOrderType("dine_in"); p.setTable(t); }
    }
    if (aiRes.notes) p.setNotes(p.notes ? p.notes + ", " + aiRes.notes : aiRes.notes);
    closeAi(); setAiText(""); setAiRes(null); setTab("bill");
  };

  const emptyNew = { name: "", price: "", category: cats[0] || "Thali", veg: true, portion: "" };
  const [newItem, setNewItem] = useState(emptyNew);

  const checkNewItem = () => {
    const name = newItem.name.trim();
    const price = Number(newItem.price);
    if (!name) { alert("⚠️ Item ka naam daalo"); return null; }
    if (!Number.isFinite(price) || price <= 0) { alert("⚠️ Sahi rate daalo"); return null; }
    return { name, price };
  };

  // Sirf is bill me (menu me save nahi hota)
  const addCustomOnly = () => {
    const v = checkNewItem();
    if (!v) return;
    setItems((prev) => [...prev, { _new: true, itemId: uid("c"), name: v.name, portion: newItem.portion.trim(), price: v.price, qty: 1, _rowId: Date.now() + "_" + Math.random().toString(36).slice(2, 6) }]);
    setNewItem(emptyNew);
    setShowNew(false);
  };

  // Menu me hamesha ke liye save + bill me add
  const saveNewItem = async () => {
    const v = checkNewItem();
    if (!v || savingItem) return;
    setSavingItem(true);
    try {
      const dish = mi(uid("m"), v.name, v.price, newItem.category || cats[0] || "Thali", newItem.veg, "", newItem.portion.trim(), false, true, "");
      const updatedMenu = [dish, ...(menu || [])];
      await setDoc(doc(db, "settings", "menu"), { items: updatedMenu });
      if (p.setMenuState) p.setMenuState(updatedMenu);
      addItem(dish);
      setNewItem(emptyNew);
      setShowNew(false);
    } catch (e) {
      console.error("Save new item error:", e);
      alert("❌ Item save nahi hua. Internet check karke dobara try karo.");
    } finally {
      setSavingItem(false);
    }
  };

  const commitQty = (rowId, raw) => {
    const v = parseFloat(String(raw).replace(",", "."));
    if (!Number.isFinite(v) || v <= 0) return false;
    setItems((prev) => prev.map((it) => (it._rowId === rowId ? { ...it, qty: Math.round(v * 100) / 100 } : it)));
    return true;
  };
  const commitPrice = (rowId, raw) => {
    const v = parseFloat(String(raw).replace(",", "."));
    if (!Number.isFinite(v) || v < 0) return false;
    setItems((prev) => prev.map((it) => (it._rowId === rowId ? { ...it, price: Math.round(v * 100) / 100 } : it)));
    return true;
  };
  const removeRow = (rowId) => setItems((prev) => prev.filter((it) => it._rowId !== rowId));

  const clash = isDraft && p.orderType === "dine_in"
    ? (orders || []).find((o) => o.orderType === "dine_in" && o.status !== "served" && o.status !== "cancelled" && Number(o.table) === Number(p.table))
    : null;

    const isDark = !!p.waiterMode;
  const bgMain = isDark ? "#0B111A" : "#F9FAFB";
  const bgCard = isDark ? "#161F2F" : "#fff";
  const textMain = isDark ? "#fff" : "#111827";
  const textMuted = isDark ? "#8B9BB4" : "#374151";
  const borderMain = isDark ? "#273449" : "#E5E7EB";

  const inp = { padding: isDesktop ? "9px 12px" : "10px 10px", border: `1px solid ${isDark ? "#273449" : "#E5E7EB"}`, borderRadius: 8, fontSize: isDesktop ? 13 : 14, width: "100%", boxSizing: "border-box", fontFamily: "inherit", minWidth: 0, background: isDark ? "#161F2F" : "#fff", color: isDark ? "#fff" : "#111827", colorScheme: isDark ? "dark" : "light", transition: "all 0.15s ease", outline: "none" };

  const chip = (on, color = "#DC2626") => ({ padding: isDesktop ? "7px 14px" : "8px 12px", borderRadius: 6, border: `1px solid ${on ? color : (isDark ? "#273449" : "#E5E7EB")}`, background: on ? color : (isDark ? "#161F2F" : "#fff"), color: on ? "#fff" : (isDark ? "#8B9BB4" : "#374151"), fontWeight: 600, fontSize: 12, cursor: "pointer", whiteSpace: "nowrap", fontFamily: "inherit", transition: "all 0.15s ease", boxShadow: on ? `0 1px 3px ${color}40` : "none" });
  const lbl = { fontSize: 10, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.4, color: isDark ? "#8B9BB4" : COLORS.textLight, minWidth: isDesktop ? 34 : 30 };
  const disabled = p.saving || items.length === 0;
  const footBtn = (bg, color, border) => ({ flex: 1, padding: isDesktop ? "11px 12px" : "9px 6px", borderRadius: 6, border: border || "none", background: disabled ? "#F3F4F6" : bg, color: disabled ? "#9CA3AF" : color, fontWeight: 700, fontSize: 13, cursor: disabled ? "not-allowed" : "pointer", fontFamily: "inherit", transition: "all 0.15s ease" });
  const actBtn = (bg, color, border) => ({ display: "none", flex: 1, padding: "11px 6px", borderRadius: 10, border: border || "none", background: disabled ? COLORS.paper2 : bg, color: disabled ? COLORS.textLight : color, fontWeight: 800, fontSize: 13, cursor: disabled ? "not-allowed" : "pointer", fontFamily: "inherit" });
  const qtyBtn = { width: isDesktop ? 24 : 28, height: isDesktop ? 24 : 28, border: "none", background: "transparent", color: COLORS.sage, fontSize: 16, fontWeight: 800, cursor: "pointer", padding: 0 };

  const menuPane = (
    <div style={{ display: "flex", flexDirection: "column", gap: 10, minHeight: 0, height: "100%", padding: isDesktop ? "16px 20px" : "12px 14px", background: bgMain }}>
      <div style={{ display: "flex", gap: 6 }}>
        <input placeholder="🔍 Item search..." value={search} onChange={(e) => setSearch(e.target.value)} style={{ ...inp, flex: 1, width: "auto" }} />
                <button type="button" onClick={() => setShowNew(true)} style={{ ...chip(true, COLORS.sage), padding: "9px 12px" }}>{isDesktop ? "➕ New Item" : "➕ Item"}</button>
        <button type="button" onClick={() => { setAiOpen(true); setAiErr(""); setAiRes(null); }} style={{ ...chip(true, COLORS.info), padding: "9px 12px" }}>{isDesktop ? "🤖 AI" : "🤖"}</button>

      </div>
            {aiOpen && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.55)", zIndex: 270, display: "flex", alignItems: "center", justifyContent: "center", padding: 12 }} onClick={closeAi}>
          <div onClick={(e) => e.stopPropagation()} style={{ background: isDark ? "#161F2F" : "#fff", borderRadius: 16, padding: 16, width: "100%", maxWidth: 400, maxHeight: "90vh", overflowY: "auto", display: "flex", flexDirection: "column", gap: 8 }}>
            <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 18, fontWeight: 800 }}>🤖 AI Order</div>
            <div style={{ fontSize: 11, color: isDark ? "#8B9BB4" : COLORS.textLight }}>Bolo ya likho: "table 5, 2 chicken biryani, paneer tikka half, ek cold coffee"</div>
            <textarea value={aiText} onChange={(e) => setAiText(e.target.value)} rows={3} placeholder="Order yahan bolo / likho..." style={{ ...inp, resize: "none" }} />
            <div style={{ display: "flex", gap: 6 }}>
              <button type="button" onClick={startMic} style={{ ...chip(listening, COLORS.rust), flex: 1, padding: "10px 6px" }}>{listening ? "⏹️ Rukho" : "🎤 Bolo"}</button>
              <button type="button" disabled={aiBusy || !aiText.trim()} onClick={runAi} style={{ ...chip(true, COLORS.info), flex: 1, padding: "10px 6px", opacity: aiBusy || !aiText.trim() ? 0.5 : 1 }}>{aiBusy ? "⏳ Soch raha..." : "✨ Samjho"}</button>
            </div>
            {aiErr && <div style={{ color: COLORS.error, fontSize: 12, fontWeight: 700 }}>{aiErr}</div>}
            {aiRes && (
              <div style={{ background: isDark ? "#0B111A" : COLORS.paper, borderRadius: 10, padding: 10, border: `1.5px solid ${COLORS.gold}` }}>
                <div style={{ fontSize: 12, fontWeight: 800, marginBottom: 4 }}>
                  {aiRes.orderType === "parcel" ? "🛍️ Parcel" : aiRes.table ? `🍽️ Table ${aiRes.table}` : "🍽️ Table (nahi bola)"}
                </div>
                {(aiRes.items || []).map((l, i) => {
                  const m = (menu || []).find((x) => x.id === l.id);
                  return m ? <div key={i} style={{ fontSize: 13, fontWeight: 700 }}>{l.qty}× {m.name}{m.portion ? ` (${m.portion})` : ""} <span style={{ color: COLORS.copper }}>₹{m.price * l.qty}</span></div> : null;
                })}
                {aiRes.notes && <div style={{ fontSize: 12, marginTop: 4 }}>📝 {aiRes.notes}</div>}
                {(aiRes.unmatched || []).length > 0 && <div style={{ fontSize: 12, marginTop: 4, color: COLORS.warning, fontWeight: 700 }}>⚠️ Samajh nahi aaya: {aiRes.unmatched.join(", ")}</div>}
                <button type="button" disabled={(aiRes.items || []).length === 0} onClick={applyAi} style={{ ...chip(true, COLORS.sage), width: "100%", marginTop: 8, padding: "10px 6px" }}>✓ Bill me add karo</button>
              </div>
            )}
            <button type="button" onClick={closeAi} style={{ padding: 8, border: "none", background: "transparent", color: isDark ? "#8B9BB4" : COLORS.textLight, fontWeight: 700, cursor: "pointer" }}>Cancel</button>
          </div>
        </div>
      )}
      {showNew && (

        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.55)", zIndex: 260, display: "flex", alignItems: "center", justifyContent: "center", padding: 12 }} onClick={() => setShowNew(false)}>
          <div onClick={(e) => e.stopPropagation()} style={{ background: isDark ? "#161F2F" : "#fff", borderRadius: 16, padding: 16, width: "100%", maxWidth: 380, display: "flex", flexDirection: "column", gap: 8 }}>
            <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 18, fontWeight: 800 }}>➕ Naya Item</div>
            <input autoFocus placeholder="Item ka naam *" value={newItem.name} onChange={(e) => setNewItem({ ...newItem, name: e.target.value })} style={inp} />
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
              <input type="number" inputMode="decimal" placeholder="Rate ₹ *" value={newItem.price} onChange={(e) => setNewItem({ ...newItem, price: e.target.value })} style={inp} />
              <input placeholder="Portion (Half/Full)" value={newItem.portion} onChange={(e) => setNewItem({ ...newItem, portion: e.target.value })} style={inp} />
            </div>
            <select value={newItem.category} onChange={(e) => setNewItem({ ...newItem, category: e.target.value })} style={{ ...inp, background: isDark ? "#161F2F" : "#fff" }}>
              {cats.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
            <div style={{ display: "flex", gap: 6 }}>
              <button type="button" onClick={() => setNewItem({ ...newItem, veg: true })} style={{ ...chip(newItem.veg, COLORS.sage), flex: 1 }}>🟢 Veg</button>
              <button type="button" onClick={() => setNewItem({ ...newItem, veg: false })} style={{ ...chip(!newItem.veg, COLORS.rust), flex: 1 }}>🔴 Non-Veg</button>
            </div>
            <button type="button" disabled={savingItem} onClick={saveNewItem} style={{ padding: 12, borderRadius: 10, border: "none", background: savingItem ? COLORS.paper2 : COLORS.sage, color: savingItem ? COLORS.textLight : "#fff", fontWeight: 800, fontSize: 14, cursor: savingItem ? "wait" : "pointer" }}>
              {savingItem ? "⏳ Saving..." : "💾 Menu me save + bill me add"}
            </button>
            <button type="button" onClick={addCustomOnly} style={{ padding: 11, borderRadius: 10, border: `2px solid ${COLORS.info}`, background: "transparent", color: COLORS.info, fontWeight: 800, fontSize: 13, cursor: "pointer" }}>
              ➕ Sirf is bill me (menu me save nahi)
            </button>
            <button type="button" onClick={() => setShowNew(false)} style={{ padding: 8, border: "none", background: "transparent", color: isDark ? "#8B9BB4" : COLORS.textLight, fontWeight: 700, cursor: "pointer" }}>Cancel</button>
          </div>
        </div>
      )}
      <div style={{ display: "flex", gap: 6, overflowX: "auto", paddingBottom: 2, flexShrink: 0 }}>
        {["all", ...cats].map((c) => (
          <button key={c} type="button" onClick={() => setCat(c)} style={chip(cat === c, "#111827")}>{c === "all" ? "All" : c}</button>
        ))}
      </div>
      <div style={{ flex: 1, minHeight: 0, overflowY: "auto", display: "grid", gridTemplateColumns: isDesktop ? "repeat(auto-fill, minmax(170px, 1fr))" : "repeat(2, 1fr)", gap: 6, alignContent: "start" }}>
        {list.length === 0 && <div style={{ gridColumn: "1 / -1", textAlign: "center", padding: 20, color: isDark ? "#8B9BB4" : COLORS.textLight, fontSize: 12 }}>Koi item nahi mila</div>}
        {list.map((m) => {
          const q = qtyOf(m.id);
          return (
            <button key={m.id} type="button" onClick={() => addItem(m)} style={{ textAlign: "left", padding: "6px 8px", borderRadius: 5, border: `1px solid ${q > 0 ? "#16A34A" : borderMain}`, background: bgCard, cursor: "pointer", position: "relative", fontFamily: "inherit", minHeight: isDesktop ? 36 : 46, transition: "all 0.15s ease", boxShadow: q > 0 ? "0 1px 3px rgba(22,163,74,0.15)" : "none" }} className="smooth-transition hover-lift">
              <div style={{ display: "flex", gap: 5, alignItems: "flex-start" }}>
                <VegDot veg={m.veg} />
                <span style={{ fontSize: 12, fontWeight: 700, lineHeight: 1.2, color: textMain, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>{m.name}</span>
              </div>
              <div style={{ fontSize: 12, fontWeight: 800, color: COLORS.copper, marginTop: 3 }}>
                ₹{m.price}{m.portion ? <span style={{ color: isDark ? "#8B9BB4" : COLORS.textLight, fontWeight: 600 }}> · {m.portion}</span> : null}
              </div>
              {q > 0 && <span style={{ position: "absolute", top: 4, right: 4, background: COLORS.sage, color: "#fff", borderRadius: 10, padding: "1px 7px", fontSize: 11, fontWeight: 800 }}>{q}</span>}
            </button>
          );
        })}
      </div>
    </div>
  );

  const billPane = (
    <div style={{ display: "flex", flexDirection: "column", gap: isDesktop ? 8 : 6, minHeight: 0, height: isDesktop ? "100%" : "auto", overflowY: isDesktop ? "auto" : "visible" }}>
      <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center" }}>
        {isDraft ? (
          <>
            <button type="button" onClick={() => p.setOrderType("dine_in")} style={chip(p.orderType === "dine_in")}>🍽️ Table</button>
            <button type="button" onClick={() => p.setOrderType("parcel")} style={chip(p.orderType === "parcel")}>🛍️ Parcel</button>
            {p.orderType === "dine_in" && (
              <select value={p.table} onChange={(e) => p.setTable(Number(e.target.value))} style={{ ...inp, width: 84 }}>
                {Array.from({ length: 20 }, (_, i) => i + 1).map((n) => <option key={n} value={n}>T-{n}</option>)}
              </select>
            )}
            <select value={p.waiter} onChange={(e) => p.setWaiter(e.target.value)} style={{ ...inp, flex: 1, minWidth: 90, width: "auto", background: isDark ? "#161F2F" : "#fff" }}>

              <option value="">🧑‍🍳 Waiter chuno</option>
              {p.waiter && !waiterNames.includes(p.waiter) && <option value={p.waiter}>{p.waiter}</option>}
              {waiterNames.map((n) => <option key={n} value={n}>{n}</option>)}
            </select>
          </>
        ) : (
          <div style={{ fontWeight: 800, fontSize: 13 }}>
            {order.orderType === "parcel" ? "🛍️ Parcel" : `🍽️ Table ${order.table}`} · #{order.id.slice(1, 9).toUpperCase()}{order.waiter ? ` · 🧑‍🍳 ${order.waiter}` : ""}
          </div>
        )}
      </div>

      {clash && (
        <div style={{ background: "#FFF3E0", border: `1.5px solid ${COLORS.warning}`, borderRadius: 8, padding: "6px 8px", fontSize: 12, fontWeight: 700, display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8 }}>
          <span>⚠️ Table {p.table} pe order #{clash.id.slice(1, 5).toUpperCase()} pehle se chal raha hai</span>
          <button type="button" onClick={() => p.onOpenOrder(clash)} style={chip(true, COLORS.info)}>Wahi kholo</button>
        </div>
      )}

      {(presets.customers || []).length > 0 && (
        <select value="" onChange={(e) => { const c = (presets.customers || [])[Number(e.target.value)]; if (c) { p.setCustName(c.name); p.setCustPhone(c.phone || ""); } }} style={{ ...inp, background: isDark ? "#161F2F" : "#fff" }}>
          <option value="">👤 Saved customer chuno...</option>
          {(presets.customers || []).map((c, i) => <option key={i} value={i}>{c.name}{c.phone ? ` · ${c.phone}` : ""}</option>)}
        </select>
      )}
           <div style={{ background: isDark ? "#161F2F" : "linear-gradient(135deg, #FDFCFA 0%, #F7F5F0 100%)", borderRadius: 12, padding: 10, border: `1px solid ${isDark ? "#273449" : "#E8E6DC"}` }}>
        <div style={{ fontSize: 10, fontWeight: 800, color: isDark ? "#8B9BB4" : COLORS.textLight, textTransform: "uppercase", letterSpacing: 0.4, marginBottom: 6 }}>👤 Customer</div>
        <div style={{ display: "grid", gridTemplateColumns: "1.2fr 1fr 1fr", gap: 6 }}>
          <input placeholder="Name" value={p.custName} onChange={(e) => p.setCustName(e.target.value)} style={inp} />
          <input placeholder="Phone" value={p.custPhone} onChange={(e) => p.setCustPhone(e.target.value)} style={inp} />
          <input placeholder="GSTIN" value={p.gstin} onChange={(e) => p.setGstin(e.target.value.toUpperCase())} style={inp} />
        </div>
      </div>

      <div style={{ flex: isDesktop ? "1 1 auto" : "none", minHeight: isDesktop ? 220 : 140, maxHeight: isDesktop ? "none" : "42dvh", overflowY: "auto", border: `1px solid ${borderMain}`, borderRadius: 6, background: bgCard }}>
        {items.length === 0 && <div style={{ textAlign: "center", padding: "30px 16px", color: "#9CA3AF", fontSize: 13, fontWeight: 600 }}>👈 Menu se item tap karo</div>}
        {items.map((it) => (
          <div key={it._rowId} style={{ display: "flex", alignItems: "center", gap: 6, padding: "5px 10px", borderBottom: `1px solid #F3F4F6`, transition: "background 0.15s ease", minHeight: 38 }} onMouseEnter={(e) => e.currentTarget.style.background = "#F9FAFB"} onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}>
            <div style={{ flex: 1, minWidth: 0, display: "flex", alignItems: "center", gap: 6 }}>
              <span style={{ fontSize: 12, fontWeight: 700, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", color: isDark ? "#fff" : "#111827" }}>{it.name}{it.portion ? <span style={{ color: "#9CA3AF", fontWeight: 500 }}> · {it.portion}</span> : ""}</span>
              <input key={it._rowId + "_p_" + it.price} type="number" inputMode="decimal" min={0} step="any" defaultValue={it.price}
                onBlur={(e) => { if (!commitPrice(it._rowId, e.target.value)) e.target.value = it.price; }}
                onKeyDown={(e) => { if (e.key === "Enter") e.target.blur(); }}
                style={{ width: 48, padding: "2px 4px", border: `1px solid ${isDark ? "#273449" : "#E5E7EB"}`, borderRadius: 4, fontSize: 11, fontWeight: 700, textAlign: "center", color: "#6B7280", background: isDark ? "#0B111A" : "#F9FAFB" }} />
            </div>
            <div style={{ display: "flex", alignItems: "center", border: `1.5px solid #DC2626`, borderRadius: 6, background: isDark ? "#161F2F" : "#fff", overflow: "hidden", height: 30 }}>
              <button type="button" onClick={() => changeQty(it._rowId, -1)} style={{ width: 26, height: 30, border: "none", background: "#FEF2F2", color: "#DC2626", fontSize: 15, fontWeight: 900, cursor: "pointer", padding: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>−</button>
              <input key={it._rowId + "_q_" + it.qty} type="number" inputMode="decimal" min={0} step="any" defaultValue={it.qty}
                onBlur={(e) => { if (!commitQty(it._rowId, e.target.value)) e.target.value = it.qty; }}
                onKeyDown={(e) => { if (e.key === "Enter") e.target.blur(); }}
                style={{ width: 32, height: 30, textAlign: "center", border: "none", background: isDark ? "#161F2F" : "#fff", fontWeight: 900, fontSize: 14, color: "#DC2626", padding: 0, outline: "none" }} />
              <button type="button" onClick={() => changeQty(it._rowId, 1)} style={{ width: 26, height: 30, border: "none", background: "#DC2626", color: "#fff", fontSize: 15, fontWeight: 900, cursor: "pointer", padding: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>+</button>
            </div>
            <div style={{ width: 58, textAlign: "right", fontWeight: 900, fontSize: 13, fontFamily: "'JetBrains Mono', monospace", color: "#DC2626" }}>₹{Math.round(it.price * it.qty * 100) / 100}</div>
            <button type="button" onClick={() => removeRow(it._rowId)} style={{ background: "transparent", border: "none", color: "#9CA3AF", width: 20, height: 20, borderRadius: 4, fontSize: 12, cursor: "pointer", fontWeight: 800, padding: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>✕</button>
          </div>
        ))}
      </div>

      <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center" }}>
        <span style={lbl}>GST</span>
        {gstList.map((r) => (
          <button key={r} type="button" onClick={() => p.setGstRate(r)} style={chip(p.gstRate === r)}>{r === 0 ? "No" : r + "%"}</button>
        ))}
        <button type="button" onClick={() => p.setGstRate("custom")} style={chip(p.gstRate === "custom")}>Custom</button>
        {p.gstRate === "custom" && <input type="number" placeholder="%" value={p.gstCustom} onChange={(e) => p.setGstCustom(e.target.value)} style={{ ...inp, width: 60 }} />}
        <span style={{ ...lbl, marginLeft: 6 }}>Disc</span>
        {(presets.discounts || []).map((d) => (
          <button key={d} type="button" onClick={() => p.setDiscPct(p.discPct === d ? 0 : d)} style={chip(p.discPct === d, COLORS.success)}>{d}%</button>
        ))}
        <input type="number" min={0} max={100} placeholder="%" value={p.discPct || ""} onChange={(e) => p.setDiscPct(Math.min(100, Math.max(0, Number(e.target.value) || 0)))} style={{ ...inp, width: 56 }} />
        <input type="number" min={0} placeholder="₹" value={p.disc || ""} onChange={(e) => p.setDisc(Math.max(0, Number(e.target.value) || 0))} style={{ ...inp, width: 64 }} />
      </div>

      <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center" }}>
        <span style={lbl}>Pay</span>
        {[["cash", "Cash"], ["upi", "UPI"], ["card", "Card"], ["razorpay", "Razor"], ["due", "Due"]].map(([id, label]) => (
          <button key={id} type="button" onClick={() => p.setPayMode(id)} style={chip(p.payMode === id)}>{label}</button>
        ))}
        <button type="button" onClick={() => p.setPayStatus(p.payStatus === "paid" ? "pending" : "paid")} style={chip(true, p.payStatus === "paid" ? COLORS.success : COLORS.warning)}>
          {p.payStatus === "paid" ? "✓ Paid" : "⏳ Pending"}
        </button>
      </div>

      <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
        <div style={{ flex: 1, minWidth: 120, display: "flex", flexDirection: "column", gap: 4 }}>
          {(presets.notes || []).length > 0 && (
            <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
              {(presets.notes || []).map((n) => (
                <button key={n} type="button" onClick={() => p.setNotes(p.notes ? p.notes + ", " + n : n)} style={{ ...chip(false), padding: "3px 8px", fontSize: 11 }}>+ {n}</button>
              ))}
            </div>
          )}
          <input placeholder="Notes..." value={p.notes} onChange={(e) => p.setNotes(e.target.value)} style={inp} />
        </div>
        {!p.hidePrint && (
          <label style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 12, fontWeight: 700, cursor: "pointer" }}>
            <input type="checkbox" checked={p.showBillNo} onChange={(e) => p.setShowBillNo(e.target.checked)} /> Bill #
          </label>
        )}
        {isDraft && (
          <label style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 12, fontWeight: 700, cursor: "pointer" }}>
            <input type="checkbox" checked={p.sendKot} onChange={(e) => p.setSendKot(e.target.checked)} /> 🍳 Kitchen ko bhejo
          </label>
        )}
      </div>

      <div style={{ background: "linear-gradient(135deg, #FDFCFA 0%, #F5F3EE 100%)", borderRadius: 14, padding: "14px 16px", fontSize: 13, border: `1.5px solid #E8E0D0`, boxShadow: "0 4px 16px rgba(0,0,0,0.04)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", padding: "3px 0" }}><span style={{ color: "#6B7280", fontWeight: 600 }}>Subtotal</span><b style={{ fontFamily: "'JetBrains Mono', monospace", color: isDark ? "#fff" : "#111827" }}>₹{calc.sub}</b></div>
        {p.discPct > 0 && <div style={{ display: "flex", justifyContent: "space-between", color: COLORS.success }}><span>Discount {p.discPct}%</span><b>-₹{calc.discPctAmt}</b></div>}
        {p.disc > 0 && <div style={{ display: "flex", justifyContent: "space-between", color: COLORS.success }}><span>Extra discount</span><b>-₹{calc.discAmt}</b></div>}
        {calc.gstRate > 0 && <div style={{ display: "flex", justifyContent: "space-between", color: COLORS.copper }}><span>GST {calc.gstRate}%</span><b>+₹{calc.gst}</b></div>}
        {calc.delivery > 0 && <div style={{ display: "flex", justifyContent: "space-between", color: COLORS.copper }}><span>Delivery</span><b>+₹{calc.delivery}</b></div>}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: 20, fontWeight: 900, borderTop: `2px solid ${COLORS.ink}`, paddingTop: 10, marginTop: 8 }}>
          <span style={{ letterSpacing: "0.05em" }}>TOTAL</span><span style={{ color: COLORS.copper, fontFamily: "'JetBrains Mono', monospace", fontSize: 22 }}>₹{calc.total}</span>
        </div>
      </div>

      <div style={{ display: "flex", gap: 6 }}>
        <button type="button" disabled={disabled} onClick={() => p.onAction("save")} style={actBtn("transparent", COLORS.sage, `2px solid ${COLORS.sage}`)}>
          {p.saving ? "⏳..." : (isDraft && p.sendKot ? "🍳 KOT Bhejo" : "💾 Save")}
        </button>
        <button type="button" disabled={disabled} onClick={() => p.onAction("print")} style={actBtn(COLORS.info, "#fff")}>🖨️ Save & Print</button>
        <button type="button" disabled={disabled} onClick={() => p.onAction("paid")} style={actBtn(COLORS.sage, "#fff")}>✓ Paid & Print</button>
      </div>
    </div>
  );

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(17,24,39,0.55)", backdropFilter: "blur(6px)", zIndex: 200, display: "flex", alignItems: isDesktop ? "center" : "flex-end", justifyContent: "center" }} onClick={p.onClose}>
      <div onClick={(e) => e.stopPropagation()} className="slide-up"
       style={{ background: isDark ? "#161F2F" : "#fff", colorScheme: "light", width: isDesktop ? "min(1200px, 97vw)" : "100%",
 maxWidth: isDesktop ? 1280 : 560, height: isDesktop ? "96vh" : "98dvh", borderRadius: isDesktop ? 14 : "20px 20px 0 0", padding: isDesktop ? 0 : "0 0 calc(0px + env(safe-area-inset-bottom, 0px))", display: "flex", flexDirection: "column", boxSizing: "border-box", gap: 0, boxShadow: "0 25px 50px rgba(0,0,0,0.15)", overflow: "hidden" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 20, fontWeight: 800, background: "linear-gradient(135deg, #1A1A1A 0%, #3C3C3C 100%)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", letterSpacing: "-0.01em" }}>🧾 {isDraft ? "New Order + Bill" : "Order Bill"}</div>
          <button type="button" onClick={p.onClose} style={{ background: "rgba(0,0,0,0.05)", border: "none", borderRadius: "50%", width: 30, height: 30, fontSize: 14, cursor: "pointer" }}>✕</button>
        </div>

        {(isDesktop || tab === "bill") && (
          <div style={{ order: 99, display: "flex", gap: 8, alignItems: "center", flexShrink: 0, padding: "10px 16px", background: isDark ? "#0B111A" : "#F9FAFB", borderTop: `1px solid #E5E7EB` }}>
            <div style={{ fontWeight: 800, fontSize: 16, color: "#DC2626", fontFamily: "'JetBrains Mono', monospace", minWidth: 80 }}>₹{calc.total}</div>
            <button type="button" disabled={disabled} onClick={() => p.onAction("save")} style={footBtn("#DC2626", "#fff")}>
              {p.saving ? "⏳..." : (isDraft && p.sendKot ? "🍳 Send KOT" : "💾 Save")}
            </button>
            {!p.hidePrint && (
              <>
                <button type="button" disabled={disabled} onClick={() => p.onAction("print")} style={footBtn(COLORS.info, "#fff")}>🖨️ Print</button>
                <button type="button" disabled={disabled} onClick={() => p.onAction("paid")} style={footBtn(COLORS.sage, "#fff")}>✓ Paid + Print</button>
              </>
            )}
          </div>
        )}

        {isDesktop ? (
          <div style={{ display: "grid", gridTemplateColumns: "1.15fr 1fr", gridTemplateRows: "minmax(0, 1fr)", gap: 14, flex: 1, minHeight: 0, overflow: "hidden" }}>
            <div style={{ minHeight: 0, height: "100%", overflow: "hidden" }}>{menuPane}</div>
            <div style={{ minHeight: 0, height: "100%", overflow: "hidden" }}>{billPane}</div>
          </div>
        ) : (
          <>
            <div style={{ display: "flex", gap: 6 }}>
              <button type="button" onClick={() => setTab("menu")} style={{ ...chip(tab === "menu", COLORS.ink), flex: 1, padding: "8px 6px" }}>🍽️ Menu</button>
              <button type="button" onClick={() => setTab("bill")} style={{ ...chip(tab === "bill", COLORS.ink), flex: 1, padding: "8px 6px" }}>🧾 Bill ({itemCount}) · ₹{calc.total}</button>
            </div>
            <div style={{ flex: 1, minHeight: 0, overflowY: tab === "bill" ? "auto" : "hidden" }}>
              {tab === "menu" ? menuPane : billPane}
            </div>
            {tab === "menu" && (
              <button type="button" onClick={() => setTab("bill")} style={{ padding: "14px 16px", borderRadius: 8, border: "none", background: "#DC2626", color: "#fff", fontWeight: 800, fontSize: 14, cursor: "pointer", display: "flex", justifyContent: "space-between", alignItems: "center", boxShadow: "0 4px 12px rgba(220,38,38,0.25)" }}>
                <span>{itemCount} item{itemCount !== 1 ? "s" : ""}</span><span style={{ fontFamily: "'JetBrains Mono', monospace" }}>₹{calc.total} ➔</span>
              </button>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function StaffView({ menu = [], orders, advanceStatus, requestPinPrompt, calls, resolveCall, cancelOrderByStaff, placeOrder, categories = [], setMenuState }) {
  const active = orders.filter((o) => o.status !== "served" && o.status !== "cancelled").sort((a, b) => a.createdAt - b.createdAt);
  const activeCalls = calls.filter(c => c.status === 'active');
  const columns = ["new", "preparing", "ready"];
  const newOrderCount = active.filter(o => o.status === "new").length;
  const prevCountRef = useRef(newOrderCount);
  const [selectedOrderId, setSelectedOrderId] = useState(null);
  const [viewMode] = useViewMode();
  const [colTab, setColTab] = useState("new");
  const [showHelpModal, setShowHelpModal] = useState(false);
  const [billOrder, setBillOrder] = useState(null);
  const [billEditItems, setBillEditItems] = useState([]);
  const [billGstRate, setBillGstRate] = useState(0);
  const [billGstCustom, setBillGstCustom] = useState("");
  const [billDiscount, setBillDiscount] = useState(0);
  const [billDiscountPct, setBillDiscountPct] = useState(0);
  const [billPayMode, setBillPayMode] = useState("cash");
  const [billPayStatus, setBillPayStatus] = useState("paid");
  const [billCustomerName, setBillCustomerName] = useState("");
  const [billCustomerPhone, setBillCustomerPhone] = useState("");
  const [billCustomerGstin, setBillCustomerGstin] = useState("");
  const [billNotes, setBillNotes] = useState("");
  const [billSearch, setBillSearch] = useState("");
  const [billAddItemOpen, setBillAddItemOpen] = useState(false);
  const [billShowBillNo, setBillShowBillNo] = useState(true);
  const [billTable, setBillTable] = useState(1);
  const [billOrderType, setBillOrderType] = useState("dine_in");
  const [billWaiter, setBillWaiter] = useState("");
  const [billSendKot, setBillSendKot] = useState(true);
  const [billSaving, setBillSaving] = useState(false);

  // 📵 Kitchen screen band na ho
  useEffect(() => {
    let lock = null;
    const getLock = async () => {
      try { if ("wakeLock" in navigator) lock = await navigator.wakeLock.request("screen"); } catch (e) {}
    };
    getLock();
    const onVis = () => { if (document.visibilityState === "visible") getLock(); };
    document.addEventListener("visibilitychange", onVis);
    return () => {
      document.removeEventListener("visibilitychange", onVis);
      try { lock && lock.release(); } catch (e) {}
    };
  }, []);


  useEffect(() => {
    if (newOrderCount > prevCountRef.current) {
      playNotificationSound();
      if ('Notification' in window && Notification.permission === 'granted') {
        safeNotify('🛎️ New Order!', { body: `${newOrderCount} new waiting` });
      }
    }
    prevCountRef.current = newOrderCount;
  }, [newOrderCount]);

  const prevCallsRef = useRef(activeCalls.length);
  useEffect(() => {
    if (activeCalls.length > prevCallsRef.current) {
      const bell = new Audio("https://assets.mixkit.co/active_storage/sfx/951/951-preview.mp3");
      bell.play().catch(() => { });
    }
    prevCallsRef.current = activeCalls.length;
  }, [activeCalls.length]);

  useEffect(() => {
    const onKey = (e) => {
      const tag = (e.target?.tagName || "").toUpperCase();
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || e.target?.isContentEditable) return;
      if (billOrder) return;
      if (e.key === 'k' && e.ctrlKey) { e.preventDefault(); if (active[0]) setSelectedOrderId(active[0].id); }
      if (e.key === 'ArrowUp') { const i = active.findIndex(o => o.id === selectedOrderId); if (i > 0) setSelectedOrderId(active[i - 1].id); }
      if (e.key === 'ArrowDown') { const i = active.findIndex(o => o.id === selectedOrderId); if (i < active.length - 1 && i >= 0) setSelectedOrderId(active[i + 1].id); }
      if (e.key === 'Enter' && (e.ctrlKey || e.metaKey) && selectedOrderId) { const o = active.find(x => x.id === selectedOrderId); if (o) { e.preventDefault(); advanceStatus(o.id, o.status); } }
      if ((e.key === '?' || e.key === '/') && e.shiftKey) { e.preventDefault(); setShowHelpModal(v => !v); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [selectedOrderId, active, advanceStatus, billOrder]);

  const handlePrintReceipt = (order) => {
    const w = window.open('', '_blank', 'width=300,height=600');
    if (!w) return;
    const kots = order.kots?.length ? order.kots : [{ kotNumber: 1, items: order.items }];
    const itemsHtml = kots.map(kot => `<div style="margin-top:10px;border-top:1px dashed #000;padding-top:6px"><strong>KOT #${kot.kotNumber}${kot.isRunning ? ' (RUNNING)' : ''}</strong>${kot.items.map(it => `<div>${it.qty}x ${escapeHtml(it.name)}</div>`).join('')}</div>`).join('');
    const totalAmount = getOrderTotal(order);
    w.document.write(`<html><head><title>KOT</title><style>body{font-family:monospace;font-size:12px;padding:10px;width:260px}h2,h4{text-align:center;margin:4px 0}</style></head><body><h2>${escapeHtml(RESTAURANT.name)}</h2><h4>${order.orderType === 'parcel' ? 'PARCEL' : `TABLE ${escapeHtml(order.table)}`}</h4><p>Order: #${escapeHtml(order.id.toUpperCase())}<br/>Customer: ${escapeHtml(order.customer.name)}</p>${itemsHtml}<div style="text-align:right;font-weight:bold;margin-top:10px">Total: ₹${totalAmount}</div><script>window.print();setTimeout(()=>window.close(),500)</script></body></html>`);
    w.document.close();
  };
  const handlePrintReceiptOld = (order) => {
    const w = window.open('', '_blank', 'width=300,height=600');
    if (!w) return;
    const kots = order.kots?.length ? order.kots : [{ kotNumber: 1, items: order.items }];
    const itemsHtml = kots.map(kot => `<div style="margin-top:10px;border-top:1px dashed #000;padding-top:6px"><strong>KOT #${kot.kotNumber}${kot.isRunning ? ' (RUNNING)' : ''}</strong>${kot.items.map(it => `<div>${it.qty}x ${it.name}</div>`).join('')}</div>`).join('');
    const totalAmount = order.items.reduce((s, it) => s + (it.price * it.qty), 0) + (order.deliveryFee || 0) - (order.loyaltyDiscount || 0);
    w.document.write(`<html><head><title>KOT</title><style>body{font-family:monospace;font-size:12px;padding:10px;width:260px}h2,h4{text-align:center;margin:4px 0}</style></head><body><h2>${RESTAURANT.name}</h2><h4>${order.orderType === 'parcel' ? 'PARCEL' : `TABLE ${order.table}`}</h4><p>Order: #${order.id.toUpperCase()}<br/>Customer: ${order.customer.name}</p>${itemsHtml}<div style="text-align:right;font-weight:bold;margin-top:10px">Total: ₹${totalAmount}</div><script>window.print();setTimeout(()=>window.close(),500)</script></body></html>`);
    w.document.close();
  };

  // 🧾 OPEN BILL EDITOR
  const openBillEditor = (order) => {
    setBillOrder(order);
    setBillEditItems(
      order.items.map((it, i) => ({
        ...it,
        _origQty: it.qty,
        _rowId: i + "_" + Math.random().toString(36).slice(2, 6),
      }))
    );
    setBillGstRate(order.gstRate ?? 0);
    setBillGstCustom("");
    setBillDiscount(order.billEditedAt ? (order.billDiscount || 0) : (order.loyaltyDiscount || 0));
    setBillDiscountPct(order.billEditedAt ? (order.billDiscountPct || 0) : (order.discount || 0));
    setBillPayMode(order.payment || "cash");
    setBillPayStatus(order.paid ? "paid" : "pending");
    setBillCustomerName(isWalkIn(order.customer?.name) ? "" : (order.customer?.name || ""));
    setBillCustomerPhone(isWalkIn(order.customer?.phone) ? "" : (order.customer?.phone || ""));
    setBillCustomerGstin(order.customerGstin || "");
    setBillNotes(order.notes || "");
    setBillSearch("");
    setBillAddItemOpen(false);
    setBillShowBillNo(true);
    setBillTable(Number(order.table) || 1);
    setBillOrderType(order.orderType || "dine_in");
    setBillWaiter(order.waiter || "");
    setBillSendKot(!!order.isDraft);
  };

  // ➕ NEW ORDER — table/parcel, items, KOT aur bill sab yahin se
  const openNewOrder = (preTable) => {
    openBillEditor({
      id: uid("o"), isDraft: true,
      table: Number(preTable) || 1, orderType: "dine_in",
      customer: { name: "Walk-in", phone: "WALK-IN", address: "" },
      items: [], kots: [], waiter: "", takenBy: "staff",
      notes: "", payment: "cash", paymentStatus: "pending", paid: false,
      status: "new", createdAt: Date.now(),
      coinsClaimed: true, earnedCoins: 0, rewardUsedCoins: 0,
      deliveryFee: 0, loyaltyDiscount: 0, discount: 0
    });
  };

  // mode: "save" | "print" | "paid"
  const printKotSlip = (order, onDone) => {
  let fired = false;
  const next = () => { if (fired) return; fired = true; if (onDone) onDone(); };
    try {
      const kot = (order.kots && order.kots.length ? order.kots[order.kots.length - 1] : null) || { kotNumber: 1, items: order.items || [] };
      const rows = (kot.items || []).map((it) => `<div class="r"><span>${it.qty} x ${escapeHtml(it.name)}${it.portion ? " (" + escapeHtml(it.portion) + ")" : ""}</span></div>`).join("");
      const now = new Date().toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
      const iframe = document.createElement("iframe");
      iframe.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0;";
      document.body.appendChild(iframe);
      const w = iframe.contentWindow;
      setTimeout(() => { try { document.body.removeChild(iframe); } catch (e) {} }, 60000);
      w.document.open();
      w.document.write(`<!doctype html><html><head><meta http-equiv="Content-Security-Policy" content="script-src 'none'; object-src 'none'"><title>KOT</title><style>@page{margin:0}*{color:#000!important}body{font-family:Arial,sans-serif;width:280px;margin:0 auto;padding:8px;font-weight:700}h2,h3{text-align:center;margin:3px 0}.r{font-size:17px;padding:4px 0;border-bottom:1px dashed #000}.c{text-align:center;font-size:12px}</style></head><body><h2>KOT #${kot.kotNumber || 1}${kot.isRunning ? " (RUNNING)" : ""}</h2><h3>${order.orderType === "parcel" ? "PARCEL" : "TABLE " + escapeHtml(String(order.table))}</h3><div class="c">${escapeHtml(now)} · #${escapeHtml(order.id.slice(1, 5).toUpperCase())}${order.waiter ? " · " + escapeHtml(order.waiter) : ""}</div><div style="margin-top:8px">${rows}</div>${order.notes ? `<div class="c" style="margin-top:8px">Note: ${escapeHtml(order.notes)}</div>` : ""}</body></html>`);
      w.document.close();
      w.onafterprint = () => setTimeout(next, 400);
setTimeout(next, 20000);
setTimeout(() => { try { w.focus(); w.print(); } catch (e) { alert("⚠️ KOT print nahi ho paya: " + e.message); next(); } }, 400);
    } catch (e) { console.error("KOT print error:", e); next(); }
  };

  const handleBillAction = async (mode) => {
    if (billSaving || !billOrder) return;
    if (billEditItems.length === 0) { alert("⚠️ Pehle items add karo"); return; }
    setBillSaving(true);
    try {
      const wasDraft = !!billOrder.isDraft;
      const sendKot = billSendKot;
      const saved = await saveBillEdits(mode === "paid" ? { payStatus: "paid" } : {});
      if (!saved) return;
      const itemsSnapshot = billEditItems;
      if (mode === "paid" && saved.status === "ready") await advanceStatus(saved.id, "ready");
      setBillOrder(null);
      addDoc(collection(db, "auditLogs"), { orderId: saved.id, action: mode, by: (auth.currentUser && auth.currentUser.email) || "?", before: getOrderTotal(billOrder), after: saved.finalTotal, at: Date.now() }).catch(() => {});
      const doBill = () => { if (mode !== "save") printFinalBill(saved, itemsSnapshot); };
      if ((wasDraft && sendKot) || saved._ranKot) setTimeout(() => printKotSlip(saved, doBill), 200);
      else setTimeout(doBill, 200);
    } finally {
      setBillSaving(false);
    }
  };

  const handleBillActionOld = async (mode) => {
    if (billSaving || !billOrder) return;
    if (billEditItems.length === 0) { alert("⚠️ Pehle items add karo"); return; }
    setBillSaving(true);
    try {
      const saved = await saveBillEdits(mode === "paid" ? { payStatus: "paid" } : {});
      if (!saved) return;
      const itemsSnapshot = billEditItems;
      if (mode === "paid" && saved.status === "ready") await advanceStatus(saved.id, "ready");
      setBillOrder(null);
      if (mode !== "save") setTimeout(() => printFinalBill(saved, itemsSnapshot), 200);
    } finally {
      setBillSaving(false);
    }
  };

  // 🧮 BILL CALC
  const billCalc = useMemo(() => {
    if (!billOrder) return { sub: 0, gst: 0, discAmt: 0, discPctAmt: 0, total: 0, gstRate: 0 };
    const sub = Math.round(billEditItems.reduce((s, it) => s + (it.price || 0) * (it.qty || 0), 0));
    const gstRate = billGstRate === "custom" ? Number(billGstCustom) || 0 : Number(billGstRate) || 0;
    const discPctAmt = Math.round((sub * billDiscountPct) / 100);
    const afterPct = sub - discPctAmt;
    const gst = Math.round((afterPct * gstRate) / 100);
    const delivery = Number(billOrder.deliveryFee) || 0;
    const total = Math.max(0, afterPct - billDiscount) + gst + delivery;
    return { sub, gstRate, gst, discPctAmt, discAmt: billDiscount, total, delivery };
  }, [billOrder, billEditItems, billGstRate, billGstCustom, billDiscount, billDiscountPct]);

  // 💾 SAVE BILL EDITS TO FIRESTORE
  const saveBillEdits = async (override = {}) => {
    if (!billOrder) return null;
    try {
      const { sub, gstRate, gst, discPctAmt, discAmt, total } = billCalc;
      const updated = {
        items: billEditItems.map(({ _rowId, _new, _origQty, ...rest }) => (!billOrder.isDraft && _new ? { ...rest, kotNumber: getNextKotNo(billOrder) } : rest)),
        subtotal: sub,
        gstRate,
        gstAmount: gst,
        billDiscount: discAmt,
        billDiscountPct: billDiscountPct,
        billDiscountAmt: discPctAmt,
        finalTotal: total,
        payment: billPayMode,
        paid: (override.payStatus ?? billPayStatus) === "paid",
        paymentStatus: override.payStatus ?? billPayStatus,
        customer: {
          ...(billOrder.customer || {}),
          name: billCustomerName || "Walk-in",
          phone: billCustomerPhone || "WALK-IN",
        },
        customerGstin: billCustomerGstin || "",
        notes: billNotes,
        billEditedAt: Date.now(),
        billEditedBy: (auth.currentUser && auth.currentUser.email) || "staff",
      };
      const clean = JSON.parse(JSON.stringify(updated)); // undefined values hata deta hai (Firestore error fix)
      if (billOrder.isDraft) {
        const { isDraft, ...base } = billOrder;
        const kotItems = clean.items.map((it) => ({ ...it, kotNumber: 1 }));
        const fullOrder = JSON.parse(JSON.stringify({
          ...base, ...clean,
          table: billOrderType === "parcel" ? 0 : billTable,
          orderType: billOrderType,
          waiter: billWaiter || "Staff",
          items: kotItems,
          kots: billSendKot ? [{ id: uid("kot"), kotNumber: 1, items: kotItems, createdAt: Date.now(), status: "new", isRunning: false }] : [],
          status: billSendKot ? "new" : "served",
          ...(billSendKot ? {} : { servedAt: Date.now() })
        }));
        await placeOrder(fullOrder);
        return fullOrder;
      }
      const addedRows = billEditItems.map((it) => {
        if (it._new) return (it.qty || 0) > 0 ? it : null;
        const extra = (it.qty || 0) - (it._origQty ?? it.qty);
        return extra > 0 ? { ...it, qty: extra } : null;
      }).filter(Boolean);
      if (addedRows.length > 0) {
        const no = getNextKotNo(billOrder);
        const runKot = {
          id: uid("kot"), kotNumber: no,
          items: addedRows.map(({ _rowId, _new, _origQty, ...r }) => ({ ...r, kotNumber: no })),
          createdAt: Date.now(), status: "new", isRunning: true
        };
        clean.kots = JSON.parse(JSON.stringify([...getBaseKots(billOrder), runKot]));
        clean.status = "new";
        clean.lastKotAt = Date.now();
        await guardedOrderUpdate(billOrder, clean);
        return { ...billOrder, ...clean, _ranKot: true };
      }
      await guardedOrderUpdate(billOrder, clean);
      return { ...billOrder, ...updated };
    } catch (e) {
      console.error("saveBillEdits error:", e);
      alert("⚠️ Save fail: " + e.message);
      return null;
    }
  };

  // 🖨️ PRINT FINAL BILL
  const printFinalBill = (order, items) => {
    if (!order) return;
    const { sub, gstRate, gst, discPctAmt, discAmt, total } = billCalc;
    const payLabel = {
      cash: "Cash",
      upi: "UPI",
      card: "Card",
      razorpay: "Razorpay",
      due: "Due (Udhaar)",
    }[billPayMode] || billPayMode;

    const billNo = order.id.slice(1, 9).toUpperCase();
    const now = new Date().toLocaleString("en-IN", {
      day: "2-digit", month: "short", year: "numeric",
      hour: "2-digit", minute: "2-digit",
    });

    const itemsHtml = items
      .map(
        (it) => `<tr>
        <td style="text-align:left">${escapeHtml(it.name)}${it.portion ? ` <small>(${escapeHtml(it.portion)})</small>` : ""}</td>
        <td style="text-align:center">${it.qty}</td>
        <td style="text-align:right">₹${it.price}</td>
        <td style="text-align:right">₹${Math.round(it.price * it.qty * 100) / 100}</td>
      </tr>`
      )
      .join("");

    const billNoLine = billShowBillNo ? `<div><b>Bill #:</b> ${billNo}</div>` : `<div>&nbsp;</div>`;

    // Hidden iframe (popup block nahi hota)
    const iframe = document.createElement("iframe");
    iframe.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0;";
    document.body.appendChild(iframe);
    const w = iframe.contentWindow;
    setTimeout(() => { try { document.body.removeChild(iframe); } catch (e) {} }, 60000);

    w.document.open();
    w.document.write(`<!doctype html>
<html><head><meta http-equiv="Content-Security-Policy" content="script-src 'none'; object-src 'none'"><title>Bill ${billNo}</title>
<style>
  *{box-sizing:border-box;color:#000 !important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  div,span,b{font-size:13px !important;font-weight:700}
  @page{margin:0}
  body{font-family:Arial,Helvetica,sans-serif;font-size:14px;font-weight:700;padding:8px;width:290px;margin:0 auto;color:#000}
  h2,h4{text-align:center;margin:4px 0}
  h2{font-size:24px;font-weight:900;letter-spacing:1px}
  .line{border-top:2px dashed #000;margin:8px 0}
  table{width:100%;border-collapse:collapse;font-size:14px;font-weight:700}
  th,td{padding:4px 2px}
  th{border-bottom:2px solid #000;text-align:left;font-size:13px;font-weight:900}
  .totals td{padding:4px 2px;font-size:14px;font-weight:700}
  .grand td{font-size:20px;font-weight:900;border-top:3px solid #000;padding-top:8px}
  .footer{text-align:center;font-size:10px;margin-top:10px;line-height:1.4}
  .badge{display:inline-block;padding:3px 10px;border:2px solid #000;border-radius:10px;font-size:13px;font-weight:900;margin:2px}
  .center{text-align:center}
</style></head><body>

<h2>${escapeHtml(RESTAURANT.name)}</h2>
<div class="center" style="font-size:10px">${escapeHtml(RESTAURANT.address)}</div>
<div class="center" style="font-size:10px">Ph: ${RESTAURANT.phones.join(" / ")}</div>
${RESTAURANT.gstin ? `<div class="center" style="font-size:10px">GSTIN: ${escapeHtml(RESTAURANT.gstin)}</div>` : ""}

<div class="line"></div>
<div style="display:flex;justify-content:space-between;font-size:11px">
  ${billNoLine}
  <div><b>${order.orderType === "parcel" ? "PARCEL" : "T-" + escapeHtml(String(order.table))}</b></div>
</div>
<div style="font-size:10px;text-align:center;margin-top:4px">${now}</div>
${order.customer && order.customer.name && !isWalkIn(order.customer.name) ? `<div style="font-size:10px;margin-top:2px">Customer: ${escapeHtml(order.customer.name)}${order.customer.phone && !isWalkIn(order.customer.phone) ? " · " + escapeHtml(order.customer.phone) : ""}</div>` : ""}

${order.waiter ? `<div style="font-size:10px;margin-top:4px">Waiter: ${escapeHtml(order.waiter)}</div>` : ""}

<div class="line"></div>
<table>
  <thead><tr><th>Item</th><th style="text-align:center">Qty</th><th style="text-align:right">Rate</th><th style="text-align:right">Amt</th></tr></thead>
  <tbody>${itemsHtml}</tbody>
</table>
<div class="line"></div>

<table class="totals">
  <tr><td>Subtotal</td><td style="text-align:right">₹${sub}</td></tr>
  ${billDiscountPct > 0 ? `<tr><td>Discount (${billDiscountPct}%)</td><td style="text-align:right">-₹${discPctAmt}</td></tr>` : ""}
  ${discAmt > 0 ? `<tr><td>Extra Discount</td><td style="text-align:right">-₹${discAmt}</td></tr>` : ""}
  ${gstRate > 0 ? `<tr><td>CGST @ ${gstRate / 2}%</td><td style="text-align:right">+₹${Math.round(gst / 2)}</td></tr><tr><td>SGST @ ${gstRate / 2}%</td><td style="text-align:right">+₹${gst - Math.round(gst / 2)}</td></tr>` : ""}
  ${billCalc.delivery > 0 ? `<tr><td>Delivery</td><td style="text-align:right">+₹${billCalc.delivery}</td></tr>` : ""}
  <tr class="grand"><td>GRAND TOTAL</td><td style="text-align:right">₹${total}</td></tr>
</table>

<div class="line"></div>
<div class="center">
  <span class="badge">${payLabel}</span>
  <span class="badge">${order.paymentStatus === "paid" ? "PAID" : "PENDING"}</span>
</div>

${billNotes ? `<div style="font-size:10px;margin-top:8px;border-top:1px dashed #000;padding-top:6px"><b>Notes:</b> ${escapeHtml(billNotes)}</div>` : ""}

<div class="footer">
  <div>** Thank you! Visit again **</div>
  <div>${escapeHtml(RESTAURANT.tagline)}</div>
  <div style="margin-top:6px">Rate us on Google</div>
</div>

</body></html>`);
    w.document.close();

    setTimeout(() => {
      try { w.focus(); w.print(); } catch (e) { alert("⚠️ Print nahi ho paya: " + e.message); }
    }, 400);
  };
  return (
    <div style={{ padding: "12px 12px 40px", maxWidth: viewMode === "desktop" ? 1400 : 560, margin: "0 auto" }}>
      <KitchenNotificationColumn orders={active} selectedOrderId={selectedOrderId} onSelect={setSelectedOrderId} />

      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10, alignItems: 'center', flexWrap: 'wrap', gap: 10 }}>
        <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 22, fontWeight: 800 }}>🍳 Kitchen Board</div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button onClick={() => setShowHelpModal(true)} style={{ background: COLORS.paper2, border: `1.5px solid ${COLORS.line}`, borderRadius: 12, padding: "10px 16px", cursor: "pointer", fontWeight: 700 }}>⌨️ Shortcuts</button>
          <button onClick={() => openNewOrder()} style={{ background: COLORS.sage, color: "#fff", border: "none", borderRadius: 12, padding: "10px 16px", cursor: "pointer", fontWeight: 800 }}>➕ New Order</button>
          <ViewModeToggle />
          <button onClick={() => requestPinPrompt("admin")} style={{ background: COLORS.ink, color: "#fff", border: "none", borderRadius: 14, padding: "13px 20px", fontWeight: 700, cursor: 'pointer' }}>⚙️ Admin</button>
        </div>
      </div>
      <div style={{ fontSize: 12, color: COLORS.textLight, marginBottom: 8, fontWeight: 600 }}>👆 Tap to advance · Table pe tap = bill</div>

      {false && newOrderCount > 0 && (
        <div className="slide-up" style={{ background: 'rgba(226,89,56,0.1)', border: `2px solid ${COLORS.copper}`, borderRadius: 16, padding: 16, marginBottom: 24, display: 'flex', alignItems: 'center', gap: 12 }}>
          <span style={{ fontSize: 24 }}>🛎️</span>
          <div><div style={{ fontWeight: 800, fontSize: 16, color: COLORS.copper }}>{newOrderCount} New Order{newOrderCount > 1 ? 's' : ''}!</div><div style={{ fontSize: 13, color: COLORS.textLight }}>Tap the card to advance</div></div>
        </div>
      )}
            {/* 🍽️ Table Status Board */}
      <div style={{ marginBottom: 24 }}>
        <TableStatusBoard
          orders={orders}
          tables={20}
          compact
          onTableClick={(o) => openBillEditor(o)}
          onEmptyTableClick={(t) => openNewOrder(t)}
          showStats={true}
        />
      </div>

      {showHelpModal && <KeyboardHelpModal onClose={() => setShowHelpModal(false)} />}

      {activeCalls.length > 0 && (
        <div className="slide-up" style={{ background: "rgba(239,68,68,0.1)", border: `2px solid ${COLORS.error}`, borderRadius: 16, padding: 16, marginBottom: 24 }}>
          <h3 style={{ color: COLORS.error, margin: "0 0 12px 0" }}>🚨 Waiter Requested!</h3>
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
            {activeCalls.map(c => (
              <div key={c.id} style={{ background: '#fff', padding: "12px 16px", borderRadius: 12, display: 'flex', alignItems: 'center', gap: 16 }}>
                <span style={{ fontWeight: 800, fontSize: 16 }}>Table {c.table}</span>
                <button onClick={() => resolveCall(c.id)} style={{ background: COLORS.success, color: '#fff', border: 'none', padding: "6px 12px", borderRadius: 8, fontWeight: 700, cursor: 'pointer' }}>✓ Done</button>
              </div>
            ))}
          </div>
        </div>
      )}

      {viewMode !== "desktop" && (
        <div style={{ display: "flex", gap: 6, marginBottom: 10 }}>
          {columns.map((s) => (
            <button key={s} onClick={() => setColTab(s)} style={{ flex: 1, padding: "9px 6px", borderRadius: 10, border: `2px solid ${colTab === s ? STATUS_COLOR[s] : COLORS.line}`, background: colTab === s ? STATUS_COLOR[s] : "#fff", color: colTab === s ? "#fff" : COLORS.ink, fontWeight: 800, fontSize: 13, cursor: "pointer" }}>
              {STATUS_LABEL[s]} ({active.filter((o) => o.status === s).length})
            </button>
          ))}
        </div>
      )}
      <div style={{ display: "grid", gridTemplateColumns: viewMode === "desktop" ? "repeat(3, minmax(0, 1fr))" : "1fr", gap: 12 }}>
        {columns.filter((s) => viewMode === "desktop" || s === colTab).map((status) => {
          const list = active.filter((o) => o.status === status);
          return (
            <div key={status} style={{ background: COLORS.paper, border: `1px solid ${COLORS.line}`, borderRadius: 18, padding: 20 }}>
              <div style={{ display: "flex", gap: 10, marginBottom: 20, alignItems: "center" }}>
                <div style={{ width: 12, height: 12, borderRadius: "50%", background: STATUS_COLOR[status] }} />
                <div style={{ fontSize: 15, textTransform: "uppercase", fontWeight: 800, letterSpacing: "0.05em", color: STATUS_COLOR[status] }}>{STATUS_LABEL[status]}</div>
                <span style={{ fontSize: 13, background: STATUS_COLOR[status], color: "#fff", padding: "3px 10px", borderRadius: 14, fontWeight: 700, marginLeft: "auto" }}>{list.length}</span>
              </div>

              <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                {list.map((o) => {
                  const isSelected = selectedOrderId === o.id;
                  const runningCount = (o.kots || []).filter(k => k.isRunning).length;
                  return (
                    <div key={o.id} onClick={() => setSelectedOrderId(o.id)} style={{ background: isSelected ? COLORS.copper : '#fff', border: `2px solid ${isSelected ? COLORS.copper : COLORS.line}`, borderRadius: 12, padding: 10, cursor: 'pointer', transition: 'all 0.2s ease' }}>
                      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10, alignItems: "center" }}>
                        <div style={{ fontSize: 16, fontWeight: 800, color: isSelected ? '#fff' : (o.orderType === "parcel" ? COLORS.rust : COLORS.ink), display: "flex", alignItems: "center", flexWrap: "wrap", gap: 6 }}>
                          {o.orderType === "parcel" ? "🛍️ PARCEL" : `🍽️ Table ${o.table}`}
                          <KotBadge kots={o.kots} />
                          {runningCount > 0 && (<span style={{ background: isSelected ? 'rgba(255,255,255,0.3)' : COLORS.info, color: '#fff', fontSize: 10, padding: "2px 6px", borderRadius: 8, fontWeight: 800 }}>RUNNING</span>)}
                        </div>
                        <div style={{ fontSize: 12, fontWeight: 700, color: isSelected ? 'rgba(255,255,255,0.85)' : COLORS.textLight, background: isSelected ? 'rgba(255,255,255,0.2)' : COLORS.paper2, padding: '4px 10px', borderRadius: 12 }}>{timeAgo(o.createdAt)}</div>
                      </div>

                      <div style={{ borderTop: isSelected ? `1px solid rgba(255,255,255,0.3)` : `1.5px dashed ${COLORS.line}`, paddingTop: 8, marginBottom: 8 }}>
                        {o.items.map((it, idx) => {
                          const kot = (o.kots || []).find(k => k.kotNumber === (it.kotNumber || 1));
                          const hasActiveKot = (o.kots || []).some(k => k.status === status);
                          const isDone = !!kot && kot.status !== status && hasActiveKot;
                          return (
                            <div key={idx} style={{ fontSize: 13, marginBottom: 3, fontWeight: 600, color: isSelected ? '#fff' : COLORS.ink, opacity: isDone ? 0.45 : 1 }}>
                              <span style={{ fontWeight: 800, display: 'inline-block', width: 28 }}>{it.qty}×</span> {it.name}
                              {it.kotNumber > 1 && (<span style={{ fontSize: 10, marginLeft: 6, color: isSelected ? 'rgba(255,255,255,0.7)' : COLORS.info, fontWeight: 700 }}>KOT#{it.kotNumber}</span>)}
                              {isDone && (<span style={{ fontSize: 10, marginLeft: 6, fontWeight: 800 }}>✓ already sent</span>)}
                            </div>
                          );
                        })}
                        {[].map((it, idx) => (
                          <div key={idx} style={{ fontSize: 15, marginBottom: 6, fontWeight: 600, color: isSelected ? '#fff' : COLORS.ink }}>
                            <span style={{ fontWeight: 800, display: 'inline-block', width: 28 }}>{it.qty}×</span> {it.name}
                            {it.kotNumber > 1 && (<span style={{ fontSize: 10, marginLeft: 6, color: isSelected ? 'rgba(255,255,255,0.7)' : COLORS.info, fontWeight: 700 }}>KOT#{it.kotNumber}</span>)}
                          </div>
                        ))}
                        {o.orderType === "parcel" && (<div style={{ fontSize: 13, marginTop: 8, padding: "6px 10px", borderRadius: 8, fontWeight: 800, background: isSelected ? "rgba(255,255,255,0.2)" : "#FFF3E0", color: isSelected ? "#fff" : "#E65100" }}>📍 {o.customer?.address || "Address nahi"}<br />📞 {o.customer?.phone || "-"} · {o.customer?.name || "-"}</div>)}
                        {o.notes && (<div style={{ fontSize: 13, marginTop: 6, padding: "6px 10px", borderRadius: 8, fontWeight: 800, background: isSelected ? "rgba(255,255,255,0.2)" : "#FFFBEA", color: isSelected ? "#fff" : COLORS.ink }}>📝 {o.notes}</div>)}
                        {o.isScheduled && o.scheduledDate && (<div style={{ fontSize: 13, marginTop: 6, padding: "6px 10px", borderRadius: 8, fontWeight: 800, background: isSelected ? "rgba(255,255,255,0.2)" : "#E3F2FD", color: isSelected ? "#fff" : "#1565C0" }}>📅 Scheduled: {o.scheduledDate} {o.scheduledTime}</div>)}
                        {o.claimedReward && (<div style={{ fontSize: 14, marginTop: 10, padding: '6px 10px', background: isSelected ? 'rgba(255,255,255,0.2)' : COLORS.sageLight, color: isSelected ? '#fff' : COLORS.sageDark, borderRadius: 8, fontWeight: 800 }}>🎁 FREE: {o.claimedReward}</div>)}
                        {o.payment && (<div style={{ fontSize: 11, marginTop: 6, color: isSelected ? 'rgba(255,255,255,0.7)' : COLORS.textLight, fontWeight: 600 }}>💳 {o.payment} {o.paid ? '✅' : '⏳'}</div>)}
                      </div>

                      <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
                        {!(o.orderType === "parcel" && o.status === "ready") ? (
                          <button onClick={(e) => { e.stopPropagation(); advanceStatus(o.id, status); }} style={{ flex: 1, padding: "10px 8px", border: "none", borderRadius: 12, fontWeight: 800, fontSize: 13, cursor: "pointer", background: status === "ready" ? COLORS.sage : (status === "preparing" ? COLORS.copper : COLORS.ink), color: "#fff" }}>
                            {status === "new" ? "👨‍🍳 Start Cooking" : status === "preparing" ? "✅ Mark Ready" : "🍽️ Mark Served"}
                          </button>
                        ) : (
                          <div style={{ flex: 1, padding: "10px 8px", borderRadius: 12, fontWeight: 800, fontSize: 13, border: "1px dashed " + COLORS.line, color: COLORS.textLight, textAlign: "center", display: "flex", alignItems: "center", justifyContent: "center" }}>Rider Pending</div>
                        )}
                        <button onClick={(e) => { e.stopPropagation(); printKotSlip(o); }} title="Print KOT (Kitchen)" style={{ background: isSelected ? 'rgba(255,255,255,0.25)' : COLORS.paper2, color: isSelected ? '#fff' : COLORS.ink, border: 'none', width: 44, height: 38, borderRadius: 12, fontSize: 18, cursor: 'pointer' }}>🍳</button>
                        <button onClick={(e) => { e.stopPropagation(); openBillEditor(o); }} title="Edit & Print Bill" style={{ background: COLORS.sage, color: '#fff', border: 'none', width: 52, height: 48, borderRadius: 12, fontSize: 18, cursor: 'pointer', fontWeight: 800 }}>🧾</button>
                        <button onClick={(e) => { e.stopPropagation(); if (window.confirm(`Cancel order #${o.id.slice(1, 5)}?`)) { cancelOrderByStaff && cancelOrderByStaff(o.id); } }} style={{ background: 'transparent', color: isSelected ? '#fff' : COLORS.error, border: `1.5px solid ${isSelected ? 'rgba(255,255,255,0.5)' : COLORS.error}`, width: 48, height: 48, borderRadius: 12, fontSize: 18, cursor: 'pointer', fontWeight: 800 }}>✕</button>
                      </div>
                    </div>
                  );
                })}
                {list.length === 0 && (<div style={{ textAlign: "center", padding: "20px 0", color: COLORS.textLight, fontSize: 13, fontStyle: "italic" }}>No orders</div>)}
              </div>
            </div>
          );
        })}
      </div>

      {/* 🧾 NEW: ONE-SCREEN ORDER + BILL */}
      {billOrder ? (
        <BillPOSScreen
          order={billOrder} orders={orders} menu={menu} categories={categories} viewMode={viewMode} setMenuState={setMenuState}
          items={billEditItems} setItems={setBillEditItems} calc={billCalc}
          orderType={billOrderType} setOrderType={setBillOrderType}
          table={billTable} setTable={setBillTable}
          waiter={billWaiter} setWaiter={setBillWaiter}
          sendKot={billSendKot} setSendKot={setBillSendKot}
          custName={billCustomerName} setCustName={setBillCustomerName}
          custPhone={billCustomerPhone} setCustPhone={setBillCustomerPhone}
          gstin={billCustomerGstin} setGstin={setBillCustomerGstin}
          gstRate={billGstRate} setGstRate={setBillGstRate}
          gstCustom={billGstCustom} setGstCustom={setBillGstCustom}
          disc={billDiscount} setDisc={setBillDiscount}
          discPct={billDiscountPct} setDiscPct={setBillDiscountPct}
          payMode={billPayMode} setPayMode={setBillPayMode}
          payStatus={billPayStatus} setPayStatus={setBillPayStatus}
          notes={billNotes} setNotes={setBillNotes}
          showBillNo={billShowBillNo} setShowBillNo={setBillShowBillNo}
          saving={billSaving}
          onClose={() => setBillOrder(null)}
          onOpenOrder={(o) => openBillEditor(o)}
          onAction={handleBillAction}
        />
      ) : null}

      {/* 🧾 OLD BILL EDITOR (hidden) */}
      {false && billOrder && (
        <div
          style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.65)', backdropFilter: 'blur(4px)', zIndex: 200, display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}
          onClick={() => setBillOrder(null)}>
          <div
            onClick={(e) => e.stopPropagation()}
            className="slide-up"
            style={{ background: '#fff', width: '100%', maxWidth: 520, maxHeight: '94vh', overflowY: 'auto', borderRadius: '24px 24px 0 0', padding: '20px' }}>

            {/* HEADER */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
              <div>
                <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 22, fontWeight: 800 }}>🧾 Edit & Print Bill</div>
                <div style={{ fontSize: 12, color: COLORS.textLight, marginTop: 2 }}>
                  Order #{billOrder.id.slice(1, 9).toUpperCase()} · {billOrder.orderType === 'parcel' ? '🛍️ Parcel' : `🍽️ Table ${billOrder.table}`}
                </div>
              </div>
              <button onClick={() => setBillOrder(null)} style={{ background: 'rgba(0,0,0,0.05)', border: 'none', borderRadius: '50%', width: 36, height: 36, fontSize: 18, cursor: 'pointer' }}>✕</button>
            </div>

            {/* CUSTOMER DETAILS */}
            <div style={{ background: COLORS.paper, borderRadius: 14, padding: 14, marginBottom: 14 }}>
              <div style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 0.5, color: COLORS.textLight, marginBottom: 10 }}>👤 Customer Details</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 10 }}>
                <input placeholder="Customer Name" value={billCustomerName} onChange={(e) => setBillCustomerName(e.target.value)}
                  style={{ padding: 10, border: `1.5px solid ${COLORS.line}`, borderRadius: 10, fontSize: 14, width: '100%', boxSizing: 'border-box' }} />
                <input placeholder="Phone" value={billCustomerPhone} onChange={(e) => setBillCustomerPhone(e.target.value)}
                  style={{ padding: 10, border: `1.5px solid ${COLORS.line}`, borderRadius: 10, fontSize: 14, width: '100%', boxSizing: 'border-box' }} />
              </div>
              <input placeholder="Customer GSTIN (optional)" value={billCustomerGstin} onChange={(e) => setBillCustomerGstin(e.target.value.toUpperCase())}
                style={{ padding: 10, border: `1.5px solid ${COLORS.line}`, borderRadius: 10, fontSize: 14, width: '100%', boxSizing: 'border-box', fontFamily: "'JetBrains Mono', monospace" }} />
            </div>

            {/* ITEMS */}
            <div style={{ background: COLORS.paper, borderRadius: 14, padding: 14, marginBottom: 14 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                <div style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 0.5, color: COLORS.textLight }}>🍽️ Items ({billEditItems.length})</div>
                <button onClick={() => setBillAddItemOpen(!billAddItemOpen)}
                  style={{ background: COLORS.info, color: '#fff', border: 'none', padding: '6px 12px', borderRadius: 8, fontWeight: 800, fontSize: 12, cursor: 'pointer' }}>
                  {billAddItemOpen ? '✕ Close' : '➕ Add Item'}
                </button>
              </div>

              {billAddItemOpen && (
                <div style={{ background: '#fff', borderRadius: 10, padding: 10, marginBottom: 12, border: `1.5px solid ${COLORS.info}` }}>
                  <input autoFocus placeholder="🔍 Search menu to add..." value={billSearch} onChange={(e) => setBillSearch(e.target.value)}
                    style={{ padding: 10, border: `1.5px solid ${COLORS.line}`, borderRadius: 10, fontSize: 14, width: '100%', boxSizing: 'border-box', marginBottom: 8 }} />
                  <div style={{ maxHeight: 200, overflowY: 'auto' }}>
                    {(billSearch.trim()
                      ? menu.filter((m) => m.available && m.name.toLowerCase().includes(billSearch.toLowerCase()))
                      : menu.filter((m) => m.available).slice(0, 8)
                    ).slice(0, 15).map((m) => (
                      <div key={m.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 4px', borderBottom: `1px solid ${COLORS.line}` }}>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontSize: 13, fontWeight: 700, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{m.name}</div>
                          <div style={{ fontSize: 11, color: COLORS.copper, fontWeight: 700 }}>₹{m.price}</div>
                        </div>
                        <button onClick={() => {
                          const existing = billEditItems.findIndex((it) => it.itemId === m.id && !it.portion);
                          if (existing >= 0) {
                            const updated = [...billEditItems];
                            updated[existing] = { ...updated[existing], qty: updated[existing].qty + 1 };
                            setBillEditItems(updated);
                          } else {
                            setBillEditItems([...billEditItems, {
                              itemId: m.id, name: m.name, portion: m.portion || '',
                              price: m.price, qty: 1,
                              _rowId: Date.now() + '_' + Math.random().toString(36).slice(2, 5),
                            }]);
                          }
                        }} style={{ background: COLORS.sage, color: '#fff', border: 'none', padding: '6px 12px', borderRadius: 8, fontWeight: 800, fontSize: 12, cursor: 'pointer' }}>+ Add</button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div>
                {billEditItems.length === 0 && (
                  <div style={{ textAlign: 'center', padding: 20, color: COLORS.textLight, fontSize: 13 }}>No items. Add some!</div>
                )}
                {billEditItems.map((it, idx) => (
                  <div key={it._rowId || idx} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 4px', borderBottom: `1px solid ${COLORS.line}` }}>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 13, fontWeight: 700, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {it.name} {it.portion ? <span style={{ color: COLORS.textLight, fontSize: 11 }}>({it.portion})</span> : null}
                      </div>
                      <div style={{ fontSize: 11, color: COLORS.copper, fontWeight: 700 }}>₹{it.price} × {it.qty} = ₹{it.price * it.qty}</div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 4, border: `1.5px solid ${COLORS.sage}`, borderRadius: 8, padding: '2px' }}>
                      <button onClick={() => {
                        const updated = [...billEditItems];
                        if (updated[idx].qty <= 1) updated.splice(idx, 1);
                        else updated[idx] = { ...updated[idx], qty: updated[idx].qty - 1 };
                        setBillEditItems(updated);
                      }} style={{ width: 26, height: 26, border: 'none', background: 'transparent', color: COLORS.sage, fontSize: 18, fontWeight: 800, cursor: 'pointer' }}>−</button>
                      <span style={{ fontWeight: 800, fontSize: 13, minWidth: 16, textAlign: 'center' }}>{it.qty}</span>
                      <button onClick={() => {
                        const updated = [...billEditItems];
                        updated[idx] = { ...updated[idx], qty: updated[idx].qty + 1 };
                        setBillEditItems(updated);
                      }} style={{ width: 26, height: 26, border: 'none', background: 'transparent', color: COLORS.sage, fontSize: 18, fontWeight: 800, cursor: 'pointer' }}>+</button>
                    </div>
                    <button onClick={() => {
                      if (window.confirm(`Remove "${it.name}"?`)) {
                        setBillEditItems(billEditItems.filter((_, i) => i !== idx));
                      }
                    }} style={{ background: 'transparent', border: `1.5px solid ${COLORS.error}`, color: COLORS.error, width: 32, height: 32, borderRadius: 8, fontSize: 14, cursor: 'pointer', fontWeight: 800 }}>✕</button>
                  </div>
                ))}
              </div>
            </div>

            {/* GST */}
            <div style={{ background: COLORS.paper, borderRadius: 14, padding: 14, marginBottom: 14 }}>
              <div style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 0.5, color: COLORS.textLight, marginBottom: 10 }}>🧾 GST</div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                {[0, 5, 12, 18].map((rate) => (
                  <button key={rate} onClick={() => setBillGstRate(rate)}
                    style={{
                      padding: '8px 14px', borderRadius: 10,
                      border: `2px solid ${billGstRate === rate ? COLORS.copper : COLORS.line}`,
                      background: billGstRate === rate ? COLORS.copperLight : '#fff',
                      color: billGstRate === rate ? COLORS.copperDark : COLORS.text,
                      fontWeight: 800, fontSize: 13, cursor: 'pointer',
                    }}>
                    {rate === 0 ? 'No GST' : `${rate}%`}
                  </button>
                ))}
                <button onClick={() => setBillGstRate('custom')}
                  style={{
                    padding: '8px 14px', borderRadius: 10,
                    border: `2px solid ${billGstRate === 'custom' ? COLORS.copper : COLORS.line}`,
                    background: billGstRate === 'custom' ? COLORS.copperLight : '#fff',
                    color: billGstRate === 'custom' ? COLORS.copperDark : COLORS.text,
                    fontWeight: 800, fontSize: 13, cursor: 'pointer',
                  }}>
                  Custom
                </button>
                {billGstRate === 'custom' && (
                  <input type="number" placeholder="Rate %" value={billGstCustom} onChange={(e) => setBillGstCustom(e.target.value)}
                    style={{ padding: '8px 12px', border: `1.5px solid ${COLORS.line}`, borderRadius: 10, fontSize: 14, width: 100, fontWeight: 800 }} />
                )}
              </div>
            </div>

            {/* DISCOUNT */}
            <div style={{ background: COLORS.paper, borderRadius: 14, padding: 14, marginBottom: 14 }}>
              <div style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 0.5, color: COLORS.textLight, marginBottom: 10 }}>🎁 Discount</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 700, color: COLORS.textLight, display: 'block', marginBottom: 4 }}>Percent (%)</label>
                  <input type="number" min={0} max={100} value={billDiscountPct || ''}
                    onChange={(e) => setBillDiscountPct(Math.min(100, Math.max(0, Number(e.target.value) || 0)))}
                    placeholder="0"
                    style={{ padding: 10, border: `1.5px solid ${COLORS.line}`, borderRadius: 10, fontSize: 14, width: '100%', boxSizing: 'border-box', fontWeight: 700 }} />
                </div>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 700, color: COLORS.textLight, display: 'block', marginBottom: 4 }}>Flat (₹)</label>
                  <input type="number" min={0} value={billDiscount || ''}
                    onChange={(e) => setBillDiscount(Math.max(0, Number(e.target.value) || 0))}
                    placeholder="0"
                    style={{ padding: 10, border: `1.5px solid ${COLORS.line}`, borderRadius: 10, fontSize: 14, width: '100%', boxSizing: 'border-box', fontWeight: 700 }} />
                </div>
              </div>
            </div>

            {/* PAYMENT */}
            <div style={{ background: COLORS.paper, borderRadius: 14, padding: 14, marginBottom: 14 }}>
              <div style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 0.5, color: COLORS.textLight, marginBottom: 10 }}>💳 Mode of Payment</div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginBottom: 12 }}>
                {[
                  { id: 'cash', icon: '💵', label: 'Cash' },
                  { id: 'upi', icon: '📱', label: 'UPI' },
                  { id: 'card', icon: '💳', label: 'Card' },
                  { id: 'razorpay', icon: '⚡', label: 'Razorpay' },
                  { id: 'due', icon: '⏳', label: 'Due' },
                ].map((m) => (
                  <button key={m.id} onClick={() => setBillPayMode(m.id)}
                    style={{
                      padding: '10px 6px', borderRadius: 10,
                      border: `2px solid ${billPayMode === m.id ? COLORS.copper : COLORS.line}`,
                      background: billPayMode === m.id ? COLORS.copperLight : '#fff',
                      color: billPayMode === m.id ? COLORS.copperDark : COLORS.text,
                      fontWeight: 800, fontSize: 12, cursor: 'pointer',
                      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
                    }}>
                    <span style={{ fontSize: 18 }}>{m.icon}</span>
                    <span>{m.label}</span>
                  </button>
                ))}
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                {['paid', 'pending'].map((s) => (
                  <button key={s} onClick={() => setBillPayStatus(s)}
                    style={{
                      flex: 1, padding: '10px', borderRadius: 10,
                      border: `2px solid ${billPayStatus === s ? (s === 'paid' ? COLORS.success : COLORS.warning) : COLORS.line}`,
                      background: billPayStatus === s ? (s === 'paid' ? 'rgba(16,185,129,0.15)' : 'rgba(255,152,0,0.15)') : '#fff',
                      color: billPayStatus === s ? (s === 'paid' ? COLORS.success : '#E65100') : COLORS.text,
                      fontWeight: 800, fontSize: 13, cursor: 'pointer',
                    }}>
                    {s === 'paid' ? '✓ Paid' : '⏳ Pending'}
                  </button>
                ))}
              </div>
            </div>

            {/* BILL NO TOGGLE + NOTES */}
            <label style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', marginBottom: 12, padding: 10, background: COLORS.paper, borderRadius: 10 }}>
              <input type="checkbox" checked={billShowBillNo} onChange={(e) => setBillShowBillNo(e.target.checked)} style={{ width: 18, height: 18 }} />
              <span style={{ fontWeight: 700, fontSize: 13 }}>🧾 Print Bill Number on receipt</span>
            </label>

            <div style={{ marginBottom: 14 }}>
              <div style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 0.5, color: COLORS.textLight, marginBottom: 6 }}>📝 Notes</div>
              <textarea placeholder="Special instructions / bill notes..." value={billNotes} onChange={(e) => setBillNotes(e.target.value)} rows={2}
                style={{ padding: 12, border: `1.5px solid ${COLORS.line}`, borderRadius: 10, fontSize: 14, width: '100%', boxSizing: 'border-box', resize: 'none' }} />
            </div>

            {/* TOTALS PREVIEW */}
            <div style={{ background: 'linear-gradient(135deg, #fdfbfb, #ebedee)', borderRadius: 14, padding: 16, marginBottom: 16, border: `1.5px solid ${COLORS.gold}` }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 6 }}>
                <span>Subtotal</span>
                <span style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700 }}>₹{billCalc.sub}</span>
              </div>
              {billDiscountPct > 0 && (
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: COLORS.success, marginBottom: 6 }}>
                  <span>Discount ({billDiscountPct}%)</span>
                  <span style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700 }}>-₹{billCalc.discPctAmt}</span>
                </div>
              )}
              {billDiscount > 0 && (
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: COLORS.success, marginBottom: 6 }}>
                  <span>Extra Discount</span>
                  <span style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700 }}>-₹{billCalc.discAmt}</span>
                </div>
              )}
              {billCalc.gstRate > 0 && (
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: COLORS.copper, marginBottom: 6 }}>
                  <span>GST @ {billCalc.gstRate}%</span>
                  <span style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700 }}>+₹{billCalc.gst}</span>
                </div>
              )}
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 18, fontWeight: 800, borderTop: `2px solid ${COLORS.ink}`, paddingTop: 10, marginTop: 6 }}>
                <span>GRAND TOTAL</span>
                <span style={{ fontFamily: "'JetBrains Mono', monospace", color: COLORS.copper }}>₹{billCalc.total}</span>
              </div>
            </div>

            {/* ACTIONS */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 10 }}>
              <button onClick={async () => {
                const saved = await saveBillEdits();
                if (saved) setBillOrder(null);
              }}
                style={{ padding: 14, borderRadius: 12, border: `2px solid ${COLORS.sage}`, background: 'transparent', color: COLORS.sage, fontWeight: 800, fontSize: 14, cursor: 'pointer' }}>
                💾 Save Only
              </button>
              <button onClick={async () => {
                const saved = await saveBillEdits();
                if (saved) {
                  setBillOrder(null);
                  setTimeout(() => printFinalBill(saved, billEditItems), 200);
                }
              }}
                style={{ padding: 14, borderRadius: 12, border: 'none', background: COLORS.info, color: '#fff', fontWeight: 800, fontSize: 14, cursor: 'pointer' }}>
                🖨️ Save & Print
              </button>
            </div>
            <button onClick={async () => {
              const saved = await saveBillEdits();
              if (saved) {
                if (billOrder.status === "ready") await advanceStatus(billOrder.id, "ready");
                setBillOrder(null);
                setTimeout(() => printFinalBill(saved, billEditItems), 200);
              }
            }}
              style={{ width: '100%', padding: 16, borderRadius: 14, border: 'none', background: COLORS.sage, color: '#fff', fontWeight: 800, fontSize: 15, cursor: 'pointer', marginBottom: 10 }}>
              ✓ Mark Paid & Print Bill
            </button>

            <div style={{ fontSize: 11, color: COLORS.textLight, textAlign: 'center', lineHeight: 1.5 }}>
              💡 Save karne se bill Firestore mein update hoga. Print aapke printer pe jayega.
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ==

// 18. ADMIN VIEW — HELPER COMPONENTS

 
// ==

function KitchenMetrics({ filteredOrders }) {
  const servedOrders = filteredOrders.filter(o => o.status === "served");
  if (servedOrders.length === 0) return null;
  const hourCounts = {};
  filteredOrders.forEach(o => { const hr = new Date(o.createdAt).getHours(); hourCounts[hr] = (hourCounts[hr] || 0) + 1; });
  const peakHourEntry = Object.entries(hourCounts).sort((a, b) => b[1] - a[1])[0];
  const peakHourLabel = peakHourEntry ? `${peakHourEntry[0]}:00` : "—";
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 16, marginBottom: 28 }}>
      <StatCard label="Completed" value={servedOrders.length} icon="✅" color={COLORS.sage} />
      <StatCard label="Peak Hour" value={peakHourLabel} icon="🔥" color={COLORS.copper} />
      <StatCard label="Total" value={filteredOrders.length} icon="📋" color={COLORS.gold} />
    </div>
  );
}

function InventoryAlertBanner({ inventory }) {
  const critical = inventory.filter(i => i.stock < 2);
  const warning = inventory.filter(i => i.stock >= 2 && i.stock < 5);
  if (critical.length === 0 && warning.length === 0) return null;
  return (
    <div style={{ marginBottom: 24 }}>
      {critical.length > 0 && (<div style={{ background: 'rgba(239, 68, 68, 0.1)', border: `2px solid ${COLORS.error}`, padding: 16, borderRadius: 12, marginBottom: 12 }}><h4 style={{ color: COLORS.error, margin: '0 0 10px' }}>🚨 CRITICAL</h4>{critical.map(item => (<div key={item.id} style={{ color: COLORS.error, fontWeight: 700, fontSize: 14 }}>❌ {item.name}: {item.stock} {item.unit}</div>))}</div>)}
      {warning.length > 0 && (<div style={{ background: 'rgba(255, 152, 0, 0.1)', border: `2px solid ${COLORS.warning}`, padding: 16, borderRadius: 12 }}><h4 style={{ color: COLORS.warning, margin: '0 0 10px' }}>⚠️ LOW STOCK</h4>{warning.map(item => (<div key={item.id} style={{ color: COLORS.warning, fontWeight: 600, fontSize: 14 }}>⚠️ {item.name}: {item.stock} {item.unit}</div>))}</div>)}
    </div>
  );
}

function PresetListEditor({ title, hint, items, onChange, placeholder, number, suffix }) {
  const [val, setVal] = useState("");
  const add = () => {
    const raw = val.trim();
    if (!raw) return;
    const v = number ? Number(raw) : raw;
    if (number && (!Number.isFinite(v) || v < 0)) { alert("⚠️ Sahi number daalo"); return; }
    if (items.some((x) => String(x).toLowerCase() === String(v).toLowerCase())) { setVal(""); return; }
    onChange([...items, v]);
    setVal("");
  };
  return (
    <div style={{ background: "#fff", border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: 16, marginBottom: 16 }}>
      <div style={{ fontWeight: 800, fontSize: 16 }}>{title}</div>
      <div style={{ fontSize: 12, color: COLORS.textLight, marginBottom: 10 }}>{hint}</div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 10 }}>
        {items.length === 0 && <span style={{ fontSize: 12, color: COLORS.textLight }}>Abhi koi nahi</span>}
        {items.map((it) => (
          <span key={String(it)} style={{ display: "inline-flex", alignItems: "center", gap: 6, background: COLORS.paper2, borderRadius: 20, padding: "5px 6px 5px 12px", fontWeight: 700, fontSize: 13 }}>
            {it}{suffix || ""}
            <button type="button" onClick={() => { if (window.confirm(`"${it}" delete karna hai?`)) onChange(items.filter((x) => x !== it)); }}
              style={{ background: COLORS.error, color: "#fff", border: "none", borderRadius: "50%", width: 22, height: 22, fontSize: 11, cursor: "pointer", fontWeight: 800, padding: 0 }}>✕</button>
          </span>
        ))}
      </div>
      <div style={{ display: "flex", gap: 8 }}>
        <input type={number ? "number" : "text"} placeholder={placeholder} value={val} onChange={(e) => setVal(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") add(); }}
          style={{ padding: "10px 12px", border: `1.5px solid ${COLORS.line}`, borderRadius: 10, fontSize: 14, flex: 1, boxSizing: "border-box" }} />
        <button type="button" onClick={add} style={{ background: COLORS.copper, color: "#fff", border: "none", borderRadius: 10, padding: "10px 18px", fontWeight: 800, cursor: "pointer" }}>+ Add</button>
      </div>
    </div>
  );
}

function PresetsAdmin() {
  const [presets, savePresets] = usePresets();
  const [cName, setCName] = useState("");
  const [cPhone, setCPhone] = useState("");
  const customers = presets.customers || [];
  const addCustomer = () => {
    if (!cName.trim()) { alert("⚠️ Customer ka naam daalo"); return; }
    savePresets({ ...presets, customers: [...customers, { name: cName.trim(), phone: cPhone.trim() }] });
    setCName(""); setCPhone("");
  };
  const fld = { padding: "10px 12px", border: `1.5px solid ${COLORS.line}`, borderRadius: 10, fontSize: 14, boxSizing: "border-box" };
  return (
    <div>
      <div style={{ fontSize: 13, color: COLORS.textLight, marginBottom: 16, lineHeight: 1.5 }}>
        Yahan ek baar daalo, hamesha save rahega. Staff ke bill screen me sirf select karna padega.
      </div>
      <PresetListEditor title="🧑‍🍳 Waiters" hint="Bill screen me chips ki tarah dikhenge" placeholder="Waiter ka naam"
        items={presets.waiters || []} onChange={(l) => savePresets({ ...presets, waiters: l })} />
      <div style={{ background: "#fff", border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: 16, marginBottom: 16 }}>
        <div style={{ fontWeight: 800, fontSize: 16 }}>👤 Saved Customers</div>
        <div style={{ fontSize: 12, color: COLORS.textLight, marginBottom: 10 }}>Select karte hi naam + phone bhar jayega</div>
        {customers.length === 0 && <div style={{ fontSize: 12, color: COLORS.textLight, marginBottom: 10 }}>Abhi koi nahi</div>}
        {customers.map((c, i) => (
          <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", background: COLORS.paper2, borderRadius: 10, padding: "8px 12px", marginBottom: 6, fontWeight: 700, fontSize: 13 }}>
            <span>{c.name}{c.phone ? ` · ${c.phone}` : ""}</span>
            <button type="button" onClick={() => { if (window.confirm(`"${c.name}" delete karna hai?`)) savePresets({ ...presets, customers: customers.filter((_, k) => k !== i) }); }}
              style={{ background: COLORS.error, color: "#fff", border: "none", borderRadius: "50%", width: 24, height: 24, fontSize: 11, cursor: "pointer", fontWeight: 800, padding: 0 }}>✕</button>
          </div>
        ))}
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 8 }}>
          <input placeholder="Naam" value={cName} onChange={(e) => setCName(e.target.value)} style={{ ...fld, flex: 1, minWidth: 120 }} />
          <input placeholder="Phone" value={cPhone} onChange={(e) => setCPhone(e.target.value)} style={{ ...fld, flex: 1, minWidth: 120 }} />
          <button type="button" onClick={addCustomer} style={{ background: COLORS.copper, color: "#fff", border: "none", borderRadius: 10, padding: "10px 18px", fontWeight: 800, cursor: "pointer" }}>+ Add</button>
        </div>
      </div>
      <PresetListEditor title="📝 Quick Notes" hint="Jaise: Kam teekha, Bina pyaaz — bill me tap karke notes me judega" placeholder="Note likho"
        items={presets.notes || []} onChange={(l) => savePresets({ ...presets, notes: l })} />
      <PresetListEditor title="🎁 Discount %" hint="Bill me ek tap se discount lagega" placeholder="Jaise 10" number suffix="%"
        items={presets.discounts || []} onChange={(l) => savePresets({ ...presets, discounts: l })} />
      <PresetListEditor title="🧾 GST %" hint="Khali chhodoge to 5 / 12 / 18 chalega" placeholder="Jaise 5" number suffix="%"
        items={presets.gstRates || []} onChange={(l) => savePresets({ ...presets, gstRates: l })} />
    </div>
  );
}

function DussehraRateEditor({ items, onSave, unavail = [], toggleAvail }) {
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState(items);
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [add, setAdd] = useState({ name: "", price: "", category: DUSSEHRA_CATEGORIES[0], portion: "" });
  useEffect(() => { if (!dirty) setDraft(items); }, [items, dirty]);

  const fld = { padding: "8px 10px", border: `1.5px solid ${COLORS.line}`, borderRadius: 8, fontSize: 14, boxSizing: "border-box", fontFamily: "inherit" };
  const edit = (id, patch) => { setDraft((d) => d.map((x) => (x.id === id ? { ...x, ...patch } : x))); setDirty(true); };
  const remove = (id) => { if (!window.confirm("Ye item hatana hai?")) return; setDraft((d) => d.filter((x) => x.id !== id)); setDirty(true); };
  const addItem = () => {
    const price = Number(add.price);
    if (!add.name.trim() || !Number.isFinite(price) || price <= 0) { alert("⚠️ Naam aur sahi rate daalo"); return; }
    setDraft((d) => [...d, mi(uid("dz"), add.name.trim(), price, add.category, true, "", add.portion.trim(), false, true, "")]);
    setAdd({ ...add, name: "", price: "", portion: "" });
    setDirty(true);
  };
  const save = async () => {
    if (draft.some((x) => !String(x.name || "").trim() || !Number.isFinite(Number(x.price)) || Number(x.price) <= 0)) { alert("⚠️ Har item ka naam aur sahi rate hona chahiye"); return; }
    setSaving(true);
    await onSave(draft.map((x) => ({ ...x, price: Number(x.price) })));
    setSaving(false); setDirty(false);
  };
  const reset = () => { if (window.confirm("Saare Dussehra rates PDF wale original par wapas karne hain?")) { setDraft(DUSSEHRA_MENU); setDirty(true); } };

  if (!open) {
    return (
      <button onClick={() => setOpen(true)} style={{ width: "100%", padding: 14, marginBottom: 20, background: "#E65100", color: "#fff", border: "none", borderRadius: 14, fontWeight: 800, fontSize: 15, cursor: "pointer" }}>
        ✏️ Dussehra Rates Edit karo
      </button>
    );
  }
  return (
    <div style={{ background: "#fff", border: "1.5px solid #E65100", borderRadius: 14, padding: 16, marginBottom: 20 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12, flexWrap: "wrap", gap: 8 }}>
        <div style={{ fontWeight: 800, fontSize: 16, color: "#E65100" }}>✏️ Dussehra Menu Rates</div>
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={reset} style={{ ...fld, background: "transparent", color: COLORS.textLight, fontWeight: 700, cursor: "pointer" }}>↩️ PDF wale par reset</button>
          <button onClick={() => setOpen(false)} style={{ ...fld, background: COLORS.paper2, fontWeight: 700, cursor: "pointer" }}>✕ Band</button>
        </div>
      </div>

      {DUSSEHRA_CATEGORIES.map((cat) => {
        const rows = draft.filter((x) => x.category === cat);
        if (rows.length === 0) return null;
        return (
          <div key={cat} style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 12, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.5, color: COLORS.textLight, marginBottom: 6 }}>{cat}</div>
            {rows.map((x) => (
              <div key={x.id} style={{ display: "flex", gap: 6, alignItems: "center", marginBottom: 6, opacity: unavail.includes(x.id) ? 0.55 : 1 }}>
                <input value={x.name} onChange={(e) => edit(x.id, { name: e.target.value })} style={{ ...fld, flex: 1, minWidth: 0 }} />
                {x.portion ? <span style={{ fontSize: 11, color: COLORS.textLight, fontWeight: 700, whiteSpace: "nowrap" }}>{x.portion}</span> : null}
                <input type="number" inputMode="decimal" value={x.price} onChange={(e) => edit(x.id, { price: e.target.value })} style={{ ...fld, width: 80, fontWeight: 800, textAlign: "center" }} />
                <button onClick={() => toggleAvail && toggleAvail(x.id)} title="Hai / Khatam" style={{ ...fld, padding: "8px 8px", cursor: "pointer", background: unavail.includes(x.id) ? COLORS.error : COLORS.sageLight, color: unavail.includes(x.id) ? "#fff" : COLORS.sageDark, fontWeight: 800, border: "none" }}>{unavail.includes(x.id) ? "❌" : "✅"}</button>
                <button onClick={() => remove(x.id)} style={{ ...fld, padding: "8px 8px", cursor: "pointer", background: "transparent", color: COLORS.error, border: `1.5px solid ${COLORS.error}`, fontWeight: 800 }}>✕</button>
              </div>
            ))}
          </div>
        );
      })}

      <div style={{ background: COLORS.paper, borderRadius: 10, padding: 10, marginBottom: 12 }}>
        <div style={{ fontSize: 12, fontWeight: 800, color: COLORS.textLight, marginBottom: 6 }}>➕ Naya item</div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          <input placeholder="Naam" value={add.name} onChange={(e) => setAdd({ ...add, name: e.target.value })} style={{ ...fld, flex: 2, minWidth: 140 }} />
          <input type="number" placeholder="Rate" value={add.price} onChange={(e) => setAdd({ ...add, price: e.target.value })} style={{ ...fld, width: 80 }} />
          <input placeholder="Half / Full" value={add.portion} onChange={(e) => setAdd({ ...add, portion: e.target.value })} style={{ ...fld, width: 90 }} />
          <select value={add.category} onChange={(e) => setAdd({ ...add, category: e.target.value })} style={{ ...fld, background: "#fff" }}>
            {DUSSEHRA_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
          <button onClick={addItem} style={{ ...fld, background: COLORS.sage, color: "#fff", border: "none", fontWeight: 800, cursor: "pointer" }}>+ Add</button>
        </div>
      </div>

      <button onClick={save} disabled={!dirty || saving} style={{ width: "100%", padding: 14, border: "none", borderRadius: 12, fontWeight: 800, fontSize: 15, cursor: dirty && !saving ? "pointer" : "not-allowed", background: dirty && !saving ? "#E65100" : COLORS.paper2, color: dirty && !saving ? "#fff" : COLORS.textLight }}>
        {saving ? "⏳ Saving..." : dirty ? "💾 Save Dussehra Menu" : "Koi badlav nahi"}
      </button>
    </div>
  );
}

function AdminView({ dussehraMenu = [], saveDussehraMenu, menu, unavail = [], toggleAvail, setMenuState, bookings, orders, markPaid, requestPinPrompt, inventory, addInventory, updateStock, deleteBooking, offersList, addOffer, removeOffer, loyaltyRules, setLoyaltyRules, loyaltyUsers, settings, setSettings, gallery, setGallery, categories, updateCategories, flashSaleItems, setFlashSaleItems, comboOffers, setComboOffers, savePromotions }) {
  const [tab, setTab] = useState("overview");
  const [filterDate, setFilterDate] = useState(toLocalISODate(Date.now()));
  const [newInv, setNewInv] = useState({ name: "", stock: "", unit: "kg" });
  const [newOffer, setNewOffer] = useState({ title: "", desc: "" });
  const [newReward, setNewReward] = useState({ cost: "", item: "" });
  const [editingItem, setEditingItem] = useState(null);
  const [newItemName, setNewItemName] = useState("");
  const [newItemPrice, setNewItemPrice] = useState("");
  const [newItemCat, setNewItemCat] = useState((categories && categories[0]) || CATEGORIES[0]);
  const [newItemImage, setNewItemImage] = useState("");
  const [addMenuName, setAddMenuName] = useState("");
  const [addMenuPrice, setAddMenuPrice] = useState("");
  const [addMenuCat, setAddMenuCat] = useState((categories && categories[0]) || CATEGORIES[0]);
  const [addMenuVeg, setAddMenuVeg] = useState(true);
  const [addMenuDesc, setAddMenuDesc] = useState("");
  const [addMenuImage, setAddMenuImage] = useState("");
  const [newGalleryImg, setNewGalleryImg] = useState("");
  const [heroImgInput, setHeroImgInput] = useState(settings?.heroImage || "");
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  const [newCategoryInput, setNewCategoryInput] = useState('');
  const [manageCat, setManageCat] = useState(null);
  const [manageSearch, setManageSearch] = useState("");
  const hiddenCats = settings?.hiddenCategories || [];
  // 🩹 ONE-SHOT MENU FIX — duplicates + naam + desc + photos (Wikipedia→Cloudinary)
  const [fixState, setFixState] = useState(null);
  const [fixReport, setFixReport] = useState(null);
  const [fixProgress, setFixProgress] = useState({ done: 0, total: 0, msg: "" });
  const CLOUD_NAME = "nnddxvcn";
  const UPLOAD_PRESET = "eatpark_uploads";
  const isOwnImage = (u) => /cloudinary\.com|pexels\.com/.test(u || "");
  const normalizeDishName = (s) => {
    let n = String(s || "").replace(/\s+/g, " ").trim();
    n = n.replace(/\bchilly\b/gi, "Chilli").replace(/\bchily\b/gi, "Chilli").replace(/\bchili\b/gi, "Chilli").replace(/\bmutter\b/gi, "Mutton");
    return n.split(" ").map(w => w ? w[0].toUpperCase() + w.slice(1).toLowerCase() : "").join(" ");
  };
  const normalizeDesc = (s, name) => {
    let d = String(s || "").replace(/\s+/g, " ").trim();
    if (!d || d.length < 6) return `${name || "Fresh dish"} — freshly prepared with quality ingredients.`;
    if (!/[.!?]$/.test(d)) d += ".";
    return d[0].toUpperCase() + d.slice(1);
  };
  const wikiImage = async (dishName) => {
    const clean = String(dishName || "").replace(/\(.*?\)/g, "").replace(/\b\d+\s*(pc|pcs|piece|pieces|kg|gm|ml|ltr|plate|eggs?)\b/gi, "").replace(/\b(half|full|quarter|regular|special|small|large|medium|dry|gravy|steam|fry|tandoori)\b/gi, "").replace(/\s+/g, " ").trim();
    if (!clean) return "";
    try {
      const url = `https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=${encodeURIComponent(clean + " food")}&gsrlimit=1&prop=pageimages&piprop=thumbnail|original&pithumbsize=600&format=json&origin=*`;
      const r = await fetch(url);
      if (!r.ok) return "";
      const d = await r.json();
      const first = Object.values(d?.query?.pages || {})[0];
      const img = first?.thumbnail?.source || first?.original?.source;
      if (img && /\.(jpe?g|png|webp)/i.test(img)) return img;
    } catch (e) {}
    return "";
  };
  const cloudinaryUpload = async (remoteUrl) => {
    try {
      const fd = new FormData();
      fd.append("file", remoteUrl);
      fd.append("upload_preset", UPLOAD_PRESET);
      fd.append("folder", "eatpark_auto");
      const r = await fetch(`https://api.cloudinary.com/v1_1/${CLOUD_NAME}/image/upload`, { method: "POST", body: fd });
      if (r.ok) { const d = await r.json(); if (d.secure_url) return d.secure_url; }
    } catch (e) {}
    try {
      const ir = await fetch(remoteUrl, { mode: "cors" });
      if (!ir.ok) return "";
      const blob = await ir.blob();
      const fd = new FormData();
      fd.append("file", blob, "auto.jpg");
      fd.append("upload_preset", UPLOAD_PRESET);
      fd.append("folder", "eatpark_auto");
      const r = await fetch(`https://api.cloudinary.com/v1_1/${CLOUD_NAME}/image/upload`, { method: "POST", body: fd });
      if (r.ok) { const d = await r.json(); return d.secure_url || ""; }
    } catch (e) {}
    return "";
  };
  const scanFix = () => {
    setFixState("scanning");
    try {
      const norm = (s) => String(s || "").toLowerCase().replace(/\s+/g, " ").trim();
      const richness = (m) => (isOwnImage(m.image) ? 20 : 0) + (m.image ? 5 : 0) + (m.desc ? 3 : 0) + (m.isBestseller ? 2 : 0) + ((m.alsoIn || []).length);
      const seen = {}, dupDeleteIds = new Set(), dupPairs = [];
      [...menu].sort((a, b) => richness(b) - richness(a)).forEach((m) => {
        const key = [norm(m.name), norm(m.portion), norm(m.category), Math.round(Number(m.price) || 0)].join("|");
        if (seen[key]) { dupDeleteIds.add(m.id); dupPairs.push({ keep: seen[key].name, del: m.name, price: m.price }); }
        else seen[key] = m;
      });
      const surviving = menu.filter(m => !dupDeleteIds.has(m.id));
      const nameFixes = [], descFixes = [];
      surviving.forEach(m => {
        const newName = normalizeDishName(m.name);
        if (newName && newName !== m.name) nameFixes.push({ id: m.id, from: m.name, to: newName });
        const newDesc = normalizeDesc(m.desc, newName || m.name);
        if (newDesc !== (m.desc || "")) descFixes.push({ id: m.id, from: m.desc || "(empty)", to: newDesc });
      });
      const imgTargets = surviving.filter(m => !isOwnImage(m.image)).map(m => ({ id: m.id, name: m.name, category: m.category }));
      setFixReport({ dupPairs, dupDeleteIds: [...dupDeleteIds], nameFixes, descFixes, imgTargets });
      setFixState("report");
    } catch (e) { alert("❌ Scan fail: " + e.message); setFixState(null); }
  };
  const applyFix = async () => {
    if (!fixReport) return;
    const { dupDeleteIds, nameFixes, descFixes, imgTargets } = fixReport;
    const totalSteps = dupDeleteIds.length + nameFixes.length + descFixes.length + imgTargets.length;
    if (!window.confirm(`Final fix:\n• ${dupDeleteIds.length} duplicates delete\n• ${nameFixes.length} naam fix\n• ${descFixes.length} description fix\n• ${imgTargets.length} photo fetch\n\nBackup pehle save hoga. Continue?`)) return;
    setFixState("applying");
    setFixProgress({ done: 0, total: totalSteps, msg: "Backup save..." });
    try {
      try { localStorage.setItem("menu_backup_" + Date.now(), JSON.stringify({ at: Date.now(), menu })); } catch (e) {}
      try { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([JSON.stringify({ at: Date.now(), menu }, null, 2)], { type: "application/json" })); a.download = `menu-backup-${Date.now()}.json`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 3000); } catch (e) {}
      const delSet = new Set(dupDeleteIds);
      const nameMap = Object.fromEntries(nameFixes.map(n => [n.id, n.to]));
      const descMap = Object.fromEntries(descFixes.map(n => [n.id, n.to]));
      let working = menu.filter(m => !delSet.has(m.id)).map(m => { let o = { ...m }; if (nameMap[m.id]) o.name = nameMap[m.id]; if (descMap[m.id]) o.desc = descMap[m.id]; return o; });
      let done = dupDeleteIds.length + nameFixes.length + descFixes.length;
      setFixProgress({ done, total: totalSteps, msg: "Photos fetch..." });
      for (let i = 0; i < imgTargets.length; i++) {
        const t = imgTargets[i];
        setFixProgress({ done: done + i, total: totalSteps, msg: `🖼️ ${i + 1}/${imgTargets.length}: ${t.name}` });
        try {
          const wikiUrl = await wikiImage(t.name);
          if (wikiUrl) { const cdnUrl = await cloudinaryUpload(wikiUrl); if (cdnUrl) working = working.map(m => m.id === t.id ? { ...m, image: cdnUrl } : m); }
        } catch (e) { console.warn("skip:", t.name); }
        await new Promise(r => setTimeout(r, 250));
      }
      setFixProgress({ done: totalSteps, total: totalSteps, msg: "Firestore save..." });
      await setDoc(doc(db, "settings", "menu"), { items: working });
      setMenuState(working);
      setFixState("done");
    } catch (e) { console.error(e); alert("❌ Apply fail: " + e.message); setFixState("report"); }
  };
  const closeFix = () => { setFixState(null); setFixReport(null); setFixProgress({ done: 0, total: 0, msg: "" }); };


  const saveAppSetting = async (patch) => {
    setSettings((prev) => ({ ...prev, ...patch }));
    try { await setDoc(doc(db, "settings", "appSettings"), patch, { merge: true }); }
    catch (e) { console.error(e); alert("⚠️ Save nahi hua. Internet check karo."); }
  };
  const toggleVegMode = () => saveAppSetting({ vegMode: !settings?.vegMode });
  const toggleCategory = (c) => saveAppSetting({
    hiddenCategories: hiddenCats.includes(c) ? hiddenCats.filter((x) => x !== c) : [...hiddenCats, c]
  });
  const toggleItemInCategory = async (itemId, cat) => {
    const updatedMenu = menu.map((m) => {
      if (m.id !== itemId || m.category === cat) return m;
      const also = m.alsoIn || [];
      return { ...m, alsoIn: also.includes(cat) ? also.filter((x) => x !== cat) : [...also, cat] };
    });
    setMenuState(updatedMenu);
    try { await setDoc(doc(db, "settings", "menu"), { items: updatedMenu }); }
    catch (e) { console.error(e); alert("⚠️ Menu save nahi hua. Internet check karo."); }
  };

  const [histOrders, setHistOrders] = useState([]);
  useEffect(() => {
    if (filterDate === toLocalISODate(Date.now())) { setHistOrders([]); return; }
    let off = false;
    const s = new Date(filterDate + "T00:00:00").getTime();
    getDocs(query(collection(db, "orders"), where("createdAt", ">=", s), where("createdAt", "<", s + 86400000)))
      .then((snap) => { if (!off) setHistOrders(snap.docs.map(normOrder)); })
      .catch((e) => console.error("history load:", e));
    return () => { off = true; };
  }, [filterDate]);
  const filteredOrders = useMemo(() => {
    const m = new Map();
    histOrders.forEach(o => m.set(o.id, o));
    orders.forEach(o => m.set(o.id, o));
    return Array.from(m.values()).filter(o => toLocalISODate(o.createdAt) === filterDate);
  }, [orders, histOrders, filterDate]);
  const revenue = filteredOrders.filter((o) => o.paid && o.status !== "cancelled").reduce((s, o) => s + getOrderTotal(o), 0);
  const _revenueOld = filteredOrders.filter((o) => o.paid).reduce((s, o) => s + o.items.reduce((a, it) => a + it.price * it.qty, 0) + (o.deliveryFee || 0) - (o.loyaltyDiscount || 0), 0);
  const avgOrderValue = (() => { const a = filteredOrders.filter(o => o.status !== "cancelled"); return a.length ? Math.round(a.reduce((s, o) => s + getOrderTotal(o), 0) / a.length) : 0; })();
  const _avgOld = filteredOrders.length > 0 ? Math.round(filteredOrders.reduce((s, o) => s + o.items.reduce((a, it) => a + it.price * it.qty, 0) - (o.loyaltyDiscount || 0), 0) / filteredOrders.length) : 0;

  const handleAddCategory = () => { if (!newCategoryInput.trim()) return; if (categories.some(c => c.toLowerCase() === newCategoryInput.trim().toLowerCase())) { alert("⚠️ Ye category pehle se hai"); return; } updateCategories([...categories, newCategoryInput.trim()]); setNewCategoryInput(''); };
  const handleMoveCategory = (index, direction) => { const ni = index + direction; if (ni < 0 || ni >= categories.length) return; const u = [...categories]; const [r] = u.splice(index, 1); u.splice(ni, 0, r); updateCategories(u); };
  const handleDeleteCategory = (index) => { if (menu.some(m => m.category === categories[index])) { alert("⚠️ Is category me items hain. Pehle unhe doosri category me daalo ya delete karo."); return; } if (window.confirm("Delete this category?")) { updateCategories(categories.filter((_, i) => i !== index)); } };

  const generatePDFReport = async () => {
    setIsGeneratingPDF(true);
    try {
      const loadScript = (src) => new Promise((resolve, reject) => { const s = document.createElement('script'); s.src = src; s.onload = resolve; s.onerror = reject; document.head.appendChild(s); });
      await loadScript('https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js');
      await loadScript('https://cdn.jsdelivr.net/npm/jspdf@2.5.1/dist/jspdf.umd.min.js');
      const html2canvas = window.html2canvas;
      const jsPDF = window.jspdf.jsPDF;
      const reportElement = document.getElementById('report-content');
      if (!reportElement) { alert('Report not found'); setIsGeneratingPDF(false); return; }
      const canvas = await html2canvas(reportElement, { scale: 2 });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgWidth = 210;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);
      pdf.save(`Sales_Report_${filterDate}.pdf`);
    } catch (e) { alert('⚠️ Could not generate PDF.'); } finally { setIsGeneratingPDF(false); }
  };

  const handleAddOffer = () => { if (newOffer.title) { addOffer({ id: uid("off"), title: newOffer.title, desc: newOffer.desc }); setNewOffer({ title: "", desc: "" }); } };
  const handleAddReward = () => { if (newReward.cost && newReward.item) { setLoyaltyRules({ ...loyaltyRules, rewards: [...loyaltyRules.rewards, { id: uid("rwd"), cost: Number(newReward.cost), item: newReward.item }] }); setNewReward({ cost: "", item: "" }); } };

  const handleSaveMenuItem = async () => {
    if (!editingItem) return;
    if (!String(newItemName).trim() || !(Number(newItemPrice) > 0)) { alert("⚠️ Naam aur sahi price daalo"); return; }
    const updatedMenu = menu.map(m => m.id === editingItem.id ? { ...m, name: newItemName, price: Number(newItemPrice), category: newItemCat, ...(newItemImage ? { image: newItemImage } : {}) } : m);
    setMenuState(updatedMenu);
    try { await setDoc(doc(db, "settings", "menu"), { items: updatedMenu }); } catch (e) { alert("⚠️ Failed to save"); }
    setEditingItem(null); setNewItemImage("");
  };
  const [autoImgMsg, setAutoImgMsg] = useState("");
  const autoImagesAll = async () => {
    if (autoImgMsg) return;
    const isOwn = (u) => /cloudinary\.com|pexels\.com/.test(u || "");
    const targets = menu.filter((m) => !isOwn(m.image));
    if (!targets.length) { alert("Sab items ki photo pehle se set hai"); return; }
    if (!window.confirm(targets.length + " items ki photo auto lagani hain? (Cloudinary / apni upload ki hui photo nahi badlegi)")) return;
    const cache = {};
    const found = {};
    let calls = 0;
    for (let i = 0; i < targets.length; i++) {
      const m = targets[i];
      const key = String(m.name || "").replace(/\(.*?\)/g, "").replace(/chilly/gi, "chilli").trim().toLowerCase();
      if (!(key in cache)) {
        if (calls >= 150) { alert("150 request ho gayi (Pexels limit 200/ghanta). Thodi der baad dobara dabao, baaki items ho jayenge."); break; }
        calls++;
        setAutoImgMsg("⏳ " + (i + 1) + "/" + targets.length + " — " + m.name);
        try { const r = await fetch("/api/image?q=" + encodeURIComponent(key)); const d = await r.json(); cache[key] = d.url || ""; } catch (e) { cache[key] = ""; }
        await new Promise((r) => setTimeout(r, 400));
      }
      if (cache[key]) found[m.id] = cache[key];
    }
    const n = Object.keys(found).length;
    if (n > 0) {
      const updated = menu.map((m) => (found[m.id] ? { ...m, image: found[m.id] } : m));
      setMenuState(updated);
      try { await setDoc(doc(db, "settings", "menu"), { items: updated }); alert("✅ " + n + " items ki photo lag gayi"); }
      catch (e) { alert("⚠️ Save nahi hua: " + e.message); }
    }
    setAutoImgMsg("");
  };
  const handleDeleteMenuItem = async (id) => { if (window.confirm("Delete this item?")) { const u = menu.filter(m => m.id !== id); setMenuState(u); try { await setDoc(doc(db, "settings", "menu"), { items: u }); } catch (e) { console.error(e); alert("⚠️ Menu save nahi hua. Internet check karo."); } } };
  const handleAddNewDish = async () => {
    if (!addMenuName.trim() || !addMenuPrice) { alert("Enter name and price"); return; }
    const newDish = mi(uid("m"), addMenuName.trim(), Number(addMenuPrice), addMenuCat, addMenuVeg, addMenuDesc.trim(), "", false, true, addMenuImage.trim());
    const u = [newDish, ...menu];
    setMenuState(u);
    try { await setDoc(doc(db, "settings", "menu"), { items: u }); } catch (e) { }
    setAddMenuName(""); setAddMenuPrice(""); setAddMenuDesc(""); setAddMenuImage("");
    alert("✅ Dish added!");
  };
  const handleAddGalleryPhoto = async () => { if (!newGalleryImg.trim()) return; const u = [...gallery, newGalleryImg.trim()]; setGallery(u); try { await setDoc(doc(db, "settings", "gallery"), { images: u }); } catch (e) { console.error(e); alert("⚠️ Gallery save nahi hui. Internet check karo."); } setNewGalleryImg(""); };
  const handleDeleteGalleryPhoto = async (index) => { const u = gallery.filter((_, i) => i !== index); setGallery(u); try { await setDoc(doc(db, "settings", "gallery"), { images: u }); } catch (e) { } };
  const handleSaveHeroImage = async () => { if (!heroImgInput.trim()) return; const n = { ...settings, heroImage: heroImgInput.trim() }; setSettings(n); try { await setDoc(doc(db, "settings", "appSettings"), { heroImage: heroImgInput.trim() }, { merge: true }); alert("✅ Saved!"); } catch (e) { alert("⚠️ Save nahi hua: " + e.message); } };
  const handleExportCSV = () => {
    const rows = [["Time", "Type", "Items", "Total", "Paid"]];
    filteredOrders.forEach(o => { const t = getOrderTotal(o); rows.push([new Date(o.createdAt).toLocaleTimeString('en-IN'), o.orderType === "parcel" ? "Parcel" : `Table ${o.table}`, o.items.map(it => `${it.qty}x ${it.name}`).join("; "), t, o.paid ? "Yes" : "No"]); });
    const csv = rows.map(r => r.map(c => `"${String(HX.csvCell(c)).replace(/"/g, '""')}"`).join(",")).join("\n");
    const link = document.createElement('a');
    link.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent("\uFEFF" + csv);
    link.download = `orders_${filterDate}.csv`; link.click();
  };

  const inputStyle = { padding: "12px 16px", border: `1.5px solid ${COLORS.line}`, borderRadius: 12, fontSize: 16, width: "100%", boxSizing: "border-box" };
  const primaryBtn = { background: COLORS.copper, color: "#fff", border: "none", borderRadius: 14, padding: "13px 20px", fontWeight: 700, fontSize: 14, cursor: "pointer" };
  const th = { padding: "12px 14px", borderBottom: `2px solid ${COLORS.line}` };
  const td = { padding: "12px 14px", borderBottom: `1px solid ${COLORS.line}` };

  return (
    <div style={{ padding: "26px 20px 60px", maxWidth: 1100, margin: "0 auto" }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 28, alignItems: 'center' }}>
        <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 32, fontWeight: 800 }}>📊 Admin Dashboard <ViewModeToggle /></div>
        <button onClick={() => requestPinPrompt("customer")} style={{ background: COLORS.paper2, border: "none", padding: "10px 20px", borderRadius: 12, cursor: "pointer", fontWeight: 700 }}>← Exit</button>
      </div>

      <div style={{ display: "flex", gap: 10, marginBottom: 28, borderBottom: `2px solid ${COLORS.line}`, overflowX: "auto" }}>
        {["overview", "menu", "tables", "presets", "gallery", "settings", "offers", "loyalty", "orders", "bookings", "promotions"].map((t) => (<button key={t} onClick={() => setTab(t)} style={{ background: "none", border: "none", padding: "14px 20px", fontWeight: 800, fontSize: 15, textTransform: "capitalize", color: tab === t ? COLORS.copper : COLORS.textLight, borderBottom: tab === t ? `3px solid ${COLORS.copper}` : "3px solid transparent", cursor: "pointer", whiteSpace: "nowrap" }}>{t}</button>))}
      </div>
      

      {tab === "tables" && (
        <TableStatusBoard
          orders={orders}
          tables={20}
          onTableClick={(o) => {
            setTab("orders");
          }}
          showStats={true}
        />
      )}

      {tab === "overview" && (
        <>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20, flexWrap: 'wrap' }}>
            <span style={{ fontWeight: 700 }}>📅 Date:</span>
            <input type="date" value={filterDate} onChange={(e) => setFilterDate(e.target.value)} style={{ ...inputStyle, width: 150 }} />
            <button onClick={handleExportCSV} style={{ background: COLORS.paper2, border: `1.5px solid ${COLORS.line}`, borderRadius: 10, padding: "10px 16px", cursor: "pointer", fontWeight: 700 }}>📊 CSV</button>
            <button onClick={generatePDFReport} disabled={isGeneratingPDF} style={{ background: COLORS.copper, color: "#fff", border: "none", borderRadius: 10, padding: "10px 16px", cursor: isGeneratingPDF ? 'not-allowed' : 'pointer', fontWeight: 700 }}>{isGeneratingPDF ? '⏳' : '📄 PDF'}</button>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 20, marginBottom: 28 }}>
            <StatCard label={`Orders`} value={filteredOrders.length} icon="📋" color={COLORS.copper} />
            <StatCard label="Revenue" value={inr(revenue)} icon="💰" color={COLORS.sage} />
            <StatCard label="Avg Order" value={inr(avgOrderValue)} icon="📈" color={COLORS.gold} />
          </div>
          <KitchenMetrics filteredOrders={filteredOrders} />
                   <div id="report-content" style={{ position: 'absolute', left: 0, top: 0, width: 700, background: '#fff', zIndex: -1, opacity: 0.01, pointerEvents: 'none' }}>
            <div style={{ padding: 20 }}>
              <h2>{RESTAURANT.name} - Report</h2>
              <p>Date: {filterDate}</p>
              <p>Orders: {filteredOrders.length}</p>
              <p>Revenue: {inr(revenue)}</p>
            </div>
          </div>
        </>
      )}

      {tab === "settings" && (
        <div style={{ background: COLORS.paper, padding: 24, borderRadius: 16 }}>
          <h3 style={{ marginTop: 0, marginBottom: 16 }}>🖼️ Hero Image / Wallpaper</h3>

          {/* 📸 Upload from device */}
          <div style={{ marginBottom: 16 }}>
            <ImageUploadButton
              currentImage={heroImgInput}
              onUploaded={async (url) => {
                setHeroImgInput(url);
                const newSettings = { ...settings, heroImage: url };
                setSettings(newSettings);
                try {
                  await setDoc(doc(db, "settings", "appSettings"), { heroImage: url }, { merge: true });
                  alert("✅ Wallpaper update ho gaya!");
                } catch (e) {
                  alert("⚠️ Save fail: " + e.message);
                }
              }}
              label="🖼️ Upload New Wallpaper (Phone / Camera)"
            />
          </div>

          <div style={{ fontSize: 12, color: COLORS.textLight, textAlign: 'center', marginBottom: 12 }}>
            ─── ya URL se change karo ───
          </div>

          {/* URL fallback */}
          <div style={{ display: "flex", gap: 12, marginBottom: 20 }}>
            <input
              type="url"
              placeholder="Image URL..."
              value={heroImgInput}
              onChange={(e) => setHeroImgInput(e.target.value)}
              style={{ ...inputStyle, flex: 2 }}
            />
            <button
              onClick={handleSaveHeroImage}
              style={{ ...primaryBtn, flex: 1 }}
            >
              Save
            </button>
          </div>

          {/* Preview */}
          {heroImgInput && (
            <img
              src={heroImgInput}
              alt=""
              style={{ width: "100%", maxHeight: 200, objectFit: "cover", borderRadius: 12 }}
              onError={(e) => {
                e.target.onerror = null;
                e.target.src = "https://images.unsplash.com/photo-1514933651103-005eec06c04b?auto=format&fit=crop&w=800&q=80";
              }}
            />
          )}

          {/* 🔐 SECURITY PINs */}
          <div style={{ display: "none", borderTop: `1px solid ${COLORS.line}`, marginTop: 28, paddingTop: 24 }}>
            <h3 style={{ marginTop: 0, marginBottom: 8 }}>🔐 Security PINs</h3>
            <div style={{ fontSize: 12, color: COLORS.textLight, marginBottom: 18 }}>
              Manage PINs for Waiter, Staff, and Admin access. Changes apply instantly.
            </div>

            {/* Waiter PIN */}
            <div style={{ background: '#fff', border: `1px solid ${COLORS.line}`, borderRadius: 12, padding: 16, marginBottom: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10, flexWrap: 'wrap', gap: 8 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ fontSize: 22 }}>🧑‍🍳</span>
                  <div>
                    <div style={{ fontWeight: 800, fontSize: 15 }}>Waiter PIN</div>
                    <div style={{ fontSize: 11, color: COLORS.textLight }}>Unlocks Waiter Mode on customer screen</div>
                  </div>
                </div>
                <span style={{ fontFamily: "'JetBrains Mono', monospace", background: COLORS.info, color: '#fff', padding: '4px 10px', borderRadius: 8, fontWeight: 800, fontSize: 13 }}>
                  {settings?.waiterPin || "1234"}
                </span>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <input type="text" inputMode="numeric" maxLength={6} value={settings?.waiterPin || "1234"}
                  onChange={e => setSettings({ ...settings, waiterPin: e.target.value.replace(/\D/g, '') })}
                  placeholder="4-6 digits"
                  style={{ ...inputStyle, flex: 1, textAlign: 'center', fontFamily: "'JetBrains Mono', monospace", fontSize: 18, letterSpacing: 4, fontWeight: 800 }} />
                <button onClick={async () => {
                  const pin = (settings?.waiterPin || "1234").toString();
                  if (pin.length < 4) { alert("⚠️ PIN must be at least 4 digits"); return; }
                  try { await setDoc(doc(db, "settings", "appSettings"), settings); alert("✅ Waiter PIN updated to: " + pin); }
                  catch (e) { alert("⚠️ Failed to save"); }
                }} style={{ ...primaryBtn, whiteSpace: 'nowrap' }}>💾 Save</button>
              </div>
            </div>

            {/* Staff PIN */}
            <div style={{ background: '#fff', border: `1px solid ${COLORS.line}`, borderRadius: 12, padding: 16, marginBottom: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10, flexWrap: 'wrap', gap: 8 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ fontSize: 22 }}>🍳</span>
                  <div>
                    <div style={{ fontWeight: 800, fontSize: 15 }}>Staff PIN</div>
                    <div style={{ fontSize: 11, color: COLORS.textLight }}>Unlocks Kitchen Board</div>
                  </div>
                </div>
                <span style={{ fontFamily: "'JetBrains Mono', monospace", background: COLORS.copper, color: '#fff', padding: '4px 10px', borderRadius: 8, fontWeight: 800, fontSize: 13 }}>
                  {settings?.staffPin || "5432"}
                </span>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <input type="text" inputMode="numeric" maxLength={6} value={settings?.staffPin || "5432"}
                  onChange={e => setSettings({ ...settings, staffPin: e.target.value.replace(/\D/g, '') })}
                  placeholder="4-6 digits"
                  style={{ ...inputStyle, flex: 1, textAlign: 'center', fontFamily: "'JetBrains Mono', monospace", fontSize: 18, letterSpacing: 4, fontWeight: 800 }} />
                <button onClick={async () => {
                  const pin = (settings?.staffPin || "5432").toString();
                  if (pin.length < 4) { alert("⚠️ PIN must be at least 4 digits"); return; }
                  try { await setDoc(doc(db, "settings", "appSettings"), settings); alert("✅ Staff PIN updated to: " + pin); }
                  catch (e) { alert("⚠️ Failed to save"); }
                }} style={{ ...primaryBtn, whiteSpace: 'nowrap' }}>💾 Save</button>
              </div>
            </div>

            {/* Admin PIN */}
            <div style={{ background: '#fff', border: `1px solid ${COLORS.line}`, borderRadius: 12, padding: 16, marginBottom: 20 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10, flexWrap: 'wrap', gap: 8 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ fontSize: 22 }}>⚙️</span>
                  <div>
                    <div style={{ fontWeight: 800, fontSize: 15 }}>Admin PIN</div>
                    <div style={{ fontSize: 11, color: COLORS.textLight }}>Unlocks Admin Dashboard (highest access)</div>
                  </div>
                </div>
                <span style={{ fontFamily: "'JetBrains Mono', monospace", background: COLORS.ink, color: '#fff', padding: '4px 10px', borderRadius: 8, fontWeight: 800, fontSize: 13 }}>
                  {settings?.adminPin || "9876"}
                </span>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <input type="text" inputMode="numeric" maxLength={6} value={settings?.adminPin || "9876"}
                  onChange={e => setSettings({ ...settings, adminPin: e.target.value.replace(/\D/g, '') })}
                  placeholder="4-6 digits"
                  style={{ ...inputStyle, flex: 1, textAlign: 'center', fontFamily: "'JetBrains Mono', monospace", fontSize: 18, letterSpacing: 4, fontWeight: 800 }} />
                <button onClick={async () => {
                  const pin = (settings?.adminPin || "9876").toString();
                  if (pin.length < 4) { alert("⚠️ PIN must be at least 4 digits"); return; }
                  try { await setDoc(doc(db, "settings", "appSettings"), settings); alert("✅ Admin PIN updated to: " + pin); }
                  catch (e) { alert("⚠️ Failed to save"); }
                }} style={{ ...primaryBtn, whiteSpace: 'nowrap' }}>💾 Save</button>
              </div>
            </div>

            {/* Reset All PINs */}
            <div style={{ background: 'rgba(239, 68, 68, 0.06)', border: `1.5px dashed ${COLORS.error}`, borderRadius: 12, padding: 16 }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12, marginBottom: 12 }}>
                <span style={{ fontSize: 26 }}>⚠️</span>
                <div>
                  <div style={{ fontWeight: 800, fontSize: 15, color: COLORS.error }}>Reset All PINs</div>
                  <div style={{ fontSize: 12, color: COLORS.textLight, marginTop: 2, lineHeight: 1.5 }}>
                    Restores all PINs to factory defaults.
                  </div>
                </div>
              </div>
              <button
                onClick={async () => {
                  if (!window.confirm("⚠️ Reset ALL PINs to defaults?\n\nWaiter: 1234\nStaff: 5432\nAdmin: 9876")) return;
                  const resetSettings = { ...settings, waiterPin: "1234", staffPin: "5432", adminPin: "9876" };
                  setSettings(resetSettings);
                  try {
                    await setDoc(doc(db, "settings", "appSettings"), resetSettings);
                    alert("✅ All PINs reset!");
                  } catch (e) {
                    alert("⚠️ Failed to reset.");
                  }
                }}
                style={{
                  width: '100%', padding: 14, border: 'none', borderRadius: 12,
                  background: COLORS.error, color: '#fff', fontWeight: 800,
                  fontSize: 14, cursor: 'pointer'
                }}>
                🔄 Reset All PINs
              </button>
            </div>
          </div>
        </div>
      )}
                  {tab === "presets" && <PresetsAdmin />}

      {tab === "gallery" && (
        <>
          <div style={{ background: COLORS.paper, padding: 24, borderRadius: 16, marginBottom: 30 }}>
            <h3 style={{ marginTop: 0, marginBottom: 16 }}>📸 Add Photo</h3>
            
            {/* 📸 Upload from device */}
            <div style={{ marginBottom: 16 }}>
              <ImageUploadButton
                currentImage={newGalleryImg}
                onUploaded={(url) => {
                  setNewGalleryImg(url);
                  // Auto-add to gallery
                  setTimeout(() => {
                    const u = [...gallery, url];
                    setGallery(u);
                    setDoc(doc(db, "settings", "gallery"), { images: u }).catch(console.error);
                    setNewGalleryImg("");
                    alert("✅ Photo gallery mein add ho gayi!");
                  }, 100);
                }}
                label="📸 Upload Photo (Phone / Camera / Gallery)"
              />
            </div>

            <div style={{ fontSize: 12, color: COLORS.textLight, textAlign: 'center', marginBottom: 12 }}>
              ─── ya URL se add karo ───
            </div>

            {/* URL fallback */}
            <div style={{ display: "flex", gap: 12 }}>
              <input type="url" placeholder="Image URL..." value={newGalleryImg} onChange={e => setNewGalleryImg(e.target.value)} style={{ ...inputStyle, flex: 2 }} />
              <button onClick={handleAddGalleryPhoto} style={{ ...primaryBtn, flex: 1 }}>+ Add</button>
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 16 }}>
            {gallery.map((imgUrl, idx) => (
              <div key={idx} style={{ background: '#fff', border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: 10 }}>
                <img src={imgUrl} alt="" style={{ width: "100%", height: 120, objectFit: "cover", borderRadius: 10, marginBottom: 10 }} onError={(e) => { e.target.onerror = null; e.target.src = "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=400&q=80"; }} />
                <button onClick={() => handleDeleteGalleryPhoto(idx)} style={{ width: "100%", background: 'transparent', border: `1px solid ${COLORS.rust}`, color: COLORS.rust, padding: '6px 0', borderRadius: 8, fontWeight: 700, cursor: 'pointer' }}>Delete</button>
              </div>
            ))}
          </div>
        </>
      )}

      {tab === "menu" && (

        <>
          {/* 🩹 SAB THIK KARO */}
          <div style={{ background: "#ECFDF5", border: "2px solid #10B981", borderRadius: 14, padding: 18, marginBottom: 20 }}>
            <div style={{ fontWeight: 900, fontSize: 18, color: "#065F46", marginBottom: 4 }}>🩹 SAB THIK KARO (One-Click)</div>
            <div style={{ fontSize: 12, color: "#047857", marginBottom: 14, lineHeight: 1.6 }}>Duplicates delete · Naam sahi · Description saaf · Photo Wikipedia se free (Cloudinary me save). Backup automatic.</div>
            {!fixState && <button onClick={scanFix} style={{ background: "#10B981", color: "#fff", border: "none", borderRadius: 12, padding: "14px 24px", fontWeight: 900, fontSize: 15, cursor: "pointer", width: "100%" }}>🔍 Pehle Scan Karo (dry-run)</button>}
            {fixState === "scanning" && <div style={{ padding: 12, textAlign: "center", color: "#065F46", fontWeight: 700 }}>⏳ Menu scan ho raha hai...</div>}
            {fixState === "report" && fixReport && (
              <div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 10, marginBottom: 14 }}>
                  {[{ l: "Duplicates", v: fixReport.dupDeleteIds.length, c: "#DC2626", bg: "#FEF2F2" }, { l: "Naam Fix", v: fixReport.nameFixes.length, c: "#2563EB", bg: "#EFF6FF" }, { l: "Description", v: fixReport.descFixes.length, c: "#7C3AED", bg: "#F5F3FF" }, { l: "Photos", v: fixReport.imgTargets.length, c: "#EA580C", bg: "#FFF7ED" }].map((s) => (
                    <div key={s.l} style={{ background: s.bg, border: `1px solid ${s.c}44`, borderRadius: 10, padding: 12 }}>
                      <div style={{ fontSize: 10, fontWeight: 800, color: s.c, textTransform: "uppercase" }}>{s.l}</div>
                      <div style={{ fontSize: 22, fontWeight: 900, color: s.c }}>{s.v}</div>
                    </div>
                  ))}
                </div>
                {fixReport.dupPairs.length > 0 && (
                  <details style={{ marginBottom: 10 }}>
                    <summary style={{ cursor: "pointer", fontSize: 12, fontWeight: 800, color: "#DC2626", padding: "6px 0" }}>🔍 Duplicates ({fixReport.dupPairs.length})</summary>
                    <div style={{ maxHeight: 150, overflowY: "auto", fontSize: 11, background: "#FFF", padding: 10, borderRadius: 8, marginTop: 6 }}>
                      {fixReport.dupPairs.map((d, i) => (<div key={i} style={{ padding: 4, borderBottom: "1px solid #FEE2E2" }}><span style={{ color: "#16A34A" }}>✓ Rakhenge: {d.keep}</span><br /><span style={{ color: "#DC2626" }}>✗ Delete: {d.del} (₹{d.price})</span></div>))}
                    </div>
                  </details>
                )}
                {fixReport.nameFixes.length > 0 && (
                  <details style={{ marginBottom: 10 }}>
                    <summary style={{ cursor: "pointer", fontSize: 12, fontWeight: 800, color: "#2563EB", padding: "6px 0" }}>✏️ Naam fixes ({fixReport.nameFixes.length})</summary>
                    <div style={{ maxHeight: 150, overflowY: "auto", fontSize: 11, background: "#FFF", padding: 10, borderRadius: 8, marginTop: 6 }}>
                      {fixReport.nameFixes.map((n, i) => (<div key={i} style={{ padding: 3, borderBottom: "1px solid #DBEAFE" }}><span style={{ color: "#DC2626" }}>{n.from}</span> → <span style={{ color: "#16A34A" }}>{n.to}</span></div>))}
                    </div>
                  </details>
                )}
                {fixReport.imgTargets.length > 0 && (
                  <details style={{ marginBottom: 10 }}>
                    <summary style={{ cursor: "pointer", fontSize: 12, fontWeight: 800, color: "#EA580C", padding: "6px 0" }}>🖼️ Photos milengi ({fixReport.imgTargets.length})</summary>
                    <div style={{ maxHeight: 150, overflowY: "auto", fontSize: 11, background: "#FFF", padding: 10, borderRadius: 8, marginTop: 6 }}>
                      {fixReport.imgTargets.map((t, i) => (<div key={i} style={{ padding: 3, borderBottom: "1px solid #FFEDD5" }}>{t.name} <span style={{ color: "#9A3412" }}>({t.category})</span></div>))}
                    </div>
                  </details>
                )}
                <div style={{ display: "flex", gap: 8 }}>
                  <button onClick={applyFix} style={{ flex: 2, background: "#16A34A", color: "#fff", border: "none", borderRadius: 10, padding: 14, fontWeight: 900, fontSize: 14, cursor: "pointer" }}>✅ SAB APPLY KARO</button>
                  <button onClick={closeFix} style={{ flex: 1, background: "transparent", color: "#6B7280", border: "1px solid #D1D5DB", borderRadius: 10, padding: 14, fontWeight: 700, cursor: "pointer" }}>Cancel</button>
                </div>
              </div>
            )}
            {fixState === "applying" && (<div><div style={{ height: 10, background: "#D1FAE5", borderRadius: 5, overflow: "hidden", marginBottom: 8 }}><div style={{ height: "100%", width: `${fixProgress.total ? (fixProgress.done / fixProgress.total) * 100 : 0}%`, background: "#10B981", transition: "width 0.3s" }} /></div><div style={{ fontSize: 12, fontWeight: 700, color: "#065F46" }}>{fixProgress.msg} ({fixProgress.done}/{fixProgress.total})</div></div>)}
            {fixState === "done" && (<div style={{ textAlign: "center", padding: 16 }}><div style={{ fontSize: 40, marginBottom: 8 }}>🎉</div><div style={{ fontSize: 16, fontWeight: 900, color: "#065F46", marginBottom: 6 }}>Sab theek ho gaya!</div><div style={{ fontSize: 12, color: "#047857", marginBottom: 12 }}>Backup localStorage + JSON file me safe hai.</div><button onClick={closeFix} style={{ background: "#10B981", color: "#fff", border: "none", borderRadius: 10, padding: "10px 24px", fontWeight: 800, cursor: "pointer" }}>OK</button></div>)}
          </div>
          <div style={{ background: COLORS.paper, padding: 24, borderRadius: 16, marginBottom: 30 }}>
            {DUSSEHRA_ENABLED && (<div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, background: settings?.menuMode === 'dussehra' ? '#FFF3E0' : COLORS.paper2, border: `1.5px solid ${settings?.menuMode === 'dussehra' ? '#E65100' : COLORS.line}`, borderRadius: 14, padding: '14px 16px', marginBottom: 20 }}>
              <div>
                <div style={{ fontWeight: 800, fontSize: 16, color: settings?.menuMode === 'dussehra' ? '#E65100' : COLORS.ink }}>
                  🎉 Menu Mode: {settings?.menuMode === 'dussehra' ? 'Dussehra Special' : 'Normal Menu'}
                </div>
                <div style={{ fontSize: 12, color: COLORS.textLight, marginTop: 2 }}>Sabko turant active menu dikhega. Normal menu kabhi overwrite nahi hota.</div>
              </div>
              <button onClick={() => saveAppSetting({ menuMode: settings?.menuMode === 'dussehra' ? 'normal' : 'dussehra' })} style={{ background: settings?.menuMode === 'dussehra' ? '#E65100' : COLORS.ink, color: '#fff', border: 'none', borderRadius: 20, padding: '10px 20px', fontWeight: 800, cursor: 'pointer', whiteSpace: 'nowrap' }}>
                Switch to {settings?.menuMode === 'dussehra' ? 'Normal' : 'Dussehra'}
              </button>
            </div>)}
            <button onClick={async () => {
              const have = new Set(menu.map((m) => m.id));
              const missing = DEFAULT_MENU.filter((d) => !have.has(d.id));
              if (!missing.length) { alert("Kuch missing nahi hai."); return; }
              if (!window.confirm(missing.length + " purane items wapas jodne hain? Abhi ke " + menu.length + " items waise hi rahenge.")) return;
              try { const blob = new Blob([JSON.stringify(menu, null, 2)], { type: "application/json" }); const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "menu-backup-" + Date.now() + ".json"; a.click(); } catch (e) { console.error(e); }
              const merged = [...menu, ...missing];
              try { await setDoc(doc(db, "settings", "menu"), { items: merged }); setMenuState(merged); alert("✅ " + missing.length + " items wapas aa gaye. Total: " + merged.length); }
              catch (e) { console.error(e); alert("⚠️ Save nahi hua: " + e.message); }
            }} style={{ width: '100%', background: '#2E7D32', color: '#fff', border: 'none', borderRadius: 12, padding: '14px 16px', fontWeight: 800, cursor: 'pointer', marginBottom: 16 }}>♻️ Purane items wapas jodo</button>
            <button onClick={autoImagesAll} disabled={!!autoImgMsg} style={{ width: '100%', background: COLORS.info, color: '#fff', border: 'none', borderRadius: 12, padding: '14px 16px', fontWeight: 800, cursor: autoImgMsg ? 'wait' : 'pointer', marginBottom: 16 }}>{autoImgMsg || "🖼️ Auto image lagao (sabhi items)"}</button>
            {DUSSEHRA_ENABLED && (<DussehraRateEditor items={dussehraMenu} onSave={saveDussehraMenu} unavail={unavail} toggleAvail={toggleAvail} />)}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, background: settings?.vegMode ? COLORS.sageLight : '#fff', border: `1.5px solid ${settings?.vegMode ? COLORS.sage : COLORS.line}`, borderRadius: 14, padding: '14px 16px', marginBottom: 20 }}>
              <div>
                <div style={{ fontWeight: 800, fontSize: 16 }}>🟢 Veg Mode</div>
                <div style={{ fontSize: 12, color: COLORS.textLight, marginTop: 2 }}>ON karne par customers ko sirf Veg items dikhenge (Staff / Waiter ko poora menu)</div>
              </div>
              <button onClick={toggleVegMode} style={{ background: settings?.vegMode ? COLORS.sage : COLORS.paper2, color: settings?.vegMode ? '#fff' : COLORS.ink, border: 'none', borderRadius: 20, padding: '10px 20px', fontWeight: 800, cursor: 'pointer', whiteSpace: 'nowrap' }}>
                {settings?.vegMode ? '✅ ON' : '⚪ OFF'}
              </button>
            </div>
            <h3 style={{ marginTop: 0, marginBottom: 16 }}>📂 Categories</h3>
            <div style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
              <input type="text" placeholder="New category name" value={newCategoryInput} onChange={(e) => setNewCategoryInput(e.target.value)} style={inputStyle} />
              <button onClick={handleAddCategory} style={{ ...primaryBtn, whiteSpace: 'nowrap' }}>+ Add</button>
            </div>
            {categories.map((cat, index) => (
              <div key={cat} style={{ display: 'flex', justifyContent: 'space-between', background: '#fff', padding: '10px 16px', borderRadius: 10, marginBottom: 6 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                  <span style={{ fontWeight: 700, opacity: hiddenCats.includes(cat) ? 0.5 : 1 }}>{index + 1}. {cat}</span>
                  <button onClick={() => toggleCategory(cat)} style={{ padding: '4px 10px', borderRadius: 8, border: 'none', fontWeight: 800, fontSize: 12, cursor: 'pointer', background: hiddenCats.includes(cat) ? COLORS.error : COLORS.sage, color: '#fff' }}>
                    {hiddenCats.includes(cat) ? '❌ OFF' : '✅ ON'}
                  </button>
                  <button onClick={() => { setManageCat(cat); setManageSearch(""); }} style={{ padding: '4px 10px', borderRadius: 8, border: `1.5px solid ${COLORS.info}`, background: 'transparent', color: COLORS.info, fontWeight: 800, fontSize: 12, cursor: 'pointer' }}>
                    📋 Items ({menu.filter((m) => m.category === cat || (m.alsoIn || []).includes(cat)).length})
                  </button>
                </div>
                <div style={{ display: 'flex', gap: 6 }}>
                  <button onClick={() => handleMoveCategory(index, -1)} disabled={index === 0} style={{ padding: '4px 10px', opacity: index === 0 ? 0.4 : 1 }}>⬆️</button>
                  <button onClick={() => handleMoveCategory(index, 1)} disabled={index === categories.length - 1} style={{ padding: '4px 10px', opacity: index === categories.length - 1 ? 0.4 : 1 }}>⬇️</button>
                  <button onClick={() => handleDeleteCategory(index)} style={{ padding: '4px 10px', color: COLORS.error, background: 'transparent', border: `1.5px solid ${COLORS.error}`, borderRadius: 6, fontWeight: 700 }}>✕</button>
                </div>
              </div>
            ))}
          </div>

          <div style={{ background: COLORS.paper, padding: 24, borderRadius: 16, marginBottom: 30 }}>
            <h3 style={{ marginTop: 0, marginBottom: 16 }}>➕ Add Dish</h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 12, marginBottom: 12 }}>
              <input type="text" placeholder="Dish Name *" value={addMenuName} onChange={e => setAddMenuName(e.target.value)} style={inputStyle} />
              <input type="number" placeholder="Price *" value={addMenuPrice} onChange={e => setAddMenuPrice(e.target.value)} style={inputStyle} />
              <select value={addMenuCat} onChange={e => setAddMenuCat(e.target.value)} style={inputStyle}>{categories.map(c => <option key={c} value={c}>{c}</option>)}</select>
              <select value={addMenuVeg} onChange={e => setAddMenuVeg(e.target.value === 'true')} style={inputStyle}><option value="true">🟢 Veg</option><option value="false">🔴 Non-Veg</option></select>
            </div>
            <input type="url" placeholder="Image URL (optional)" value={addMenuImage} onChange={e => setAddMenuImage(e.target.value)} style={{ ...inputStyle, marginBottom: 12 }} />
            <textarea placeholder="Description" value={addMenuDesc} onChange={e => setAddMenuDesc(e.target.value)} style={{ ...inputStyle, marginBottom: 16, resize: 'none' }} rows={2} />
            <button onClick={handleAddNewDish} style={primaryBtn}>+ Add Dish</button>
          </div>

          <h3 style={{ marginBottom: 16 }}>Existing Menu</h3>
          {menu.map(item => (
            <div key={item.id} style={{ background: '#fff', border: `1px solid ${COLORS.line}`, padding: 16, borderRadius: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, marginBottom: 12 }}>
              <img src={item.image} alt="" style={{ width: 50, height: 50, objectFit: 'cover', borderRadius: 10 }} onError={(e) => { e.target.onerror = null; e.target.src = "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=400&q=80"; }} />
              <div style={{ flex: 1 }}><div style={{ fontWeight: 800, fontSize: 16 }}>{item.name} <span style={{ fontSize: 12, color: COLORS.textLight }}>({item.category})</span></div><div style={{ color: COLORS.copper, fontWeight: 800 }}>{inr(item.price)}</div></div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={() => { setEditingItem(item); setNewItemName(item.name); setNewItemPrice(item.price); setNewItemCat(item.category); setNewItemImage(item.image); }} style={{ background: COLORS.paper2, border: 'none', padding: '8px 14px', borderRadius: 8, fontWeight: 700, cursor: 'pointer' }}>Edit</button>
                <button onClick={() => toggleAvail && toggleAvail(item.id)} style={{ background: unavail.includes(item.id) ? COLORS.error : COLORS.sageLight, color: unavail.includes(item.id) ? '#fff' : COLORS.sageDark, border: 'none', padding: '8px 14px', borderRadius: 8, fontWeight: 800, cursor: 'pointer' }}>{unavail.includes(item.id) ? '❌ Khatam' : '✅ Hai'}</button>
                <button onClick={() => handleDeleteMenuItem(item.id)} style={{ background: 'transparent', border: `1px solid ${COLORS.rust}`, color: COLORS.rust, padding: '8px 14px', borderRadius: 8, fontWeight: 700, cursor: 'pointer' }}>Delete</button>
              </div>
            </div>
          ))}

          {manageCat && (
            <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 99 }} onClick={() => setManageCat(null)}>
              <div onClick={(e) => e.stopPropagation()} style={{ background: '#fff', padding: 20, borderRadius: 20, width: '92%', maxWidth: 480, maxHeight: '85vh', display: 'flex', flexDirection: 'column' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                  <h3 style={{ margin: 0 }}>📋 {manageCat}</h3>
                  <button onClick={() => setManageCat(null)} style={{ background: 'rgba(0,0,0,0.05)', border: 'none', borderRadius: '50%', width: 32, height: 32, cursor: 'pointer', fontSize: 16 }}>✕</button>
                </div>
                <div style={{ fontSize: 12, color: COLORS.textLight, marginBottom: 10 }}>Tick karo = item is category me bhi dikhega (original category me bhi rahega)</div>
                <input placeholder="🔍 Menu me search..." value={manageSearch} onChange={(e) => setManageSearch(e.target.value)} style={{ ...inputStyle, marginBottom: 10, padding: '10px 14px', fontSize: 14 }} />
                <div style={{ overflowY: 'auto', flex: 1, border: `1px solid ${COLORS.line}`, borderRadius: 12 }}>
                  {menu
                    .filter((m) => !manageSearch.trim() || m.name.toLowerCase().includes(manageSearch.toLowerCase()))
                    .map((m) => {
                      const own = m.category === manageCat;
                      const checked = own || (m.alsoIn || []).includes(manageCat);
                      return (
                        <label key={m.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', borderBottom: `1px solid ${COLORS.line}`, cursor: own ? 'default' : 'pointer', opacity: own ? 0.6 : 1 }}>
                          <input type="checkbox" checked={checked} disabled={own} onChange={() => toggleItemInCategory(m.id, manageCat)} style={{ width: 18, height: 18 }} />
                          <VegDot veg={m.veg} />
                          <div style={{ flex: 1, minWidth: 0 }}>
                            <div style={{ fontSize: 14, fontWeight: 700 }}>{m.name}{m.portion ? ` (${m.portion})` : ""}</div>
                            <div style={{ fontSize: 11, color: COLORS.textLight }}>{m.category} · ₹{m.price}{own ? " · yahi original category" : ""}</div>
                          </div>
                        </label>
                      );
                    })}
                </div>
                <button onClick={() => setManageCat(null)} style={{ ...primaryBtn, marginTop: 12, width: '100%' }}>✓ Done</button>
              </div>
            </div>
          )}

          {editingItem && (
            <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 99 }}>
              <div style={{ background: '#fff', padding: 24, borderRadius: 20, width: '90%', maxWidth: 400 }}>
                <h3 style={{ marginTop: 0 }}>Edit Item</h3>
                <input type="text" value={newItemName} onChange={e => setNewItemName(e.target.value)} style={{ ...inputStyle, marginBottom: 12 }} />
                <input type="number" value={newItemPrice} onChange={e => setNewItemPrice(e.target.value)} style={{ ...inputStyle, marginBottom: 12 }} />
                <select value={newItemCat} onChange={e => setNewItemCat(e.target.value)} style={{ ...inputStyle, marginBottom: 12 }}>{categories.map(c => <option key={c} value={c}>{c}</option>)}</select>
<div style={{ marginBottom: 20 }}>
  <ImageUploadButton 
    currentImage={newItemImage} 
    onUploaded={setNewItemImage}
    label="📸 Upload New Photo"
  />
</div>                <div style={{ display: 'flex', gap: 12 }}>
                  <button onClick={() => setEditingItem(null)} style={{ flex: 1, padding: 12, border: `1px solid ${COLORS.line}`, background: 'transparent', borderRadius: 10, fontWeight: 700, cursor: 'pointer' }}>Cancel</button>
                  <button onClick={handleSaveMenuItem} style={{ flex: 1, padding: 12, background: COLORS.copper, color: '#fff', border: 'none', borderRadius: 10, fontWeight: 800, cursor: 'pointer' }}>Save</button>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {tab === "loyalty" && (
        <>
          <div style={{ background: 'linear-gradient(135deg, #fdfbfb, #ebedee)', padding: 24, borderRadius: 16, marginBottom: 24, border: `1.5px solid ${COLORS.gold}` }}>
            <div style={{ fontSize: 20, marginBottom: 16, fontWeight: 800 }}>🪙 EatCoin Settings</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20 }}>
              <span style={{ fontWeight: 700 }}>₹ Spend = 1 Coin :</span>
              <input type="number" value={loyaltyRules.rate} onChange={(e) => setLoyaltyRules({ ...loyaltyRules, rate: Number(e.target.value) })} style={{ ...inputStyle, width: 120 }} />
            </div>
            <div style={{ fontWeight: 700, marginBottom: 12 }}>Add Reward</div>
            <div style={{ display: 'flex', gap: 12 }}>
              <input type="number" placeholder="Cost" value={newReward.cost} onChange={e => setNewReward({ ...newReward, cost: e.target.value })} style={{ ...inputStyle, flex: 1 }} />
              <input type="text" placeholder="Free item" value={newReward.item} onChange={e => setNewReward({ ...newReward, item: e.target.value })} style={{ ...inputStyle, flex: 2 }} />
              <button onClick={handleAddReward} style={{ ...primaryBtn, background: COLORS.gold, color: COLORS.ink }}>+ Add</button>
            </div>
          </div>
          {loyaltyRules.rewards.map(r => (
            <div key={r.id} style={{ background: '#fff', border: `1px solid ${COLORS.line}`, padding: 20, borderRadius: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <div><div style={{ fontWeight: 800, fontSize: 18 }}>{r.item}</div><div style={{ color: COLORS.gold, fontWeight: 800 }}>{r.cost} Coins</div></div>
              <button onClick={() => setLoyaltyRules({ ...loyaltyRules, rewards: loyaltyRules.rewards.filter(rw => rw.id !== r.id) })} style={{ background: 'transparent', border: `1.5px solid ${COLORS.rust}`, color: COLORS.rust, padding: '8px 16px', borderRadius: 10, cursor: 'pointer', fontWeight: 800 }}>Remove</button>
            </div>
          ))}
          <h3 style={{ marginTop: 40 }}>Top Customers</h3>
          <table style={{ width: "100%", borderCollapse: "collapse", background: "#fff", borderRadius: 12, overflow: 'hidden' }}>
            <thead><tr style={{ background: COLORS.paper }}><th style={th}>Name</th><th style={th}>Phone</th><th style={th}>Coins</th><th style={th}>Tier</th></tr></thead>
            <tbody>{[...loyaltyUsers].sort((a, b) => b.coins - a.coins).map((u, i) => (<tr key={i}><td style={td}>{u.name}</td><td style={td}>{u.phone}</td><td style={{ ...td, fontWeight: 800, color: COLORS.sageDark }}>{u.coins}</td><td style={td}>{getLoyaltyTier(u.coins).name}</td></tr>))}</tbody>
          </table>
        </>
      )}

      {tab === "offers" && (
        <>
          <div style={{ background: COLORS.paper, padding: 24, borderRadius: 16, marginBottom: 24 }}>
            <div style={{ fontSize: 20, marginBottom: 16, fontWeight: 700 }}>Create Offer</div>
            <div style={{ display: 'flex', gap: 12 }}>
              <input type="text" placeholder="Title" value={newOffer.title} onChange={e => setNewOffer({ ...newOffer, title: e.target.value })} style={{ ...inputStyle, flex: 1 }} />
              <input type="text" placeholder="Description" value={newOffer.desc} onChange={e => setNewOffer({ ...newOffer, desc: e.target.value })} style={{ ...inputStyle, flex: 2 }} />
              <button onClick={handleAddOffer} style={primaryBtn}>+ Add</button>
            </div>
          </div>
          {offersList.map((off) => (
            <div key={off.id} style={{ background: '#fff', border: `1px solid ${COLORS.line}`, padding: 20, borderRadius: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <div><div style={{ fontWeight: 800, fontSize: 18 }}>{off.title}</div><div style={{ color: COLORS.textLight, fontWeight: 600 }}>{off.desc}</div></div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={() => { const nt = prompt("Title:", off.title); if (nt !== null) { const nd = prompt("Desc:", off.desc); if (nd !== null) { addOffer({ ...off, title: nt.trim(), desc: nd.trim() }); } } }} style={{ background: COLORS.copperLight, border: `1.5px solid ${COLORS.copper}`, color: COLORS.copperDark, padding: '8px 16px', borderRadius: 10, cursor: 'pointer', fontWeight: 700 }}>✏️</button>
                <button onClick={() => removeOffer(off.id)} style={{ background: 'transparent', border: `1.5px solid ${COLORS.rust}`, color: COLORS.rust, padding: '8px 16px', borderRadius: 10, cursor: 'pointer', fontWeight: 800 }}>Delete</button>
              </div>
            </div>
          ))}
        </>
      )}

      

      {tab === "orders" && (
        <div style={{ overflowX: "auto", borderRadius: 16, border: `1px solid ${COLORS.line}` }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14, background: "#fff" }}>
            <thead><tr style={{ textAlign: "left", background: COLORS.paper }}><th style={th}>Time</th><th style={th}>Table</th><th style={th}>Items</th><th style={th}>Total</th><th style={th}>Payment</th><th style={th}>Action</th></tr></thead>
            <tbody>
              {[...filteredOrders].sort((a, b) => b.createdAt - a.createdAt).map((o) => (
                <tr key={o.id} style={{ opacity: o.status === "cancelled" ? 0.5 : 1 }}>
                  <td style={{ ...td, color: COLORS.textLight, fontWeight: 600 }}>{new Date(o.createdAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</td>
                  <td style={td}>{o.orderType === "parcel" ? <Badge color={COLORS.copper}>Parcel</Badge> : <strong>T-{o.table}</strong>}{o.status === "cancelled" && <span style={{ color: COLORS.error, fontSize: 11, fontWeight: 700, display: 'block' }}>❌ Cancelled</span>}</td>
                  <td style={td}>{o.items.map((it) => `${it.qty}×${it.name}`).join(", ")}</td>
                  <td style={{ ...td, fontWeight: 700 }}>{inr(getOrderTotal(o))}</td>
                  <td style={td}>{o.payment || "cash"}<span style={{ fontSize: 11, color: o.paid ? COLORS.sage : COLORS.textLight, display: 'block' }}>{o.paid ? "✅" : "⏳"}</span></td>
                  <td style={td}><button onClick={() => markPaid(o.id, o.paid && !o.coinsClaimed ? true : !o.paid)} style={{ border: `1.5px solid ${o.paid ? COLORS.sage : COLORS.line}`, background: o.paid ? COLORS.sage : "transparent", color: o.paid ? "#fff" : COLORS.ink, borderRadius: 10, padding: "6px 14px", fontSize: 13, cursor: "pointer", fontWeight: 700 }}>{o.paid ? (o.coinsClaimed ? "✓ Paid" : "🪙 Award coins") : "Mark paid"}</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

            {tab === "bookings" && (
        <div style={{ overflowX: "auto", borderRadius: 16, border: `1px solid ${COLORS.line}` }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14, background: "#fff" }}>
            <thead><tr style={{ background: COLORS.paper }}><th style={th}>Type</th><th style={th}>Details</th><th style={th}>Date</th><th style={th}>Action</th></tr></thead>
            <tbody>
              {bookings.map(b => (
                <tr key={b.id}>
                  <td style={td}>{b.type === "party" ? "🎉 Party" : "🍽️ Table"}</td>
                  <td style={td}><strong>{b.name}</strong><br />{b.phone}<br />{b.guests} Guests</td>
                  <td style={td}>{b.date} at {b.time}</td>
                  <td style={td}>
                    <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                      <a 
                        href={`https://wa.me/91${b.phone}?text=${encodeURIComponent(
                          `Hello ${b.name}! 🍽️\n\nAapki ${b.type === "party" ? "Party" : "Table"} booking confirm ho gayi hai.\n\n📅 Date: ${b.date}\n⏰ Time: ${b.time}\n👥 Guests: ${b.guests}\n\nEat & Park mein aapka swagat hai! 🎉`
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{ 
                          background: '#25D366', color: '#fff', 
                          padding: '6px 12px', borderRadius: 8, 
                          textDecoration: 'none', fontWeight: 700, fontSize: 12,
                          display: 'inline-flex', alignItems: 'center', gap: 4
                        }}
                      >
                        ✅ Confirm
                      </a>
                      <button 
                        onClick={() => deleteBooking(b.id)} 
                        style={{ background: 'transparent', border: `1.5px solid ${COLORS.rust}`, color: COLORS.rust, padding: '6px 12px', borderRadius: 8, cursor: 'pointer', fontWeight: 700 }}
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === "promotions" && (
        <>
          <h3 style={{ marginBottom: 16 }}>⚡ Flash Sale</h3>
          {flashSaleItems.map((item, idx) => (
            <div key={idx} style={{ background: '#fff', border: `1px solid ${COLORS.line}`, padding: 16, borderRadius: 12, marginBottom: 12 }}>
              <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center' }}>
                <select value={item.id}
                  onChange={e => { const m = menu.find(x => x.id === e.target.value); if (m) setFlashSaleItems(patchAt(flashSaleItems, idx, { id: m.id, name: m.name, price: m.price })); }}
                  style={{ ...inputStyle, flex: 2, minWidth: 200 }}>
                  {!menu.some(m => m.id === item.id) && <option value={item.id}>⚠️ {item.name} (menu mein nahi)</option>}
                  {menu.map(m => <option key={m.id} value={m.id}>{m.name}{m.portion ? ` (${m.portion})` : ""} — ₹{m.price}</option>)}
                </select>
                <input type="number" placeholder="Sale ₹" value={item.discountPrice} onChange={e => setFlashSaleItems(patchAt(flashSaleItems, idx, { discountPrice: Number(e.target.value) }))} style={{ ...inputStyle, width: 100 }} />
                <input type="number" placeholder="Stock" value={item.stock} onChange={e => setFlashSaleItems(patchAt(flashSaleItems, idx, { stock: Number(e.target.value) }))} style={{ ...inputStyle, width: 90 }} />
                <button onClick={() => setFlashSaleItems(patchAt(flashSaleItems, idx, { active: !item.active }))} style={{ background: item.active ? COLORS.sage : COLORS.error, color: '#fff', border: 'none', padding: '6px 12px', borderRadius: 8, cursor: 'pointer', fontWeight: 700 }}>{item.active ? '✅ Active' : '❌ Inactive'}</button>
                <button onClick={() => { if (window.confirm('Delete?')) setFlashSaleItems(flashSaleItems.filter((_, i) => i !== idx)); }} style={{ background: 'transparent', border: `1px solid ${COLORS.rust}`, color: COLORS.rust, padding: '6px 12px', borderRadius: 8, cursor: 'pointer' }}>Delete</button>
              </div>
            </div>
          ))}
          <button onClick={() => {
            const m = menu[0]; if (!m) return;
            setFlashSaleItems([...flashSaleItems, { id: m.id, name: m.name, price: m.price, discountPrice: Math.round(m.price * 0.8), stock: 10, active: true }]);
          }} style={{ ...primaryBtn, background: COLORS.sage, marginBottom: 30 }}>+ Add Flash Item</button>

          <h3 style={{ marginBottom: 16 }}>🎯 Combo Offers</h3>
          {comboOffers.map((combo, idx) => {
            const broken = !combo.items?.every(it => menu.some(m => m.id === it.id));
            return (
              <div key={idx} style={{ background: '#fff', border: `1px solid ${broken ? COLORS.error : COLORS.line}`, padding: 16, borderRadius: 12, marginBottom: 12 }}>
                {broken && <div style={{ color: COLORS.error, fontSize: 12, fontWeight: 700, marginBottom: 8 }}>⚠️ Is combo ke kuch items menu mein nahi hain — customers ko dikhega nahi. Delete karke naya banao.</div>}
                <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center' }}>
                  <input value={combo.name} onChange={e => setComboOffers(patchAt(comboOffers, idx, { name: e.target.value }))} style={{ ...inputStyle, flex: 2 }} />
                  <input type="number" value={combo.discount} onChange={e => { const d = Number(e.target.value); setComboOffers(patchAt(comboOffers, idx, { discount: d, finalPrice: Math.round(combo.totalPrice * (1 - d / 100)) })); }} style={{ ...inputStyle, width: 100 }} />
                  <input value={combo.image} onChange={e => setComboOffers(patchAt(comboOffers, idx, { image: e.target.value }))} style={{ ...inputStyle, width: 80 }} />
                  <button onClick={() => setComboOffers(patchAt(comboOffers, idx, { active: !combo.active }))} style={{ background: combo.active ? COLORS.sage : COLORS.error, color: '#fff', border: 'none', padding: '6px 12px', borderRadius: 8, cursor: 'pointer', fontWeight: 700 }}>{combo.active ? '✅' : '❌'}</button>
                  <button onClick={() => { if (window.confirm('Delete?')) setComboOffers(comboOffers.filter((_, i) => i !== idx)); }} style={{ background: 'transparent', border: `1px solid ${COLORS.rust}`, color: COLORS.rust, padding: '6px 12px', borderRadius: 8, cursor: 'pointer' }}>Delete</button>
                </div>
              </div>
            );
          })}
          <button onClick={() => {
            const picks = menu.slice(0, 2); if (picks.length === 0) return;
            const total = picks.reduce((s, m) => s + m.price, 0);
            setComboOffers([...comboOffers, {
              id: 'combo' + Date.now(), name: 'New Combo',
              items: picks.map(m => ({ id: m.id, name: m.name, price: m.price, quantity: 1 })),
              totalPrice: total, discount: 10, finalPrice: Math.round(total * 0.9), image: '🍽️', active: true
            }]);
          }} style={{ ...primaryBtn, background: COLORS.gold, marginBottom: 20 }}>+ Add Combo</button>
          <button onClick={savePromotions} style={{ ...primaryBtn, width: '100%' }}>💾 Save All</button>
        </>
      )}
      {false /* legacy promotions UI removed */ && (
        <>
          <h3 style={{ marginBottom: 16 }}>⚡ Flash Sale</h3>
          {flashSaleItems.map((item, idx) => (
            <div key={item.id} style={{ background: '#fff', border: `1px solid ${COLORS.line}`, padding: 16, borderRadius: 12, marginBottom: 12 }}>
              <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center' }}>
                <input value={item.name} onChange={e => { const u = [...flashSaleItems]; u[idx].name = e.target.value; setFlashSaleItems(u); }} style={{ ...inputStyle, flex: 2 }} />
                <input type="number" value={item.discountPrice} onChange={e => { const u = [...flashSaleItems]; u[idx].discountPrice = Number(e.target.value); setFlashSaleItems(u); }} style={{ ...inputStyle, width: 100 }} />
                <input type="number" value={item.stock} onChange={e => { const u = [...flashSaleItems]; u[idx].stock = Number(e.target.value); setFlashSaleItems(u); }} style={{ ...inputStyle, width: 80 }} />
                <button onClick={() => { const u = [...flashSaleItems]; u[idx].active = !u[idx].active; setFlashSaleItems(u); }} style={{ background: item.active ? COLORS.sage : COLORS.error, color: '#fff', border: 'none', padding: '6px 12px', borderRadius: 8, cursor: 'pointer', fontWeight: 700 }}>{item.active ? '✅ Active' : '❌ Inactive'}</button>
                <button onClick={() => { if (window.confirm('Delete?')) setFlashSaleItems(flashSaleItems.filter((_, i) => i !== idx)); }} style={{ background: 'transparent', border: `1px solid ${COLORS.rust}`, color: COLORS.rust, padding: '6px 12px', borderRadius: 8, cursor: 'pointer' }}>Delete</button>
              </div>
            </div>
          ))}
          <button onClick={() => setFlashSaleItems([...flashSaleItems, { id: 'flash' + Date.now(), name: 'New', price: 0, discountPrice: 0, stock: 0, active: true }])} style={{ ...primaryBtn, background: COLORS.sage, marginBottom: 30 }}>+ Add Flash Item</button>

          <h3 style={{ marginBottom: 16 }}>🎯 Combo Offers</h3>
          {comboOffers.map((combo, idx) => (
            <div key={combo.id} style={{ background: '#fff', border: `1px solid ${COLORS.line}`, padding: 16, borderRadius: 12, marginBottom: 12 }}>
              <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center' }}>
                <input value={combo.name} onChange={e => { const u = [...comboOffers]; u[idx].name = e.target.value; setComboOffers(u); }} style={{ ...inputStyle, flex: 2 }} />
                <input type="number" value={combo.discount} onChange={e => { const u = [...comboOffers]; u[idx].discount = Number(e.target.value); u[idx].finalPrice = Math.round(u[idx].totalPrice * (1 - u[idx].discount / 100)); setComboOffers(u); }} style={{ ...inputStyle, width: 100 }} />
                <input value={combo.image} onChange={e => { const u = [...comboOffers]; u[idx].image = e.target.value; setComboOffers(u); }} style={{ ...inputStyle, width: 80 }} />
                <button onClick={() => { const u = [...comboOffers]; u[idx].active = !u[idx].active; setComboOffers(u); }} style={{ background: combo.active ? COLORS.sage : COLORS.error, color: '#fff', border: 'none', padding: '6px 12px', borderRadius: 8, cursor: 'pointer', fontWeight: 700 }}>{combo.active ? '✅' : '❌'}</button>
                <button onClick={() => { if (window.confirm('Delete?')) setComboOffers(comboOffers.filter((_, i) => i !== idx)); }} style={{ background: 'transparent', border: `1px solid ${COLORS.rust}`, color: COLORS.rust, padding: '6px 12px', borderRadius: 8, cursor: 'pointer' }}>Delete</button>
              </div>
            </div>
          ))}
          <button onClick={() => setComboOffers([...comboOffers, { id: 'combo' + Date.now(), name: 'New Combo', items: [{ id: 'f2', name: 'Pizza', price: 280, quantity: 1 }], totalPrice: 280, discount: 10, finalPrice: 252, image: '🍽️', active: true }])} style={{ ...primaryBtn, background: COLORS.gold, marginBottom: 20 }}>+ Add Combo</button>
          <button onClick={savePromotions} style={{ ...primaryBtn, width: '100%' }}>💾 Save All</button>
        </>
      )}
    </div>
  );
}

// ==
// 19. DEFAULT DATA
// ==

const DEFAULT_MENU = [
  // ═══════════════════════════════════════════════
  // 🍛 THALI
  // ═══════════════════════════════════════════════
  mi("t101", "Veg Thali Regular", 150, "Thali", true, "Complete veg platter with roti, rice, dal, sabzi, salad.", "", true),
  mi("t102", "Special Veg Thali", 200, "Thali", true, "Premium veg thali with paneer, sweet, and more.", "", true),
  mi("t103", "Egg Thali (2 pc + roti/rice)", 220, "Thali", false, "Egg curry with roti, rice, salad.", "2 pc"),
  mi("t104", "Fish Thali (2 pc + roti/rice)", 250, "Thali", false, "Fish curry with roti, rice, salad.", "2 pc"),
  mi("t105", "Chicken Thali (2 pc + roti/rice)", 260, "Thali", false, "Chicken curry with roti, rice, salad.", "2 pc", true),
  mi("t106", "Mutton Thali (2 pc + roti/rice)", 350, "Thali", false, "Mutton curry with roti, rice, salad.", "2 pc"),

  // ═══════════════════════════════════════════════
  // 🐐 MUTTON, FISH & EGG
  // ═══════════════════════════════════════════════
  mi("mf201", "Mutton Curry", 340, "Mutton, Fish & Egg", false, "Slow-cooked traditional mutton curry.", "4 pc"),
  mi("mf202", "Mutton Masala", 360, "Mutton, Fish & Egg", false, "Spicy mutton masala.", "4 pc"),
  mi("mf203", "Mutton Handi", 650, "Mutton, Fish & Egg", false, "Earthen pot mutton delicacy.", "500g"),
  mi("mf204", "Mutton Handi", 1200, "Mutton, Fish & Egg", false, "Earthen pot mutton delicacy.", "1 Kg"),
  mi("mf205", "Mutton E&P Special", 450, "Mutton, Fish & Egg", false, "Chef's special mutton preparation.", "4 pc", true),
  mi("mf206", "Fish Curry (2 pc)", 120, "Mutton, Fish & Egg", false, "Mustard fish curry.", "2 pc"),
  mi("mf207", "Fish Curry (4 pc)", 220, "Mutton, Fish & Egg", false, "Mustard fish curry.", "4 pc"),
  mi("mf208", "Crispy Fish Fry (2 pc)", 150, "Mutton, Fish & Egg", false, "Crispy fried fish.", "2 pc"),
  mi("mf209", "Crispy Fish Fry (4 pc)", 280, "Mutton, Fish & Egg", false, "Crispy fried fish.", "4 pc"),
  mi("mf210", "Crispy Fish Fry (8 pc)", 520, "Mutton, Fish & Egg", false, "Crispy fried fish.", "8 pc"),
  mi("mf211", "Egg Curry (2 pc)", 150, "Mutton, Fish & Egg", false, "Boiled eggs in gravy.", "2 pc"),
  mi("mf212", "Egg Masala (2 pc)", 170, "Mutton, Fish & Egg", false, "Spicy egg masala.", "2 pc"),
  mi("mf213", "Egg Bhurji (4 eggs)", 180, "Mutton, Fish & Egg", false, "Scrambled eggs with spices.", "4 eggs"),
  mi("mf214", "Omelette Masala (2 eggs)", 120, "Mutton, Fish & Egg", false, "Spicy omelette.", "2 eggs"),

  // ═══════════════════════════════════════════════
  // 🍗 CHICKEN CURRIES
  // ═══════════════════════════════════════════════
  mi("cc301", "Chicken Dehati", 550, "Chicken Curries", false, "Rustic village-style chicken.", "Full"),
  mi("cc302", "Chicken Masala", 280, "Chicken Curries", false, "Classic chicken masala.", "Quarter"),
  mi("cc303", "Chicken Masala", 450, "Chicken Curries", false, "Classic chicken masala.", "Half"),
  mi("cc304", "Chicken Masala", 750, "Chicken Curries", false, "Classic chicken masala.", "Full"),
  mi("cc305", "Chicken Do Pyaza", 300, "Chicken Curries", false, "Chicken with onions.", "Quarter", true),
  mi("cc306", "Chicken Butter Masala", 350, "Chicken Curries", false, "Creamy butter chicken.", "Quarter", true),
  mi("cc307", "Chicken Handi", 320, "Chicken Curries", false, "Earthen pot chicken.", "Quarter"),
  mi("cc308", "Chicken Punjabi", 300, "Chicken Curries", false, "Punjabi style chicken.", "Quarter"),
  mi("cc309", "Chicken Korma", 320, "Chicken Curries", false, "Rich korma gravy.", "Quarter"),
  mi("cc310", "Chicken Tawa Masala", 320, "Chicken Curries", false, "Tawa-grilled chicken masala.", "Quarter"),
  mi("cc311", "Chicken Kolhapuri", 320, "Chicken Curries", false, "Spicy Kolhapuri chicken.", "Quarter"),
  mi("cc312", "Chicken Lajawab", 350, "Chicken Curries", false, "Royal chicken preparation.", "Quarter"),
  mi("cc313", "Chicken Kalimirch", 330, "Chicken Curries", false, "Black pepper chicken.", "Quarter"),
  mi("cc314", "Chicken Tikka Butter Masala", 380, "Chicken Curries", false, "Tikka in butter gravy.", "Quarter"),

  // ═══════════════════════════════════════════════
  // 🔥 TANDOOR
  // ═══════════════════════════════════════════════
  mi("td401", "Paneer Tikka", 299, "Tandoor", true, "Grilled marinated paneer.", "Half", true),
  mi("td402", "Paneer Tikka", 499, "Tandoor", true, "Grilled marinated paneer.", "Full"),
  mi("td403", "Veg Seekh Kabab", 250, "Tandoor", true, "Veg seekh kabab.", "Half"),
  mi("td404", "Paneer Seekh Kabab", 299, "Tandoor", true, "Paneer seekh kabab.", "Half"),
  mi("td405", "Paneer Pahadi", 320, "Tandoor", true, "Green masala paneer tikka.", "Half"),
  mi("td406", "Veg Hara Bhara Kabab", 250, "Tandoor", true, "Spinach-based kabab.", "Half"),
  mi("td407", "Paneer Hara Bhara Kabab", 299, "Tandoor", true, "Paneer hara bhara kabab.", "Half"),
  mi("td408", "Murgh Tikka", 350, "Tandoor", false, "Classic chicken tikka.", "Half", true),
  mi("td409", "Topibaaz Tandoori Murgh", 420, "Tandoor", false, "Signature tandoori chicken.", "Half", true),
  mi("td410", "Afghani Tandoori Murgh", 450, "Tandoor", false, "Creamy Afghani chicken.", "Half"),
  mi("td411", "Murgh Malai Tikka", 380, "Tandoor", false, "Creamy malai chicken tikka.", "Half"),
  mi("td412", "Murgh Achari Tikka", 370, "Tandoor", false, "Pickle-flavored chicken tikka.", "Half"),
  mi("td413", "Nawabi Tangdi Kabab", 400, "Tandoor", false, "Royal chicken leg kabab.", "Half"),
  mi("td414", "Murgh Seekh Kabab", 380, "Tandoor", false, "Chicken seekh kabab.", "Half"),
  mi("td415", "Afghani Murgh Kabab", 430, "Tandoor", false, "Afghani chicken kabab.", "Half"),

  // ═══════════════════════════════════════════════
  // 🍚 BIRYANI & RICE
  // ═══════════════════════════════════════════════
  mi("br501", "Chicken Biryani (1 pc + egg)", 180, "Biryani & Rice", false, "Fragrant chicken biryani.", "1 pc + egg", true),
  mi("br502", "Chicken Biryani (2 pc + egg)", 250, "Biryani & Rice", false, "Fragrant chicken biryani.", "2 pc + egg", true),
  mi("br503", "Chicken Hyderabadi Biryani (2 pc + egg)", 280, "Biryani & Rice", false, "Hyderabadi style biryani.", "2 pc + egg"),
  mi("br504", "Chicken D Biryani (leg + wing + egg)", 300, "Biryani & Rice", false, "Leg + wing + egg biryani.", "leg + wing + egg"),
  mi("br505", "Egg Biryani (2 eggs)", 180, "Biryani & Rice", false, "Egg biryani.", "2 eggs"),
  mi("br506", "Mutton Biryani", 320, "Biryani & Rice", false, "Royal mutton biryani.", "", true),
  mi("br507", "Veg Biryani", 180, "Biryani & Rice", true, "Aromatic veg biryani."),
  mi("br508", "Special Veg Biryani", 220, "Biryani & Rice", true, "Loaded veg biryani."),
  mi("br509", "Rajasthani Veg Biryani", 240, "Biryani & Rice", true, "Rajasthani style veg biryani."),
  mi("br510", "Navratan Veg Biryani", 250, "Biryani & Rice", true, "Nine-gem veg biryani."),
  mi("br511", "Plain Rice", 70, "Biryani & Rice", true, "Steamed rice."),
  mi("br512", "Jeera Rice", 110, "Biryani & Rice", true, "Cumin-tempered rice."),
  mi("br513", "Ghee Rice", 150, "Biryani & Rice", true, "Ghee-tossed rice."),
  mi("br514", "Veg Fried Rice", 170, "Biryani & Rice", true, "Veg fried rice."),
  mi("br515", "Paneer Fried Rice", 200, "Biryani & Rice", true, "Paneer fried rice."),
  mi("br516", "Schezwan Fried Rice", 180, "Biryani & Rice", true, "Spicy schezwan fried rice."),
  mi("br517", "Veg Pulao", 180, "Biryani & Rice", true, "Fragrant veg pulao."),
  mi("br518", "Special Veg Pulao", 220, "Biryani & Rice", true, "Premium veg pulao."),
  mi("br519", "Raita", 60, "Biryani & Rice", true, "Cooling yogurt."),
  mi("br520", "Boondi Raita", 80, "Biryani & Rice", true, "Boondi raita."),

  // ═══════════════════════════════════════════════
  // 🧀 PANEER & MUSHROOM
  // ═══════════════════════════════════════════════
  mi("pm601", "Mix Veg", 180, "Paneer & Mushroom", true, "Mixed vegetable curry."),
  mi("pm602", "Paneer Masala", 250, "Paneer & Mushroom", true, "Paneer in spiced gravy.", "", true),
  mi("pm603", "Paneer Kadhai", 260, "Paneer & Mushroom", true, "Kadhai paneer."),
  mi("pm604", "Paneer Handi", 270, "Paneer & Mushroom", true, "Earthen pot paneer."),
  mi("pm605", "Paneer Butter Masala", 260, "Paneer & Mushroom", true, "Creamy makhani paneer.", "", true),
  mi("pm606", "Paneer Do Pyaza", 260, "Paneer & Mushroom", true, "Paneer with onions."),
  mi("pm607", "Paneer 555", 280, "Paneer & Mushroom", true, "Signature paneer 555."),
  mi("pm608", "Paneer Dehati", 270, "Paneer & Mushroom", true, "Rustic paneer curry."),
  mi("pm609", "Paneer Chatpata", 270, "Paneer & Mushroom", true, "Tangy paneer."),
  mi("pm610", "Paneer Punjabi", 260, "Paneer & Mushroom", true, "Punjabi paneer."),
  mi("pm611", "Paneer Tawa Masala", 280, "Paneer & Mushroom", true, "Tawa paneer masala."),
  mi("pm612", "Paneer Tikka Masala", 290, "Paneer & Mushroom", true, "Tikka paneer masala."),
  mi("pm613", "Shahi Paneer", 300, "Paneer & Mushroom", true, "Royal shahi paneer."),
  mi("pm614", "Paneer Kaju", 320, "Paneer & Mushroom", true, "Paneer with cashews."),
  mi("pm615", "Paneer Rezala", 290, "Paneer & Mushroom", true, "Rezala paneer."),
  mi("pm616", "E&P Special Paneer", 350, "Paneer & Mushroom", true, "Chef's special paneer.", "", true),
  mi("pm617", "Mushroom Masala", 250, "Paneer & Mushroom", true, "Spicy mushroom masala."),
  mi("pm618", "Mushroom Do Pyaza", 260, "Paneer & Mushroom", true, "Mushroom with onions."),
  mi("pm619", "Mushroom Handi", 270, "Paneer & Mushroom", true, "Earthen pot mushroom."),
  mi("pm620", "Mushroom Kadhai", 270, "Paneer & Mushroom", true, "Kadhai mushroom."),
  mi("pm621", "Mushroom 555", 280, "Paneer & Mushroom", true, "Signature mushroom 555."),
  mi("pm622", "Mushroom Dehati", 270, "Paneer & Mushroom", true, "Rustic mushroom."),
  mi("pm623", "Mushroom Chatpata", 270, "Paneer & Mushroom", true, "Tangy mushroom."),
  mi("pm624", "Mushroom Punjabi", 260, "Paneer & Mushroom", true, "Punjabi mushroom."),
  mi("pm625", "Mushroom Kaju", 320, "Paneer & Mushroom", true, "Mushroom with cashews."),
  mi("pm626", "Mushroom Tawa Masala", 280, "Paneer & Mushroom", true, "Tawa mushroom."),
  mi("pm627", "Mushroom Rezala", 290, "Paneer & Mushroom", true, "Rezala mushroom."),
  mi("pm628", "E&P Special Mushroom", 350, "Paneer & Mushroom", true, "Chef's special mushroom."),
  mi("pm629", "Mushroom Tikka Masala", 290, "Paneer & Mushroom", true, "Tikka mushroom masala."),

  // ═══════════════════════════════════════════════
  // 🫓 DAL, ROTI & CHOLE
  // ═══════════════════════════════════════════════
  mi("dr701", "Dal Fry", 70, "Dal, Roti & Chole", true, "Cumin-tempered dal."),
  mi("dr702", "Dal Tadka", 100, "Dal, Roti & Chole", true, "Dhaba-style dal."),
  mi("dr703", "Dal Makhani", 180, "Dal, Roti & Chole", true, "Creamy black dal.", "", true),
  mi("dr704", "Dal Maharani", 200, "Dal, Roti & Chole", true, "Royal dal."),
  mi("dr705", "Chole Bhature", 120, "Dal, Roti & Chole", true, "Chole with 2 bhature.", "2 bhature", true),
  mi("dr706", "Tandoori Roti", 15, "Dal, Roti & Chole", true, "Plain tandoori roti."),
  mi("dr707", "Tandoori Roti (Butter)", 20, "Dal, Roti & Chole", true, "Butter tandoori roti."),
  mi("dr708", "Rumali Roti", 25, "Dal, Roti & Chole", true, "Soft rumali roti."),
  mi("dr709", "Naan", 50, "Dal, Roti & Chole", true, "Plain naan."),
  mi("dr710", "Naan (Butter)", 60, "Dal, Roti & Chole", true, "Butter naan."),
  mi("dr711", "Garlic Naan", 70, "Dal, Roti & Chole", true, "Garlic naan.", "", true),
  mi("dr712", "Stuffed Naan", 90, "Dal, Roti & Chole", true, "Stuffed naan."),
  mi("dr713", "Special Naan", 100, "Dal, Roti & Chole", true, "Chef's special naan."),
  mi("dr714", "Green Salad (Half)", 60, "Dal, Roti & Chole", true, "Fresh green salad.", "Half"),
  mi("dr715", "Green Salad (Full)", 100, "Dal, Roti & Chole", true, "Fresh green salad.", "Full"),

  // ═══════════════════════════════════════════════
  // 🌱 SOYA CHAAP
  // ═══════════════════════════════════════════════
  mi("sc801", "Soya Malai Chaap", 200, "Soya Chaap", true, "Creamy malai soya chaap.", "Half", true),
  mi("sc802", "Soya Malai Chaap", 380, "Soya Chaap", true, "Creamy malai soya chaap.", "Full"),
  mi("sc803", "Soya Masala Chaap (Dry)", 220, "Soya Chaap", true, "Dry masala soya chaap.", "Half"),
  mi("sc804", "Soya Masala Chaap (Gravy)", 240, "Soya Chaap", true, "Gravy masala soya chaap.", "Half"),
  mi("sc805", "Soya Pudina Chaap", 220, "Soya Chaap", true, "Mint soya chaap.", "Half"),
  mi("sc806", "Soya Achari Chaap", 220, "Soya Chaap", true, "Pickle-flavored soya chaap.", "Half"),
  mi("sc807", "Soya Butter Chaap", 240, "Soya Chaap", true, "Butter soya chaap.", "Half"),
  mi("sc808", "Soya Lemon Chaap", 220, "Soya Chaap", true, "Lemon soya chaap.", "Half"),
  mi("sc809", "Soya Chatpata Chaap", 220, "Soya Chaap", true, "Tangy soya chaap.", "Half"),
  mi("sc810", "Soya Garlic Chaap", 220, "Soya Chaap", true, "Garlic soya chaap.", "Half"),

  // ═══════════════════════════════════════════════
  // 🥡 CHINESE
  // ═══════════════════════════════════════════════
  mi("ch901", "Veg Manchurian", 180, "Chinese", true, "Veg dumplings in soy gravy.", "D/G"),
  mi("ch902", "Hot Garlic Manchurian", 190, "Chinese", true, "Hot garlic sauce manchurian.", "D/G"),
  mi("ch903", "Schezwan Manchurian", 190, "Chinese", true, "Spicy schezwan manchurian.", "D/G"),
  mi("ch904", "Paneer Chilly", 240, "Chinese", true, "Crispy paneer in chili sauce.", "D/G", true),
  mi("ch905", "Schezwan Paneer", 250, "Chinese", true, "Schezwan paneer.", "D/G"),
  mi("ch906", "Baby Corn Crispy Chilli", 240, "Chinese", true, "Crispy baby corn chili.", "D/G"),
  mi("ch907", "Paneer Chilly Hot Garlic", 260, "Chinese", true, "Paneer in hot garlic sauce.", "D/G"),
  mi("ch908", "Mushroom Chilly", 250, "Chinese", true, "Mushroom in chili sauce.", "D/G"),
  mi("ch909", "Baby Corn Hot Garlic", 250, "Chinese", true, "Baby corn in hot garlic.", "D/G"),
  mi("ch910", "Baby Corn Schezwan", 250, "Chinese", true, "Schezwan baby corn.", "D/G"),
  mi("ch911", "Mushroom Hot Garlic", 260, "Chinese", true, "Mushroom in hot garlic.", "D/G"),
  mi("ch912", "Schezwan Mushroom", 260, "Chinese", true, "Schezwan mushroom.", "D/G"),
  mi("ch913", "Veg Noodles", 130, "Chinese", true, "Wok-tossed veg noodles."),
  mi("ch914", "Schezwan Noodles", 150, "Chinese", true, "Spicy schezwan noodles."),
  mi("ch915", "Paneer Noodles", 180, "Chinese", true, "Paneer noodles."),
  mi("ch916", "Hakka Noodles", 160, "Chinese", true, "Classic hakka noodles."),
  mi("ch917", "Egg Noodles", 170, "Chinese", false, "Egg noodles."),
  mi("ch918", "Chicken Noodles", 180, "Chinese", false, "Chicken noodles."),
  mi("ch919", "Chicken Chilly (D)", 240, "Chinese", false, "Dry chili chicken.", "Dry", true),
  mi("ch920", "Chicken Chilly (G)", 260, "Chinese", false, "Gravy chili chicken.", "Gravy"),
  mi("ch921", "Chicken Salt & Pepper", 250, "Chinese", false, "Salt & pepper chicken."),
  mi("ch922", "Crispy Chilly Chicken (D)", 260, "Chinese", false, "Crispy dry chili chicken.", "Dry"),
  mi("ch923", "Chicken Hot Garlic (D)", 260, "Chinese", false, "Dry hot garlic chicken.", "Dry"),
  mi("ch924", "Chicken Hot Garlic (G)", 280, "Chinese", false, "Gravy hot garlic chicken.", "Gravy"),
  mi("ch925", "Chicken Lollypop (6 pc)", 300, "Chinese", false, "Crispy chicken lollipop.", "6 pc", true),
  mi("ch926", "Chicken Manchurian (D)", 260, "Chinese", false, "Dry chicken manchurian.", "Dry"),
  mi("ch927", "Chicken Manchurian (G)", 280, "Chinese", false, "Gravy chicken manchurian.", "Gravy"),
  mi("ch928", "KFC-style Chicken Fry", 280, "Chinese", false, "Crispy fried chicken."),
  mi("ch929", "Chicken Schezwan (D)", 270, "Chinese", false, "Dry schezwan chicken.", "Dry"),
  mi("ch930", "Chicken Schezwan (G)", 290, "Chinese", false, "Gravy schezwan chicken.", "Gravy"),
  mi("ch931", "Chicken Barbeque", 300, "Chinese", false, "BBQ chicken."),
  mi("ch932", "Dragon Chicken", 290, "Chinese", false, "Spicy dragon chicken."),
  mi("ch933", "Chicken Wings Fry", 250, "Chinese", false, "Fried chicken wings."),
  mi("ch934", "Lemon Chicken", 280, "Chinese", false, "Tangy lemon chicken."),
  mi("ch935", "Honey Crispy Chicken", 300, "Chinese", false, "Honey-glazed crispy chicken."),
  mi("ch936", "Charshi Chicken (Dry)", 320, "Chinese", false, "Charshi dry chicken.", "Dry"),

  // ═══════════════════════════════════════════════
  // 🥟 MOMOS & ROLLS
  // ═══════════════════════════════════════════════
  mi("mr1001", "Veg Momos (Steam)", 80, "Momos & Rolls", true, "Steamed veg momos.", "Steam"),
  mi("mr1002", "Veg Momos (Fry)", 100, "Momos & Rolls", true, "Fried veg momos.", "Fry"),
  mi("mr1003", "Veg Momos (Pan-fry)", 110, "Momos & Rolls", true, "Pan-fried veg momos.", "Pan-fry"),
  mi("mr1004", "Veg Momos (Kurkure)", 130, "Momos & Rolls", true, "Kurkure veg momos.", "Kurkure"),
  mi("mr1005", "Veg Momos (Tandoori)", 150, "Momos & Rolls", true, "Tandoori veg momos.", "Tandoori"),
  mi("mr1006", "Paneer Momos (Steam)", 100, "Momos & Rolls", true, "Steamed paneer momos.", "Steam"),
  mi("mr1007", "Paneer Momos (Fry)", 120, "Momos & Rolls", true, "Fried paneer momos.", "Fry"),
  mi("mr1008", "Paneer Momos (Tandoori)", 170, "Momos & Rolls", true, "Tandoori paneer momos.", "Tandoori"),
  mi("mr1009", "Chicken Momos (Steam)", 150, "Momos & Rolls", false, "Steamed chicken momos.", "Steam", true),
  mi("mr1010", "Chicken Momos (Fry)", 160, "Momos & Rolls", false, "Fried chicken momos.", "Fry"),
  mi("mr1011", "Chicken Momos (Tandoori)", 200, "Momos & Rolls", false, "Tandoori chicken momos.", "Tandoori"),
  mi("mr1012", "Veg Roll", 90, "Momos & Rolls", true, "Spiced veggies wrapped."),
  mi("mr1013", "Special Veg Roll", 120, "Momos & Rolls", true, "Special veg roll."),
  mi("mr1014", "Paneer Roll", 130, "Momos & Rolls", true, "Tandoori paneer roll."),
  mi("mr1015", "Veg Cheese Roll", 140, "Momos & Rolls", true, "Veg cheese roll."),
  mi("mr1016", "Paneer Tikka Roll", 150, "Momos & Rolls", true, "Paneer tikka roll."),
  mi("mr1017", "Mushroom Tikka Roll", 160, "Momos & Rolls", true, "Mushroom tikka roll."),
  mi("mr1018", "Veg Spring Roll", 120, "Momos & Rolls", true, "Veg spring roll."),
  mi("mr1019", "Malai Chaap Roll", 150, "Momos & Rolls", true, "Malai chaap roll."),
  mi("mr1020", "Egg Roll", 100, "Momos & Rolls", false, "Egg roll."),
  mi("mr1021", "Double Egg Roll", 130, "Momos & Rolls", false, "Double egg roll."),
  mi("mr1022", "Chicken Roll", 150, "Momos & Rolls", false, "Chicken roll.", "", true),
  mi("mr1023", "Chicken Tikka Roll", 170, "Momos & Rolls", false, "Chicken tikka roll."),
  mi("mr1024", "Double Egg Double Chicken Roll", 200, "Momos & Rolls", false, "Double egg + double chicken."),
  mi("mr1025", "Chicken Spring Roll", 160, "Momos & Rolls", false, "Chicken spring roll."),

  // ═══════════════════════════════════════════════
  // 🍕 PIZZA, BURGERS & MORE
  // ═══════════════════════════════════════════════
  mi("pb1101", "Classic Pizza", 200, "Pizza, Burgers & More", true, "Classic veg pizza."),
  mi("pb1102", "Mexican Pizza", 250, "Pizza, Burgers & More", true, "Spicy Mexican pizza."),
  mi("pb1103", "Mushroom Pizza", 260, "Pizza, Burgers & More", true, "Mushroom pizza."),
  mi("pb1104", "Paneer Onion Pizza", 260, "Pizza, Burgers & More", true, "Paneer onion pizza."),
  mi("pb1105", "Farmhouse Pizza", 280, "Pizza, Burgers & More", true, "Loaded farmhouse pizza."),
  mi("pb1106", "Cheese Pizza", 250, "Pizza, Burgers & More", true, "Extra cheese pizza."),
  mi("pb1107", "E&P Special Pizza", 300, "Pizza, Burgers & More", true, "Chef's special pizza.", "", true),
  mi("pb1108", "Veg Crispy Burger", 90, "Pizza, Burgers & More", true, "Crispy veg burger."),
  mi("pb1109", "Veg Cheese Burger", 120, "Pizza, Burgers & More", true, "Veg cheese burger."),
  mi("pb1110", "Chicken Crispy Burger", 150, "Pizza, Burgers & More", false, "Crispy chicken burger."),
  mi("pb1111", "Chicken Cheese Burger", 180, "Pizza, Burgers & More", false, "Chicken cheese burger."),
  mi("pb1112", "Veg Pasta", 160, "Pizza, Burgers & More", true, "Veg pasta."),
  mi("pb1113", "Red Sauce Pasta", 180, "Pizza, Burgers & More", true, "Red sauce pasta."),
  mi("pb1114", "White Sauce Pasta", 200, "Pizza, Burgers & More", true, "Creamy white sauce pasta."),
  mi("pb1115", "Mix Sauce Pasta", 220, "Pizza, Burgers & More", true, "Mix sauce pasta."),
  mi("pb1116", "Veg Sandwich", 120, "Pizza, Burgers & More", true, "Grilled veg sandwich."),
  mi("pb1117", "Veg Cheese Sandwich", 150, "Pizza, Burgers & More", true, "Grilled veg cheese sandwich."),
  mi("pb1118", "Club Sandwich (3 layer)", 180, "Pizza, Burgers & More", true, "3-layer club sandwich."),
  mi("pb1119", "Chicken Sandwich", 160, "Pizza, Burgers & More", false, "Chicken sandwich."),
  mi("pb1120", "Chicken Cheese Sandwich", 190, "Pizza, Burgers & More", false, "Chicken cheese sandwich."),
  mi("pb1121", "Chicken Club Sandwich", 220, "Pizza, Burgers & More", false, "3-layer chicken club sandwich."),

  // ═══════════════════════════════════════════════
  // 🍜 MAGGI, CORN & FRIES
  // ═══════════════════════════════════════════════
  mi("mc1201", "Plain Maggi", 60, "Maggi, Corn & Fries", true, "Plain Maggi noodles."),
  mi("mc1202", "Masala Maggi", 80, "Maggi, Corn & Fries", true, "Spicy masala Maggi."),
  mi("mc1203", "Cheese Corn Maggi", 120, "Maggi, Corn & Fries", true, "Cheese corn Maggi."),
  mi("mc1204", "Schezwan Maggi", 100, "Maggi, Corn & Fries", true, "Schezwan Maggi."),
  mi("mc1205", "Hot Garlic Maggi", 100, "Maggi, Corn & Fries", true, "Hot garlic Maggi."),
  mi("mc1206", "E&P Special Maggi", 130, "Maggi, Corn & Fries", true, "Chef's special Maggi.", "", true),
  mi("mc1207", "Corn Salt & Pepper", 100, "Maggi, Corn & Fries", true, "Salt & pepper corn."),
  mi("mc1208", "Corn Lemon & Butter", 110, "Maggi, Corn & Fries", true, "Lemon butter corn."),
  mi("mc1209", "Corn Garlic & Butter", 110, "Maggi, Corn & Fries", true, "Garlic butter corn."),
  mi("mc1210", "Masala Corn", 100, "Maggi, Corn & Fries", true, "Spicy masala corn."),
  mi("mc1211", "French Fries", 100, "Maggi, Corn & Fries", true, "Crispy french fries.", "", true),
  mi("mc1212", "Masala Fries", 120, "Maggi, Corn & Fries", true, "Masala fries."),
  mi("mc1213", "Crispy Chilly Potato", 140, "Maggi, Corn & Fries", true, "Crispy chili potato."),
  mi("mc1214", "Honey Chilli Potato", 150, "Maggi, Corn & Fries", true, "Honey chili potato."),

  // ═══════════════════════════════════════════════
  // 🍲 SOUPS
  // ═══════════════════════════════════════════════
  mi("sp1301", "Veg Hot & Sour", 100, "Soups", true, "Veg hot & sour soup."),
  mi("sp1302", "Veg Manchow", 100, "Soups", true, "Veg manchow soup."),
  mi("sp1303", "Sweet Corn", 110, "Soups", true, "Sweet corn soup."),
  mi("sp1304", "Tomato Soup", 100, "Soups", true, "Tomato soup."),
  mi("sp1305", "Chicken Hot & Sour", 130, "Soups", false, "Chicken hot & sour soup."),
  mi("sp1306", "Chicken Manchow", 130, "Soups", false, "Chicken manchow soup."),

  // ═══════════════════════════════════════════════
  // 🥤 SHAKES & DRINKS
  // ═══════════════════════════════════════════════
  mi("sd1401", "Mojito (Mint)", 90, "Shakes & Drinks", true, "Mint mojito.", "", true),
  mi("sd1402", "Mojito (Blue Lagoon)", 90, "Shakes & Drinks", true, "Blue lagoon mojito."),
  mi("sd1403", "Mojito (Green Apple)", 90, "Shakes & Drinks", true, "Green apple mojito."),
  mi("sd1404", "Mojito (Blueberry)", 90, "Shakes & Drinks", true, "Blueberry mojito."),
  mi("sd1405", "Mojito (Spicy Lemonade)", 90, "Shakes & Drinks", true, "Spicy lemonade mojito."),
  mi("sd1406", "Mojito (Watermelon)", 90, "Shakes & Drinks", true, "Watermelon mojito."),
  mi("sd1407", "Vanilla Shake", 120, "Shakes & Drinks", true, "Vanilla milkshake."),
  mi("sd1408", "Chocolate Shake", 130, "Shakes & Drinks", true, "Chocolate milkshake."),
  mi("sd1409", "Butterscotch Shake", 130, "Shakes & Drinks", true, "Butterscotch shake."),
  mi("sd1410", "Strawberry Shake", 130, "Shakes & Drinks", true, "Strawberry shake."),
  mi("sd1411", "KitKat Shake", 150, "Shakes & Drinks", true, "KitKat shake."),
  mi("sd1412", "Oreo Shake", 140, "Shakes & Drinks", true, "Oreo shake."),
  mi("sd1413", "KitKat Oreo Shake", 160, "Shakes & Drinks", true, "KitKat + Oreo shake.", "", true),
  mi("sd1414", "Cold Coffee", 120, "Shakes & Drinks", true, "Chilled cold coffee.", "", true),
  mi("sd1415", "Hot Chocolate", 100, "Shakes & Drinks", true, "Hot chocolate."),
  mi("sd1416", "Dark Hot Chocolate", 120, "Shakes & Drinks", true, "Dark hot chocolate."),
  mi("sd1417", "Hot Coffee", 60, "Shakes & Drinks", true, "Hot coffee."),
  mi("sd1418", "Hot Tea", 30, "Shakes & Drinks", true, "Hot tea."),
  mi("sd1419", "Hot Milk", 50, "Shakes & Drinks", true, "Hot milk."),
  mi("sd1420", "Lime Water (Nimbu)", 40, "Shakes & Drinks", true, "Fresh lime water."),
  mi("sd1421", "Cold Drinks", 50, "Shakes & Drinks", true, "Chilled cold drink."),
  mi("sd1422", "Mineral Water (MRP)", 20, "Shakes & Drinks", true, "Mineral water."),

  // ═══════════════════════════════════════════════
  // 🍮 DESSERTS
  // ═══════════════════════════════════════════════
  mi("ds1501", "Rasgulla", 60, "Desserts", true, "Sweet rasgulla."),
  mi("ds1502", "Gulab Jamun", 60, "Desserts", true, "Sweet gulab jamun."),
  mi("ds1503", "Rajbhog", 80, "Desserts", true, "Royal rajbhog."),
  mi("ds1504", "Rasmalai", 90, "Desserts", true, "Creamy rasmalai."),
  mi("ds1505", "Special Fried Ice Cream", 150, "Desserts", true, "Crispy fried ice cream.", "", true),
  mi("ds1506", "Fruit Cream", 100, "Desserts", true, "Fresh fruit cream."),

  // ═══════════════════════════════════════════════
  // 🥗 COMBOS
  // ═══════════════════════════════════════════════
  mi("cb1601", "Veg Burger + Coke", 120, "Combos", true, "Veg burger with Coke."),
  mi("cb1602", "Veg Noodles + Manchurian + Coke", 220, "Combos", true, "Veg noodles + manchurian + Coke."),
  mi("cb1603", "Soya Malai Chaap + Rumali Roti + Coke", 250, "Combos", true, "Soya malai chaap combo."),
  mi("cb1604", "Paneer Tikka + Coke", 320, "Combos", true, "Paneer tikka with Coke."),
  mi("cb1605", "Veg Fried Rice + Manchurian + Coke", 220, "Combos", true, "Fried rice + manchurian + Coke."),
  mi("cb1606", "Veg Fried Rice + Paneer Chilly + Coke", 250, "Combos", true, "Fried rice + paneer chilly + Coke."),
  mi("cb1607", "Pizza + Coke", 240, "Combos", true, "Pizza with Coke."),
  mi("cb1608", "Chicken Roll + Coke", 180, "Combos", false, "Chicken roll with Coke.")
];

const DUSSEHRA_CATEGORIES = [
  "Chaat, Momos & Starters", "Noodles / Chowmein", "Dal, Raita & Papad",
  "Paneer Special", "Mushroom Special", "Rice & Pulao",
  "Breads, Sweets & Drinks", "Combos"
];
const DUSSEHRA_MENU = [
  // Chaat, Momos & Starters
  mi("dz101", "Special Banarasi Samosa Chaat", 80, "Chaat, Momos & Starters", true, "Tangy & spicy Banarasi samosa chaat.", "Half", true),
  mi("dz102", "Special Banarasi Samosa Chaat", 110, "Chaat, Momos & Starters", true, "Tangy & spicy Banarasi samosa chaat.", "Full", true),
  mi("dz103", "Himalayan Authentic Steamed Momos", 80, "Chaat, Momos & Starters", true, "With spicy mountain chutney.", "6 pcs"),
  mi("dz104", "Himalayan Authentic Steamed Momos", 110, "Chaat, Momos & Starters", true, "With spicy mountain chutney.", "10 pcs"),
  mi("dz105", "Everest Golden Fried Momos", 90, "Chaat, Momos & Starters", true, "Hot and crispy fried momos.", "6 pcs"),
  mi("dz106", "Everest Golden Fried Momos", 130, "Chaat, Momos & Starters", true, "Hot and crispy fried momos.", "10 pcs"),
  mi("dz107", "Himalayan Special Kurkure Momos", 110, "Chaat, Momos & Starters", true, "Super crunchy kurkure momos.", "6 pcs"),
  mi("dz108", "Himalayan Special Kurkure Momos", 160, "Chaat, Momos & Starters", true, "Super crunchy kurkure momos.", "10 pcs"),
  mi("dz109", "Crispy Honey Chilli Potato", 170, "Chaat, Momos & Starters", true, "Crispy potato in honey chilli sauce."),
  mi("dz110", "Hot Garlic Zesty Veg Manchurian", 200, "Chaat, Momos & Starters", true, "Dry or gravy.", "Dry / Gravy"),
  mi("dz111", "Schezwan Fiery Paneer Chilli", 260, "Chaat, Momos & Starters", true, "Dry or gravy.", "Dry / Gravy"),
  mi("dz112", "Tangy Pepper Mushroom Chilli", 300, "Chaat, Momos & Starters", true, "Dry or gravy.", "Dry / Gravy"),

  // Noodles / Chowmein
  mi("dz201", "Veg Noodles (Chowmein)", 90, "Noodles / Chowmein", true, "Wok-tossed veg chowmein.", "Half"),
  mi("dz202", "Veg Noodles (Chowmein)", 140, "Noodles / Chowmein", true, "Wok-tossed veg chowmein.", "Full"),
  mi("dz203", "Paneer Noodles (Chowmein)", 120, "Noodles / Chowmein", true, "Paneer chowmein.", "Half"),
  mi("dz204", "Paneer Noodles (Chowmein)", 180, "Noodles / Chowmein", true, "Paneer chowmein.", "Full"),
  mi("dz205", "Singapuri Veg Noodles (Spicy)", 110, "Noodles / Chowmein", true, "Spicy Singapuri style noodles.", "Half"),
  mi("dz206", "Singapuri Veg Noodles (Spicy)", 170, "Noodles / Chowmein", true, "Spicy Singapuri style noodles.", "Full"),
  mi("dz207", "Veg Chowmein + Manchurian (4 Pcs) Platter", 170, "Noodles / Chowmein", true, "Chowmein with 4 pcs manchurian.", "", true),

  // Dal, Raita & Papad
  mi("dz301", "Special Yellow Dal Tadka", 150, "Dal, Raita & Papad", true, "Special dal tadka.", "Full"),
  mi("dz302", "Plain Yellow / Jeera Dal", 130, "Dal, Raita & Papad", true, "No onion, no garlic.", "Full"),
  mi("dz303", "Special Boondi / Mix Veg Raita", 90, "Dal, Raita & Papad", true, "Boondi or mix veg raita."),
  mi("dz304", "Roasted Papad", 50, "Dal, Raita & Papad", true, "Roasted papad."),
  mi("dz305", "Masala Papad", 70, "Dal, Raita & Papad", true, "Masala papad."),

  // Paneer Special
  mi("dz401", "Paneer Kadai", 290, "Paneer Special", true, "", "Full"),
  mi("dz402", "Paneer Do Pyaza", 300, "Paneer Special", true, "", "Full"),
  mi("dz403", "Paneer Tawa Masala", 320, "Paneer Special", true, "", "Full"),
  mi("dz404", "Paneer Butter Masala", 320, "Paneer Special", true, "", "Full", true),
  mi("dz405", "Paneer Punjabi", 340, "Paneer Special", true, "", "Full"),
  mi("dz406", "Special Paneer (No Onion-Garlic)", 350, "Paneer Special", true, "No onion, no garlic.", "Full", true),

  // Mushroom Special
  mi("dz501", "Mushroom Kadai", 300, "Mushroom Special", true, "", "Full"),
  mi("dz502", "Mushroom Do Pyaza", 320, "Mushroom Special", true, "", "Full"),
  mi("dz503", "Mushroom Tawa Masala", 330, "Mushroom Special", true, "", "Full"),
  mi("dz504", "Mushroom Butter Masala", 330, "Mushroom Special", true, "", "Full"),
  mi("dz505", "Mushroom Punjabi", 350, "Mushroom Special", true, "", "Full"),
  mi("dz506", "Special Mushroom (No Onion-Garlic)", 370, "Mushroom Special", true, "No onion, no garlic.", "Full"),

  // Rice & Pulao
  mi("dz601", "Jeera Rice", 130, "Rice & Pulao", true, "", "Full"),
  mi("dz602", "Green Peas Pulao", 160, "Rice & Pulao", true, "", "Full"),
  mi("dz603", "Ghee Pulao (Special Veg Pulao)", 200, "Rice & Pulao", true, "", "Full"),

  // Breads, Sweets & Drinks
  mi("dz701", "Tandoori Roti (Plain)", 18, "Breads, Sweets & Drinks", true, "Plain tandoori roti."),
  mi("dz702", "Tandoori Roti (Butter)", 20, "Breads, Sweets & Drinks", true, "Butter tandoori roti."),
  mi("dz703", "Plain Naan", 60, "Breads, Sweets & Drinks", true, "Plain naan."),
  mi("dz704", "Butter Naan", 70, "Breads, Sweets & Drinks", true, "Butter naan."),
  mi("dz705", "Cold Drink Can (Coke / Sprite / Diet Coke)", 50, "Breads, Sweets & Drinks", true, "Chilled can."),
  mi("dz706", "Hot Gulab Jamun (2 Pcs)", 80, "Breads, Sweets & Drinks", true, "Hot gulab jamun.", "2 pcs"),
  mi("dz707", "Special Masala Cold Drink", 70, "Breads, Sweets & Drinks", true, "Masala cold drink."),
  mi("dz708", "Mineral Water", 20, "Breads, Sweets & Drinks", true, "Packaged drinking water.", "1 L"),

  // Combos
  mi("dz801", "Combo 1: Chinese Platter", 220, "Combos", true, "Veg Noodles + Veg Manchurian (4 pcs) + 1 Coke can.", "", true),
  mi("dz802", "Combo 2: Tandoori Feast", 280, "Combos", true, "Paneer Butter Masala + 2 Butter Naan + 1 Gulab Jamun.", "", true),
  mi("dz803", "Combo 3: Satvik (No Onion-Garlic)", 300, "Combos", true, "Special Paneer + Jeera Rice + 2 Butter Roti.", "", true)
];

// Dussehra menu sirf Bihiya project (eat-park-r2) me, jahan VITE_BRANCH=bihiya set ho
const DUSSEHRA_ENABLED = false; // Disabled - fully removed from app

const DEFAULT_OFFERS = [
  { id: "off1", title: "Flat 20% OFF 🍜", desc: "Enjoy 20% off on all Chinese today!" },
  { id: "off2", title: "Free Cold Drink 🥤", desc: "Free cold drink on orders above ₹499." }
];

const DEFAULT_GALLERY = [
  "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=400&q=80",
  "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=400&q=80",
  "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=400&q=80"
];
// ==
// 20. ProgressRing & OrderTimer
// ==
const ProgressRing = memo(({ progress, size = 60, strokeWidth = 3 }) => {
  const circumference = 2 * Math.PI * ((size - strokeWidth) / 2);
  const offset = circumference - (progress / 100) * circumference;
  return (
    <svg width={size} height={size}>
      <g transform={`rotate(-90 ${size / 2} ${size / 2})`}>
        <circle cx={size / 2} cy={size / 2} r={(size - strokeWidth) / 2}
          fill="none" stroke={COLORS.line} strokeWidth={strokeWidth} />
        <circle cx={size / 2} cy={size / 2} r={(size - strokeWidth) / 2}
          fill="none" stroke={COLORS.sage} strokeWidth={strokeWidth}
          strokeDasharray={circumference} strokeDashoffset={offset}
          style={{ transition: 'stroke-dashoffset 0.5s ease' }} />
      </g>
      <text x="50%" y="50%" textAnchor="middle" dy="0.35em"
        fontSize="16" fontWeight="700" fill={COLORS.sage}>
        {progress}%
      </text>
    </svg>
  );
});

const OrderTimer = memo(({ createdAt, servedAt, status, estimatedTime }) => {
  const [elapsed, setElapsed] = useState(0);
  useEffect(() => {
    if (status === 'served' || status === 'delivered' || status === 'completed') {
      if (servedAt) setElapsed(Math.floor((servedAt - createdAt) / 1000));
      return;
    }
    if (status === 'cancelled') return;
    const t = setInterval(() => setElapsed(Math.floor((Date.now() - createdAt) / 1000)), 1000);
    return () => clearInterval(t);
  }, [createdAt, servedAt, status]);
  const minutes = Math.floor(elapsed / 60); const seconds = elapsed % 60; const isOvertime = elapsed > (estimatedTime * 60) && status !== 'served' && status !== 'delivered' && status !== 'completed';
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px', background: isOvertime ? 'rgba(239, 68, 68, 0.1)' : COLORS.sageLight, borderRadius: 10, borderLeft: `3px solid ${isOvertime ? COLORS.error : COLORS.sage}` }}>
      <span style={{ fontSize: 11, fontWeight: 800, color: isOvertime ? COLORS.error : COLORS.sageDark }}>⏱️ {minutes}:{seconds.toString().padStart(2, '0')}</span>
      <span style={{ fontSize: 11, color: COLORS.textLight, fontWeight: 600 }}>/ {estimatedTime}m</span>
    </div>
  );
});

// ==
// 21. MAIN APP
// ==

async function setOrderOnce(order) {
  const ref = doc(db, "orders", order.id);
  try { const ex = await getDoc(ref); if (ex.exists()) return; } catch (e) {}
  await setDoc(ref, order);
}

function authMsg(e) {
  const c = (e && e.code) || "";
  const m = {
    "auth/operation-not-allowed": "Login system band hai (Firebase > Authentication > Anonymous ON karo)",
    "auth/admin-restricted-operation": "Login system band hai (Firebase > Authentication > Anonymous ON karo)",
    "auth/network-request-failed": "Internet/network dikkat. Dobara try karo",
    "auth/web-storage-unsupported": "Is browser me storage band hai. Chrome/Safari me link kholo",
    "auth/unauthorized-domain": "Ye website Firebase Authorized domains me nahi hai",
    "auth/too-many-requests": "Bahut try ho gaye, thodi der baad try karo",
    "permission-denied": "Order allow nahi hua (Firestore rules) - staff ko batao"
  };
  return "Order fail: " + (m[c] || c || (e && e.message) || "unknown");
}
let _anonInFlight = null;
async function ensureUser() {
  try { await Promise.race([authReady, new Promise((r) => setTimeout(r, 8000))]); } catch (e) {}
  await setPersistence(auth, browserLocalPersistence); // Ye line add karo
  if (auth.currentUser) return auth.currentUser;
  if (!_anonInFlight) {
    _anonInFlight = (async () => {
      let lastErr;
      for (let i = 0; i < 3; i++) {
        try { return (await signInAnonymously(auth)).user; }
        catch (e) { lastErr = e; await new Promise((r) => setTimeout(r, 600 * (i + 1))); }
      }
      throw lastErr;
    })().finally(() => { _anonInFlight = null; });
  }
  return _anonInFlight;
}

export default function App() {
    // 👇 Check karo ki user delivery panel par aaya hai ya nahi
  if (window.location.pathname === "/delivery") {
    return <DeliveryApp />;
  }

  const [role, setRole] = useState("customer");
  const [authUser, setAuthUser] = useState(null);
  const [staffRole, setStaffRole] = useState(null); // admin | staff | waiter
  const [emailInput, setEmailInput] = useState("");
  const hadUserRef = useRef(false);
  useEffect(() => onAuthStateChanged(auth, async (u) => {
    setAuthUser(u);
    if (u) hadUserRef.current = true;
    else if (hadUserRef.current) signInAnonymously(auth).catch((e) => console.error("anon re-login:", e));
    if (u && !u.isAnonymous) {
      try {
        const s = await getDoc(doc(db, "staff", u.uid));
        const _r = s.exists() ? (s.data().role || "staff") : null;
        setStaffRole(_r);
        try {
          const saved = sessionStorage.getItem("eatpark_role");
          if (_r && (saved === "staff" || (saved === "admin" && _r === "admin"))) setRole(saved);
        } catch (e) {}

      } catch (e) { setStaffRole(null); }
    } else setStaffRole(null);
  }), []);
  const [isDark, setIsDark] = useState(false);
  const [calls, setCalls] = useState([]);
  const [inventory, setInventory] = useState([]);
  const [offersList, setOffersList] = useState(DEFAULT_OFFERS);
  const [gallery, setGallery] = useState(DEFAULT_GALLERY);
  const [loyaltyRules, setLoyaltyRules] = useState({ rate: 10, rewards: [{ id: "r1", cost: 300, item: "Free French Fry" }] });
  const [loyaltyUsers, setLoyaltyUsers] = useState([]);
  const [coinHistory, setCoinHistory] = useState([]);
  const [table, setTable] = useState(() => { const params = new URLSearchParams(window.location.search); const t = Number(params.get("table")); return Number.isInteger(t) && t >= 1 && t <= 20 ? t : 1; });
  const [menu, setMenuState] = useState(DEFAULT_MENU);
  const [unavail, setUnavail] = useState([]);
    const menuEff = useMemo(() => menu.map((m) => ({ ...m, available: !unavail.includes(m.id) })), [menu, unavail]);
  const [online, setOnline] = useState(typeof navigator === "undefined" ? true : navigator.onLine);
  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => { window.removeEventListener("online", on); window.removeEventListener("offline", off); };
  }, []);
  useEffect(() => {
    let dead = false;
    let unsub = () => {};
    authReady.then(() => {
      if (dead) return;
      unsub = onSnapshot(doc(db, "settings", "availability"), (snap) => {
        const ids = snap.exists() ? snap.data().ids : [];
        setUnavail(Array.isArray(ids) ? ids : []);
      }, (e) => console.error("availability listener:", e));
    }).catch(() => {});
    return () => { dead = true; unsub(); };
  }, []);
  const toggleAvail = async (id) => {
    const isOff = unavail.includes(id);
    setUnavail((p) => (isOff ? p.filter((x) => x !== id) : [...p, id]));
    try { await setDoc(doc(db, "settings", "availability"), { ids: isOff ? arrayRemove(id) : arrayUnion(id) }, { merge: true }); }
    catch (e) { console.error(e); alert("⚠️ Save nahi hua. Internet / rules check karo."); setUnavail((p) => (isOff ? [...p, id] : p.filter((x) => x !== id))); }
  };
  const [orders, setOrdersState] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [settings, setSettings] = useState({ menuMode: "normal", heroImage: "https://images.unsplash.com/photo-1514933651103-005eec06c04b?auto=format&fit=crop&w=800&q=80" });
  const [loading, setLoading] = useState(true);
  const [showPinModal, setShowPinModal] = useState(false);
  const [targetRole, setTargetRole] = useState("staff");
  const [pinInput, setPinInput] = useState("");
  const [categories, setCategories] = useState(CATEGORIES);
  const [dussehraMenu, setDussehraMenu] = useState(DUSSEHRA_MENU);
  const isDussehraMode = DUSSEHRA_ENABLED && settings?.menuMode === "dussehra";
  const currentMenu = useMemo(
    () => (isDussehraMode ? dussehraMenu : menu).map((m) => ({ ...m, available: !unavail.includes(m.id) })),
    [isDussehraMode, dussehraMenu, menu, unavail]
  );
  const currentCategories = isDussehraMode ? DUSSEHRA_CATEGORIES : categories;
  const [flashSaleItems, setFlashSaleItems] = useState([
    { id: 'mf207', name: 'Fish Curry (4 pc)', price: 220, discountPrice: 179, stock: 10, active: true }
  ]);
  const [_oldFlash, _setOldFlash] = useState([
    { id: 'nv19', name: 'Fish Curry', price: 449, discountPrice: 299, stock: 10, active: true }
  ]);
  const [comboOffers, setComboOffers] = useState([
    { id: 'combo1', name: 'Family Combo', items: [
        { id: 'pb1107', name: 'E&P Special Pizza', price: 300, quantity: 1 },
        { id: 'br502', name: 'Chicken Biryani (2 pc + egg)', price: 250, quantity: 1 },
        { id: 'pm602', name: 'Paneer Masala', price: 250, quantity: 1 }],
      totalPrice: 800, discount: 20, finalPrice: 640, image: '🍕', active: true },
    { id: 'combo2', name: 'Weekend Special', items: [
        { id: 'cc306', name: 'Chicken Butter Masala', price: 350, quantity: 1 },
        { id: 'dr711', name: 'Garlic Naan', price: 70, quantity: 2 },
        { id: 'sd1421', name: 'Cold Drinks', price: 50, quantity: 2 }],
      totalPrice: 590, discount: 25, finalPrice: 443, image: '🍗', active: true }
  ]);
  const [_oldCombos, _setOldCombos] = useState([
    { id: 'combo1', name: 'Family Combo', items: [{ id: 'f2', name: 'Special Pizza', price: 280, quantity: 1 }, { id: 'br5', name: 'Chicken Biryani', price: 210, quantity: 1 }, { id: 'pn1', name: 'Paneer Masala', price: 250, quantity: 1 }], totalPrice: 740, discount: 20, finalPrice: 592, image: '🍕', active: true },
    { id: 'combo2', name: 'Weekend Special', items: [{ id: 'nv8', name: 'Butter Chicken', price: 350, quantity: 1 }, { id: 'b8', name: 'Garlic Naan', price: 70, quantity: 2 }, { id: 'd10', name: 'Cold Drink', price: 50, quantity: 2 }], totalPrice: 590, discount: 25, finalPrice: 442, image: '🍗', active: true }
  ]);

  const pinLock = usePinLockout();
  const validComboOffers = useMemo(
    () => comboOffers.filter(c => c.items?.length && c.items.every(it => currentMenu.some(m => m.id === it.id && (!settings.vegMode || m.veg)))),
    [comboOffers, currentMenu, settings.vegMode]
  );
  const validFlashSaleItems = useMemo(
    () => flashSaleItems.filter(f => currentMenu.some(m => m.id === f.id && (!settings.vegMode || m.veg))),
    [flashSaleItems, currentMenu, settings.vegMode]
  );

  const requestPinPrompt = (target) => {
    if (target === "customer") {
      setRole("customer"); try { sessionStorage.removeItem("eatpark_role"); } catch (e) {}

      setOrdersState([]); setLoyaltyUsers([]); setInventory([]); setCoinHistory([]); setBookings([]); setCalls([]);
      signOut(auth).catch(() => {});
      return;
    }
    if (staffRole === "admin" || (target === "staff" && staffRole === "staff")) { setRole(target); try { sessionStorage.setItem("eatpark_role", target); } catch (e) {} return; }

    setTargetRole(target); setShowPinModal(true); setPinInput("");
  };

  const handlePinSubmit = async () => {
    if (!emailInput.trim() || !pinInput) { alert("❌ Email aur password daalo"); return; }

    if (pinLock.isLocked()) {
      alert(`⏳ Bahut galat attempts. ${pinLock.secondsLeft()}s baad try karo.`);
      return;
    }

    try {
      const cred = await signInWithEmailAndPassword(auth, emailInput.trim(), pinInput);
      console.log("✅ Auth success, UID:", cred.user.uid);

      let s;
      try {
        s = await getDoc(doc(db, "staff", cred.user.uid));
      } catch (fsErr) {
        console.error("❌ Firestore error:", fsErr.code, fsErr.message);
        await signOut(auth);
        if (fsErr.code === "permission-denied") {
          alert("⚠️ Firestore rules staff collection ko block kar rahi hain.\nFirebase Console → Firestore → Rules check karo.");
        } else {
          alert("⚠️ Firestore error: " + fsErr.message);
        }
        return;
      }

      if (!s.exists()) {
        await signOut(auth);
        alert(
          "❌ Ye account staff nahi hai.\n\n" +
          "Firebase Console me 'staff' collection banao:\n" +
          "Document ID: " + cred.user.uid + "\n" +
          "Field: role = 'admin' ya 'staff'"
        );
        return;
      }

      const r = s.data().role || "staff";
      const ok = r === "admin" || (targetRole === "staff" && r === "staff");
           if (!ok) {
        await signOut(auth);
        alert(`❌ Is account ka role '${r}' hai, '${targetRole}' nahi.`);
        return;
      }

      pinLock.reset();
      setRole(targetRole); try { sessionStorage.setItem("eatpark_role", targetRole); } catch (e) {}

      setShowPinModal(false);
      setPinInput("");
      setEmailInput("");
    } catch (e) {
    console.error("❌ Auth error:", e.code, e.message);
    const msgs = {
      "auth/invalid-credential": "❌ Email ya password galat hai",
      "auth/user-not-found": "❌ Ye email registered nahi hai",
      "auth/wrong-password": "❌ Password galat hai",
      "auth/network-request-failed": "⚠️ Internet issue ya Auth domain galat hai",
      "auth/operation-not-allowed": "⚠️ Firebase me Email/Password provider enable nahi hai",
      "auth/too-many-requests": "⏳ Bahut attempts. Thodi der baad try karo",
      "auth/invalid-email": "❌ Email format galat hai",
    };
    alert(msgs[e.code] || `❌ Login fail: ${e.code || e.message}`);
    pinLock.registerFail();
    setPinInput("");
  }
};
 
 const updateCategories = async (newCategories) => {
    setCategories(newCategories);
    try { await setDoc(doc(db, "settings", "categories"), { categories: newCategories }); } catch (e) { console.error(e); }
  };

  // 🟢 Live: Veg Mode / hidden categories turant customers ko dikhein
  useEffect(() => {
    let off = false;
    let unsub = () => {};
    authReady.then(() => {
      if (off) return;
      unsub = onSnapshot(doc(db, "settings", "appSettings"), (snap) => {
        if (!snap.exists()) return;
        const { adminPin, staffPin, waiterPin, ...safe } = snap.data();
        setSettings((prev) => ({ ...prev, ...safe }));
      }, (e) => console.error("appSettings listener:", e));
    }).catch(() => {});
    return () => { off = true; unsub(); };
  }, []);

  // 🟢 Live menu: rate / out-of-stock turant sabko dikhe
  // 🆕 MenuMode बदलने पर मेन्यू अपडेट करें
  
  useEffect(() => {
    let off = false;
    let unsub = () => {};
    authReady.then(() => {
      if (off) return;
      unsub = onSnapshot(doc(db, "settings", "menu"), (snap) => {
        if (!snap.exists()) return;
        const items = snap.data().items;
        if (Array.isArray(items) && items.length > 0) setMenuState(items.map(withDishImage));
      }, (e) => console.error("menu listener:", e));
    }).catch(() => {});
    return () => { off = true; unsub(); };
  }, []);

  // 🎉 Dussehra menu (rates admin se edit hote hain)
  useEffect(() => {
    if (!DUSSEHRA_ENABLED) return;
    let off = false;
    let unsub = () => {};
    authReady.then(() => {
      if (off) return;
      unsub = onSnapshot(doc(db, "settings", "dussehraMenu"), (snap) => {
        if (!snap.exists()) return;
        const items = snap.data().items;
        if (Array.isArray(items) && items.length > 0) setDussehraMenu(items.map(withDishImage));
      }, (e) => console.error("dussehraMenu listener:", e));
    }).catch(() => {});
    return () => { off = true; unsub(); };
  }, []);

  const saveDussehraMenu = async (items) => {
    setDussehraMenu(items);
    try { await setDoc(doc(db, "settings", "dussehraMenu"), { items }); alert("✅ Dussehra menu save ho gaya!"); }
    catch (e) { console.error(e); alert("⚠️ Dussehra menu save nahi hua. Internet / Firebase rules check karo."); }
  };

  const loyaltyTimer = useRef(null);

  const saveLoyaltyRules = (rules) => {
    setLoyaltyRules(rules);
    clearTimeout(loyaltyTimer.current);
    loyaltyTimer.current = setTimeout(() => {
      setDoc(doc(db, "settings", "loyaltyRules"), { rules }).catch((e) => { console.error(e); alert("⚠️ Loyalty rules save nahi hue."); });
    }, 700);
  };

  const savePromotions = async () => {
    try { await setDoc(doc(db, "settings", "promotions"), { flashSale: flashSaleItems, comboOffers }); alert("✅ Saved!"); } catch (e) { alert("❌ Failed: " + e.message); }
  };

  useEffect(() => {
      // 🔔 Notification permission maango
  if (false) {
    Notification.requestPermission();
  }

  const fetchAllData = async () => {
    try {
      const lq = { docs: [] };
      const users = lq.docs.map(d => d.data());
      if (users.length > 0) setLoyaltyUsers(users);
      /* inventory ab sirf staff login ke baad load hoti hai */
      const hq = { docs: [] };
      const hist = hq.docs.map(d => d.data());
      if (hist.length > 0) setCoinHistory(hist);
      
      const ms = (await Promise.all(
        ["menu", "categories", "gallery", "offers", "loyaltyRules", "appSettings", "promotions"].map((n) => getDoc(doc(db, "settings", n)).catch(() => null))
      )).filter((s) => s && s.exists());
      
      // 🆕 menuFound flag — track karo ki Firestore mein menu hai ya nahi
      let menuFound = false;
      
      ms.forEach(ds => {
        const data = ds.data();
        
        // ✅ MENU — Force new menu if old
        if (ds.id === "menu") {
          menuFound = true;  // 🆕 Mark karo ki menu exists
          if (data.items && Array.isArray(data.items) && data.items.length > 0) {
            console.log("📦 Using Firestore menu:", data.items.length, "items");
                        setMenuState(data.items.map(withDishImage));
          } else {
            console.log("📦 Firestore menu old/empty. Using DEFAULT_MENU:", DEFAULT_MENU.length, "items");
            setMenuState(DEFAULT_MENU);
            const activeMenu = DEFAULT_MENU;
setDoc(doc(db, "settings", "menu"), { items: activeMenu }).catch(console.error);
          }
        }
        
        // ✅ CATEGORIES — Force new categories if old
        if (ds.id === "categories") {
          const firestoreCats = data.categories || [];
          const OLD_CATS = ["Chinese Starter", "Drinks", "Chef's Special", "Fun Food", "Mughlai", 
                            "Tandoori", "Soup", "Snacks", "Chinese Mains", "Chicken, Mutton, Fish & Egg",
                            "Indian Bread", "Pulao", "Aloo, Dal & Sides", 
                            "Biryani & Thali", "Momo", "Tea & Coffee"];
          const hasOldCats = false; // migration ho chuka, ab admin ki categories reset nahi hongi
          
          if (hasOldCats || firestoreCats.length === 0) {
            console.log("📂 Firestore has OLD categories. Using new CATEGORIES.");
            setCategories(CATEGORIES);
            setDoc(doc(db, "settings", "categories"), { categories: CATEGORIES }).catch(console.error);
          } else {
            console.log("📂 Using Firestore categories");
            setCategories(firestoreCats);
          }
        }
        
        // ✅ GALLERY
        if (ds.id === "gallery" && data.images) setGallery(data.images);
        if (ds.id === "offers" && Array.isArray(data.items)) setOffersList(data.items);
        if (ds.id === "loyaltyRules" && data.rules && Array.isArray(data.rules.rewards)) setLoyaltyRules(data.rules);
        
        // ✅ APP SETTINGS
        if (ds.id === "appSettings") { const { adminPin, staffPin, waiterPin, ...safe } = data; setSettings(prev => ({ ...prev, ...safe })); }
        
        // ✅ PROMOTIONS
        if (ds.id === "promotions") {
          if (data.flashSale) setFlashSaleItems(data.flashSale);
          if (data.comboOffers) setComboOffers(data.comboOffers);
        }
      });
      
      // 🆕 Agar menu Firestore mein exist nahi karta
      if (false && !menuFound) {

        console.log("📦 No menu in Firestore. Saving DEFAULT_MENU:", DEFAULT_MENU.length, "items");
        const activeMenu = DEFAULT_MENU;
setDoc(doc(db, "settings", "menu"), { items: activeMenu }).catch(console.error);
      }
      
    } catch (e) { 
      console.error("Fetch error:", e); 
    } finally { 
      setLoading(false); 
    }
  };
  
  const loadingTimer = setTimeout(() => setLoading(false), 8000);
  authReady.then(() => fetchAllData()).catch(() => fetchAllData());
  // cleanup ke liye neeche wale return mein `clearTimeout(loadingTimer)` add karo

  // ⚠️ Ye code MAT HATANA
  const qCalls = query(collection(db, "calls"), where("status", "==", "active"));
  const unsubCalls = !staffRole ? () => {} : onSnapshot(qCalls, (snap) => { 
    setCalls(snap.docs.map(d => ({ ...d.data(), id: d.id }))); 
  });
   // 📅 Bookings live listener
const unsubBookings = !staffRole ? () => {} : onSnapshot(collection(db, "bookings"), (snap) => {
  setBookings(snap.docs.map(d => ({ id: d.id, ...d.data() })));
});
  
  const startOfToday = new Date();
  startOfToday.setTime(HX.businessDayStart());
  const reloadAt = new Date(); reloadAt.setHours(5, 0, 0, 0);
  if (reloadAt <= new Date()) reloadAt.setDate(reloadAt.getDate() + 1);
  const reloadTimer = setTimeout(() => window.location.reload(), reloadAt - new Date());
  // NOTE: createdAt must be stored as a Number (Date.now()) — not serverTimestamp().
  // If any code writes serverTimestamp(), this query will miss those orders.
  const ordersQuery = query(
    collection(db, "orders"),
    where("createdAt", ">=", startOfToday.getTime())
  );
  let todayList = [];
  let openList = [];
  const mergeOrders = () => {
    const map = new Map();
    openList.forEach(o => map.set(o.id, o));
    todayList.forEach(o => map.set(o.id, o));
    setOrdersState(Array.from(map.values()));
  };
  const unsubOpen = !staffRole ? () => {} : onSnapshot(
    query(collection(db, "orders"), where("status", "in", ["new", "preparing", "ready"])),
    (snap) => { openList = snap.docs.map(normOrder); mergeOrders(); },
    (err) => console.error("Open orders listener:", err)
  );
  const unsubOrders = !staffRole ? () => {} : onSnapshot(ordersQuery, (snap) => {
    todayList = snap.docs.map(normOrder); mergeOrders();
  });
  
  return () => { 
    unsubCalls(); 
    unsubOpen();
    clearTimeout(reloadTimer);
    clearTimeout(loadingTimer);
    unsubOrders(); 
    unsubBookings();
  };
}, [staffRole]);

  // Customer: sirf apne orders
  useEffect(() => {
    if (staffRole || !authUser) return;
    const un = onSnapshot(
      query(collection(db, "orders"), where("createdBy", "==", authUser.uid)),
      (snap) => setOrdersState(snap.docs.map(normOrder)),
      (e) => console.error("my orders:", e)
    );
    return () => un();
  }, [staffRole, authUser && authUser.uid]);

  // Staff: loyalty, inventory, coin history
  useEffect(() => {
    if (!staffRole) return;
    (async () => {
      if (staffRole === "admin") try { const q1 = await getDocs(query(collection(db, "loyaltyUsers"), orderBy("coins", "desc"), limit(300))); setLoyaltyUsers(q1.docs.map(d => d.data())); } catch (e) { console.error(e); }
      if (staffRole === "admin") try { const q2 = await getDocs(collection(db, "inventory")); setInventory(q2.docs.map(d => d.data())); } catch (e) { console.error(e); }
      if (staffRole === "admin") try { const q3 = await getDocs(query(collection(db, "coinHistory"), orderBy("timestamp", "desc"), limit(300))); setCoinHistory(q3.docs.map(d => d.data())); } catch (e) { console.error(e); }
    })();
  }, [staffRole]);

  const deleteBooking = async (id) => { if (window.confirm("Delete?")) { try { await deleteDoc(doc(db, "bookings", id)); } catch (e) { console.error(e); alert("⚠️ Delete nahi hua."); } } };
  const addInventory = async (item) => { try { await setDoc(doc(db, "inventory", item.id), item); setInventory(prev => [...prev, item]); } catch (e) { console.error(e); alert("⚠️ Inventory save nahi hua."); } };
  const updateStock = async (id, ns) => { try { await updateDoc(doc(db, "inventory", id), { stock: ns }); setInventory(prev => prev.map(i => i.id === id ? { ...i, stock: ns } : i)); } catch (e) { console.error(e); alert("⚠️ Stock update nahi hua."); } };

   const requestWaiter = async (tbl) => {
    try {
      const callId = uid("call");
      await setDoc(doc(db, "calls", callId), { id: callId, table: tbl, time: Date.now(), status: "active" });
    } catch (e) { console.error(e); }
  };
   const resolveCall = async (id) => {
    try {
      await updateDoc(doc(db, "calls", id), { status: "resolved", resolvedAt: Date.now() });
    } catch (e) {
      console.error("Resolve call error:", e);
      // Fallback: turant local state se hatao
      setCalls(prev => prev.filter(c => c.id !== id));
    }
  };

  const saveOffers = async (list) => {
    setOffersList(list);
    try { await setDoc(doc(db, "settings", "offers"), { items: list }); }
    catch (e) { console.error(e); alert("⚠️ Offers save nahi hue."); }
  };
  const addOffer = async (off) => {
    const next = offersList.some(o => o.id === off.id) ? offersList.map(o => (o.id === off.id ? off : o)) : [...offersList, off];
    await saveOffers(next);
  };
  const removeOffer = async (id) => { await saveOffers(offersList.filter(o => o.id !== id)); };

  const placeOrder = async (order) => {
    try { if (order.coinsClaimed === undefined) order.coinsClaimed = false; const _u = await ensureUser(); order.createdBy = _u.uid;
 await Promise.race([setOrderOnce(order), new Promise((_, rej) => setTimeout(() => rej(new Error("Internet slow hai, order confirm nahi hua. Dobara try karo")), 15000))
]);
    setOrdersState(prev => prev.some(x => x.id === order.id) ? prev : [...prev, order]); } catch (e) {
      console.error("placeOrder failed:", e.code, e.message);
      if (e.code === "permission-denied") {
        throw new Error("Firestore rules 'orders' collection block kar rahi hain. Firebase Console → Rules check karo.");
      }
      throw e;
    }
  };

  const advanceStatus = async (orderId, currentStatus) => {
    const order = orders.find(o => o.id === orderId);
    if (order && order.orderType === "parcel" && currentStatus === "ready") {
      alert("Parcel order delivery boy handle karega. Aap ise 'Delivered' mark nahi kar sakte.");
      return;
    }
    const idx = STATUS_FLOW.indexOf(currentStatus);
    const nextStatus = STATUS_FLOW[Math.min(idx + 1, STATUS_FLOW.length - 1)];
    if (nextStatus === currentStatus) return;
    const updateData = { status: nextStatus, ...(nextStatus === "served" ? { servedAt: Date.now() } : {}) };
    if (order?.kots?.length) {
      updateData.kots = order.kots.map(k => (k.status === currentStatus ? { ...k, status: nextStatus } : k));
    }
    setOrdersState(prev => prev.map(o => (o.id === orderId ? { ...o, ...updateData } : o)));
    try {
      await runTransaction(db, async (tx) => {
        const ref = doc(db, "orders", orderId);
        const snap = await tx.get(ref);
        if (!snap.exists()) return;
        const cur = snap.data();
        if (cur.status === "cancelled") return;
        if (cur.status !== currentStatus) throw new Error("STALE_STATUS"); // another screen already moved it
        const patch = { status: nextStatus, ...(nextStatus === "served" ? { servedAt: Date.now() } : {}) };
        if (cur.kots?.length) patch.kots = cur.kots.map(k => (k.status === currentStatus ? { ...k, status: nextStatus } : k));
        tx.update(ref, patch);
      });
    } catch (e) {
      console.error(e);
      setOrdersState(prev => prev.map(o => (o.id === orderId ? { ...o, status: currentStatus, ...(order?.kots ? { kots: order.kots } : {}) } : o)));
      alert(String(e && e.message).includes("STALE_STATUS") ? "⚠️ Ye order kisi aur screen se pehle hi aage badh chuka hai." : "⚠️ Status update fail hua. Dobara try karo.");
    }
  };
  const advanceStatusOld = async (orderId, currentStatus) => {
    const idx = STATUS_FLOW.indexOf(currentStatus);
    const nextStatus = STATUS_FLOW[Math.min(idx + 1, STATUS_FLOW.length - 1)];
    const updateData = { status: nextStatus, ...(nextStatus === "served" ? { servedAt: Date.now() } : {}) };
    try { await updateDoc(doc(db, "orders", orderId), updateData); } catch (e) { }
    setOrdersState(orders.map(o => o.id === orderId ? { ...o, ...updateData } : o));
  };

 const markPaid = async (orderId, paid) => {
  try {
    await runTransaction(db, async (tx) => {
      const orderRef = doc(db, "orders", orderId);
      const orderSnap = await tx.get(orderRef);
      if (!orderSnap.exists()) throw new Error("Order not found");
      if (orderSnap.data().status === "cancelled") throw new Error("Order cancelled hai");

      const order = orderSnap.data();

      // Agar already paid mark ho chuka hai toh skip
      if (paid && order.coinsClaimed) {
        tx.update(orderRef, { paid: true });
        return;
      }

      if (paid) {
const earned = Math.floor(getOrderTotal(order) / (Number(loyaltyRules?.rate) || 10));

        const used = Math.max(0, Number(order.rewardUsedCoins) || 0);
        const phone = order.customer?.phone;

        if (phone && phone.length >= 10) {
          const userRef = doc(db, "loyaltyUsers", phone);
          const userSnap = await tx.get(userRef);
          const curCoins = userSnap.exists() ? (userSnap.data().coins || 0) : 0;
          if (used > curCoins) throw new Error("Customer ke paas itne coins nahi - reward claim galat hai");
          const newCoins = Math.max(0, curCoins + earned - used);

          if (userSnap.exists()) {
            tx.update(userRef, { coins: newCoins });
          } else {
            tx.set(userRef, { phone, name: order.customer?.name || "Guest", coins: newCoins });
          }
        }
        tx.update(orderRef, { paid: true, coinsClaimed: true });
      } else {
        tx.update(orderRef, { paid: false });
      }
    });

    // Transaction ke baad history alag se likho (idempotent check)
    // Note: yahan hum fresh data use kar rahe hain, aur agar `coinHistory` mein
    // duplicate add ho raha ho to coinsClaimed flag ke through ruk jayega
    const order = orders.find(o => o.id === orderId);
    const alreadyClaimed = order && order.coinsClaimed;
    if (paid && order && !alreadyClaimed) {
      const phone = order.customer?.phone;
      const earned = order.earnedCoins || 0;
      const used = order.rewardUsedCoins || 0;
      if (phone && phone.length >= 10) {
        if (earned > 0) {
          await addDoc(collection(db, "coinHistory"), {
            phone, coins: earned,
            reason: `Order #${order.id.slice(1, 5).toUpperCase()}`,
            timestamp: Date.now()
          });
        }
        if (used > 0) {
          await addDoc(collection(db, "coinHistory"), {
            phone, coins: -used,
            reason: `Redeemed #${order.id.slice(1, 5).toUpperCase()}`,
            timestamp: Date.now()
          });
        }
        setLoyaltyUsers(prev => {
          const ex = prev.find(u => u.phone === phone);
          const newCoins = Math.max(0, (ex?.coins || 0) + earned - used);
          if (ex) return prev.map(u => u.phone === phone ? { ...u, coins: newCoins } : u);
          return [...prev, { phone, name: order.customer?.name || "Guest", coins: newCoins }];
        });
      }
    }

    setOrdersState(prev => prev.map(o =>
      o.id === orderId ? { ...o, paid, coinsClaimed: paid ? true : o.coinsClaimed } : o
    ));
  } catch (e) {
    console.error("markPaid error:", e);
    alert("⚠️ Payment update failed: " + (e.message || "unknown"));
  }
};

  const bookEvent = async (booking) => { await setDoc(doc(db, "bookings", booking.id), booking); };

  const cancelOrderByStaff = async (orderId) => {
    try { await updateDoc(doc(db, "orders", orderId), { status: "cancelled", cancelledAt: Date.now(), cancelledBy: "staff" }); addDoc(collection(db, "auditLogs"), { orderId, action: "cancel", by: (auth.currentUser && auth.currentUser.email) || "?", at: Date.now() }).catch(() => {});  } catch (e) { console.error(e); }
  };

  if (loading) {
    return (<div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: COLORS.paper, fontWeight: 700, fontSize: 18, color: COLORS.copper }}>🍽️ Loading Eat & Park POS...</div>);
  }

  return (
    <ErrorBoundary>
      <div className={isDark ? "dark-theme" : ""} style={{ minHeight: "100vh", background: "var(--bg-color, #FAFAF8)", color: COLORS.ink, fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
        <style>{FONTS}</style>
        {!online && (<div style={{ position: "fixed", top: 0, left: 0, right: 0, zIndex: 9999, background: COLORS.error, color: "#fff", textAlign: "center", padding: "6px 8px", fontWeight: 800, fontSize: 13 }}>📵 Internet nahi hai — order / KOT abhi nahi jayega</div>)}
        <div className="app-content">
  
  
  {role === "customer" && <ErrorBoundary key="cust"><CustomerView menu={currentMenu} orders={orders} placeOrder={placeOrder} bookEvent={bookEvent} gallery={gallery} offersList={offersList} table={table} setTable={setTable} requestPinPrompt={requestPinPrompt} settings={settings} isDark={isDark} setIsDark={setIsDark} requestWaiter={requestWaiter} loyaltyRules={loyaltyRules} loyaltyUsers={loyaltyUsers} coinHistory={coinHistory} setOrdersState={setOrdersState} categories={currentCategories} flashSaleItems={validFlashSaleItems} comboOffers={validComboOffers} setMenuState={setMenuState} setLoyaltyRules={saveLoyaltyRules} advanceStatus={advanceStatus} /></ErrorBoundary>}
  
  {role === "staff" && <ErrorBoundary key="staff"><StaffView menu={currentMenu} orders={orders} placeOrder={placeOrder} categories={currentCategories} setMenuState={setMenuState} advanceStatus={advanceStatus} requestPinPrompt={requestPinPrompt} calls={calls} resolveCall={resolveCall} cancelOrderByStaff={cancelOrderByStaff} /></ErrorBoundary>}
  
  {role === "admin" && <ErrorBoundary key="admin"><AdminView dussehraMenu={dussehraMenu} saveDussehraMenu={saveDussehraMenu} menu={menu} unavail={unavail} toggleAvail={toggleAvail} setMenuState={setMenuState} bookings={bookings} orders={orders} markPaid={markPaid} requestPinPrompt={requestPinPrompt} inventory={inventory} addInventory={addInventory} updateStock={updateStock} deleteBooking={deleteBooking} offersList={offersList} addOffer={addOffer} removeOffer={removeOffer} loyaltyRules={loyaltyRules} setLoyaltyRules={saveLoyaltyRules} loyaltyUsers={loyaltyUsers} settings={settings} setSettings={setSettings} gallery={gallery} setGallery={setGallery} categories={categories} updateCategories={updateCategories} flashSaleItems={flashSaleItems} setFlashSaleItems={setFlashSaleItems} comboOffers={comboOffers} setComboOffers={setComboOffers} savePromotions={savePromotions} /></ErrorBoundary>}
  
  {/* (Removed unreachable fallback — role is always one of customer/staff/admin) */}
</div>
        {showPinModal && (
          <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)", backdropFilter: "blur(4px)", zIndex: 999, display: "flex", alignItems: "center", justifyContent: "center" }} onClick={() => setShowPinModal(false)}>
            <div onClick={(e) => e.stopPropagation()} style={{ background: "#fff", padding: "28px", borderRadius: 20, width: "90%", maxWidth: 340, textAlign: "center" }} className="slide-up">
              <div style={{ fontSize: 36, marginBottom: 16 }}>🔒</div>
              <h3 style={{ margin: "0 0 20px", fontSize: 22, fontWeight: 700 }}>Login ({targetRole.toUpperCase()})</h3>
              <input type="email" placeholder="Email" value={emailInput} onChange={(e) => setEmailInput(e.target.value)} style={{ padding: "14px", border: `1.5px solid ${COLORS.line}`, borderRadius: 12, fontSize: 16, width: "100%", boxSizing: "border-box", marginBottom: 12 }} />
              <input type="password" placeholder="••••" autoFocus value={pinInput} onChange={(e) => setPinInput(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') handlePinSubmit(); }} style={{ padding: "16px", border: `1.5px solid ${COLORS.line}`, borderRadius: 12, fontSize: 32, width: "100%", boxSizing: "border-box", textAlign: "center", letterSpacing: 12, marginBottom: 24, fontWeight: 800 }} />
              <div style={{ display: "flex", gap: 12 }}>
                <button onClick={() => { setShowPinModal(false); setPinInput(""); }} style={{ flex: 1, padding: "14px", borderRadius: 12, border: `2px solid ${COLORS.line}`, background: "transparent", fontWeight: 700, cursor: "pointer" }}>Cancel</button>
                <button onClick={handlePinSubmit} style={{ flex: 1, padding: "14px", borderRadius: 12, background: COLORS.ink, color: "#fff", border: "none", fontWeight: 800, cursor: "pointer" }}>Login</button>
              </div>
              <div style={{ fontSize: 11, color: COLORS.textLight, marginTop: 16 }}></div>
            </div>
          </div>
        )}
      </div>
    </ErrorBoundary>
  );
}

// EP-PATCH-v1
